-- 20250718 updateby : goupengcheng 10207
-- algorithm : 修改小区表

SET hive.enforce.bucketing=TRUE;
SET hive.exec.compress.output=TRUE;
SET mapred.output.compress=TRUE;
SET mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
SET io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- 减少小文件，开启自适应框架
set spark.sql.adaptive.enabled = true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

INSERT OVERWRITE TABLE dm_lte_highspeedrail_section_cell_rel_d
partition(
    p_provincecode = $dm_lte_highspeedrail_section_cell_rel_d.p_provincecode$
    ,p_date = '$dm_lte_highspeedrail_section_cell_rel_d.p_date$'
)
select
    base.p_date
    ,base.net_type
    ,base.provincecode
    ,base.citycode
    ,cfg.province_name
    ,cfg.city_name
    ,base.line_id
    ,base.line_name
    ,base.section_id_1km
    ,is_bad_section
    ,base.cellkey
    ,cell_name
    ,cell_lon
    ,cell_lat
    ,azimuth
    ,is_indoor
    ,freq
    ,is_bad_cell
    ,master_operators
from
(
    -- 小区
    SELECT
        p_date
        ,'4G' as net_type
        ,provincecode
        ,citycode
        ,lineid AS line_id
        ,line_name
        ,section_id_1km
        ,cellkey
        ,districtcode
    FROM
        -- 切换数据源
        dm_highrail_user_line_lte_all_cell_use_d
    -- 添加省分区
    WHERE p_provincecode = $dm_lte_highspeedrail_section_cell_rel_d.p_provincecode$
        AND p_date = '$dm_lte_highspeedrail_section_cell_rel_d.p_date$'
        -- 添加过滤条件
        AND valid_flag = 1
        -- dm_highrail_user_line_lte_all_cell_d
    -- WHERE
        -- p_date = '$dm_lte_highspeedrail_section_cell_rel_d.p_date$'
        -- and provincecode = $dm_lte_highspeedrail_section_cell_rel_d.p_provincecode$
) base
left join
(
    -- 配置表回填名称
    select
        distinct
        provincecode
        ,city_id
        ,city_name
        ,province_name
    from
        cfg_city
) cfg
on cfg.city_id = base.citycode
left join
(
    -- 路段打标
    select
        max(is_bad_section_4g) is_bad_section
        ,provincecode
        ,section_id_1km
        ,lineid
    from
        dm_highspeedrail_section_index_d
    WHERE p_provincecode = $dm_lte_highspeedrail_section_cell_rel_d.p_provincecode$
        AND p_date = '$dm_lte_highspeedrail_section_cell_rel_d.p_date$'
    group by
        provincecode
        ,section_id_1km
        ,lineid
) sec
on base.provincecode = sec.provincecode
    and base.section_id_1km = sec.section_id_1km
    and base.line_id = sec.lineid
left join
(
    -- 小区指标
    select
        distinct
        cell_name cell_name
        ,cell_lon cell_lon
        ,cell_lat cell_lat
        ,azimuth azimuth
        ,is_indoor is_indoor
        ,freq freq
        ,is_bad is_bad_cell
        ,master_operators master_operators
        ,cellkey
        ,provincecode
    from
        dm_lte_highspeedrail_cel_index_d
    WHERE p_provincecode = $dm_lte_highspeedrail_section_cell_rel_d.p_provincecode$
        AND p_date = '$dm_lte_highspeedrail_section_cell_rel_d.p_date$'
) cel
on base.provincecode = cel.provincecode
    and base.cellkey = cel.cellkey
;

