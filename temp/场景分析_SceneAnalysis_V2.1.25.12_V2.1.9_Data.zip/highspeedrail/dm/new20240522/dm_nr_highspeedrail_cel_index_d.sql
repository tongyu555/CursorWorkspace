-- 20250718 updateby : goupengcheng 10207
-- algorithm : 修改小区表  并对工参表去重

-- 减少小文件，开启自适应框架
set spark.sql.adaptive.enabled = true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

cache table base as
SELECT
    p_date
    ,'5G' as net_type
    ,provincecode
    ,citycode
    ,lineid AS line_id
    ,line_name
--     ,section_id_1km
    ,cellkey
    ,districtcode
    ,ROW_NUMBER() OVER(PARTITION BY lineid,cellkey ORDER BY p_date DESC) rn
FROM
    -- 切换数据源
    dm_highrail_user_line_nr_all_cell_use_d
--添加省分区过滤条件
WHERE p_provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
    AND p_date = '$dm_nr_highspeedrail_cel_index_d.p_date$'
    --添加是否场景小区过滤条件
    AND valid_flag = 1
    -- dm_highrail_user_line_nr_all_cell_d
-- WHERE
    -- p_date = '$dm_nr_highspeedrail_cel_index_d.p_date$'
    -- AND provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
HAVING rn = 1
;

-- 工参
cache table cm as
SELECT
    cell_longitude cell_lon
    ,cell_latitude cell_lat
    ,cell_azimuth azimuth
    ,regexp_replace(cellname,',','_') cell_name
    ,indoor_flag is_indoor
    ,freq freq
    ,PCI pci
    ,cell_height height
    ,bandwidth_dl bandwidth
    ,master_operators master_operators
    ,cellkey
    -- 20250718 添加去重逻辑
    ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDER BY cell_longitude DESC) rn
from
    fact_nr_cm_projdata
where p_provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
    and plmnnum = 46011
HAVING rn = 1
;

-- 地市配置表 回填名称
cache table city as
select
    provincecode
    ,province_name
    ,city_id
    ,city_name
from
    cfg_city
;

INSERT OVERWRITE TABLE dm_nr_highspeedrail_cel_index_d
partition(
    p_provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
    ,p_date = '$dm_nr_highspeedrail_cel_index_d.p_date$'
)
SELECT
    base.p_date
    ,base.net_type
    ,base.provincecode
    ,base.citycode
    ,city.province_name
    ,city.city_name
    ,base.line_id
    ,base.line_name
    ,base.cellkey
    ,cm.cell_lon
    ,cm.cell_lat
    ,cm.azimuth
    ,cm.cell_name
    ,cm.is_indoor
    ,cm.freq
    ,cm.pci
    ,cm.height
    ,cm.bandwidth
    ,cm.master_operators
    ,rsrpcount
    ,avgrsrp
    ,mod3interfer_mrcount
    ,weakcover_mrcount
    ,overlap_mrcount
    ,mod3interfer_mrratio
    ,weakcover_mrratio
    ,overlap_mrratio
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_110_rate
    ,rsrpgoodcount_105_rate
    ,flux_web
    ,flux_video
    ,rrc_connreq
    ,rrc_connsucc
    ,rrc_connsucc_rate
    ,qos_initialestabsucc
    ,qos_initialestabreq
    ,ng_connsucc
    ,ng_connatt
    ,access_success_rate
    ,ue_normalcontextrelease
    ,ue_contextrelease
    ,uecntx_drop_cnt
    ,uecntx_drop_rate
    ,ho_succintragnb
    ,ho_succbyxn
    ,ho_succbyng
    ,ho_attintragnb
    ,ho_attbyxn
    ,ho_attbyng
    ,ho_succ_rate
    ,rrc_connreestabreq
    ,rrc_connreestabsucc
    ,rrc_connreestabsucc_rate
    ,vonr_ho_atttovolte
    ,vonr_ho_succtovolte
    ,vonr_ho_succtovolte_rate
    ,vonr_rtp_rxpktul
    ,vonr_rtp_losspktul
    ,vonr_rtp_losspktul_rate
    ,vonr_rtp_rxpktdl
    ,vonr_rtp_losspktdl
    ,vonr_rtp_losspktdl_rate
    ,vonr_connreq
    ,vonr_connsucc
    ,vonr_connsucc_rate
    ,vonr_releasesum
    ,vonr_normalrelease
    ,vonr_drop_rate
    ,rlc_rxbytesul
    ,rlc_lastrxbytesul
    ,rlc_rxtimeul_exceptlastslot
    ,uexp_meanspeedul
    ,rlc_txbytesdl
    ,rlc_lasttxbytesdl
    ,rlc_txtimedl_exceptlastslot
    ,uexp_meanspeeddl
    ,flux_pm
    ,cqi_good_cnt
    ,cqi_total_cnt
    ,cqi_good_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_use_dl_rate
    ,phy_meannlperprbul
    ,is_bad_cover
    ,is_bad_access
    ,case when is_bad_cover=1 or is_bad_access=1 then 1 else 0 end is_bad
from
    base
left join
    city
on base.citycode = city.city_id
left join
(
    -- 覆盖
    select
        p_provincecode provincecode
        ,cellkey
        ,sum(ssrsrpcount) rsrpcount
        ,sum(totalssrsrp)/sum(ssrsrpcount) avgrsrp
        ,sum(mod3interfer_mrcount) mod3interfer_mrcount
        ,sum(ssrsrpcount - rsrpgoodcount) weakcover_mrcount
        ,sum(overlap_mrcount) overlap_mrcount
        ,sum(mod3interfer_mrcount)/sum(ssrsrpcount) mod3interfer_mrratio
        ,sum(ssrsrpcount - rsrpgoodcount)/sum(ssrsrpcount) weakcover_mrratio
        ,sum(overlap_mrcount)/sum(ssrsrpcount) overlap_mrratio
        ,sum(case when ssrsrpcount-weakcover_mrcount>0 then ssrsrpcount-weakcover_mrcount else 0 end) rsrpgoodcount_110
        ,sum(rsrpgoodcount) rsrpgoodcount_105
        ,sum(case when ssrsrpcount-weakcover_mrcount>0 then ssrsrpcount-weakcover_mrcount else 0 end) / sum(ssrsrpcount) rsrpgoodcount_110_rate
        ,sum(rsrpgoodcount)/sum(ssrsrpcount) rsrpgoodcount_105_rate
        ,case when sum(totalssrsrp)/sum(ssrsrpcount)<-105 and sum(rsrpgoodcount)/sum(ssrsrpcount)<0.75 then 1 else 0 end is_bad_cover
    from
        aggr_nr_highspeedrail_coverage_celgrd_d
    WHERE p_provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_nr_highspeedrail_cel_index_d.p_date$'
        -- (
        -- SELECT
            -- mod3interfer_mrcount
            -- ,overlap_mrcount
            -- ,rsrpgoodcount
            -- ,ssrsrpcount
            -- ,totalssrsrp
            -- ,weakcover_mrcount
            -- ,cellkey
            -- ,p_provincecode
            -- ,citycode
            -- ,districtcode
            -- ,rsrpgoodcount
        -- FROM
            -- aggr_nr_highspeedrail_coverage_celgrd_d
        -- WHERE
            -- p_provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
            -- AND p_date = '$dm_nr_highspeedrail_cel_index_d.p_date$'
        -- )
    group by
        p_provincecode
        ,cellkey
) celgrd
on base.cellkey = celgrd.cellkey
    and base.provincecode = celgrd.provincecode
left join
(
    -- web
    SELECT
        sum(nvl(outputoctets_sum,0) + nvl(inputoctets_sum,0))/1024/1024 AS flux_web
        ,cellkey
        ,p_provincecode provincecode
    FROM
        aggr_nr_highspeedrail_web_cel_d
    WHERE
        p_provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_nr_highspeedrail_cel_index_d.p_date$'
    group by
        p_provincecode
        ,cellkey
) web
on base.cellkey = web.cellkey
    and base.provincecode = web.provincecode
left join
(
    -- video
    SELECT
        sum(nvl(outputoctets_sum,0) + nvl(inputoctets_sum,0))/1024/1024 as flux_video
        ,cellkey
        ,p_provincecode provincecode
    FROM
        aggr_nr_highspeedrail_video_cel_d
    WHERE p_provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_nr_highspeedrail_cel_index_d.p_date$'
    group by
        p_provincecode
        ,cellkey
) video
on base.cellkey = video.cellkey
    and base.provincecode = video.provincecode
left join
(
    SELECT
        sum(ul_mos_sum) as ul_mos_sum
        ,sum(ul_mos_nonvoid_cnt) as ul_mos_nonvoid_cnt
        ,sum(ul_mos_sum)/sum(ul_mos_nonvoid_cnt) as ul_mos_avg
        ,sum(NVL(ul_mos3_cnt,0) + NVL(ul_mos4_cnt,0) + NVL(ul_mos5_cnt,0)) as ul_mos35_cnt
        ,sum(NVL(ul_mos3_cnt,0) + NVL(ul_mos4_cnt,0) + NVL(ul_mos5_cnt,0))/sum(ul_mos_nonvoid_cnt) as ul_mos35_cnt_rate
        ,sum(dl_mos_sum) as dl_mos_sum
        ,sum(dl_mos_nonvoid_cnt) as dl_mos_nonvoid_cnt
        ,sum(dl_mos_sum)/sum(dl_mos_nonvoid_cnt) as dl_mos_avg
        ,sum(NVL(dl_mos3_cnt,0) + NVL(dl_mos4_cnt,0) + NVL(dl_mos5_cnt,0)) as dl_mos35_cnt
        ,sum(NVL(dl_mos3_cnt,0) + NVL(dl_mos4_cnt,0) + NVL(dl_mos5_cnt,0))/sum(dl_mos_nonvoid_cnt) as dl_mos_35cnt_rate
        ,cellkey
        ,p_provincecode provincecode
    FROM
        aggr_volte_highspeedrail_gmsession_cel_d
    WHERE p_provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_nr_highspeedrail_cel_index_d.p_date$'
    group by
        p_provincecode
        ,cellkey
) gmsession
on base.cellkey = gmsession.cellkey
    and base.provincecode = gmsession.provincecode
left join
(
    -- pm
    SELECT
        cellkey
        ,p_provincecode as provincecode
        ,sum(rrc_connreq_busy) rrc_connreq
        ,sum(rrc_connsucc_busy) rrc_connsucc
        ,sum(rrc_connsucc_busy)/sum(rrc_connreq_busy) rrc_connsucc_rate
        ,sum(qos_initialestabsucc_busy) qos_initialestabsucc
        ,sum(qos_initialestabreq_busy) qos_initialestabreq
        ,sum(ng_connsucc_busy) ng_connsucc
        ,sum(ng_connatt_busy) ng_connatt
        ,nvl(sum(qos_initialestabsucc_busy)/sum(qos_initialestabreq_busy),1)*nvl(sum(ng_connsucc_busy)/sum(ng_connatt_busy),1)*nvl(sum(rrc_connsucc_busy)/sum(rrc_connreq_busy),1) access_success_rate
        -- ,(sum(qos_initialestabsucc_busy)/sum(qos_initialestabreq_busy))*(sum(ng_connsucc_busy)/sum(ng_connatt_busy))*(sum(rrc_connsucc_busy)/sum(rrc_connreq_busy)) access_success_rate
        ,sum(ue_normalcontextrelease_busy) ue_normalcontextrelease
        ,sum(ue_contextrelease_busy) ue_contextrelease
        ,sum(ue_contextrelease_busy - ue_normalcontextrelease_busy) uecntx_drop_cnt
        ,1 - sum(ue_normalcontextrelease_busy) / sum(ue_contextrelease_busy) uecntx_drop_rate
        ,sum(ho_succintragnb_busy) ho_succintragnb
        ,sum(ho_succbyxn_busy) ho_succbyxn
        ,sum(ho_succbyng_busy) ho_succbyng
        ,sum(ho_attintragnb_busy) ho_attintragnb
        ,sum(ho_attbyxn_busy) ho_attbyxn
        ,sum(ho_attbyng_busy) ho_attbyng
        ,sum(nvl(ho_succintragnb_busy,0) + nvl(ho_succbyxn_busy,0) + nvl(ho_succbyng_busy,0))/sum(nvl(ho_attintragnb_busy,0) + nvl(ho_attbyxn_busy,0) + nvl(ho_attbyng_busy,0)) ho_succ_rate
        ,sum(rrc_connreestabreq_busy) rrc_connreestabreq
        ,sum(rrc_connreestabsucc_busy) rrc_connreestabsucc
        ,sum(rrc_connreestabsucc_busy)/sum(rrc_connreestabreq_busy) rrc_connreestabsucc_rate
        ,sum(vonr_ho_atttovolte_busy) vonr_ho_atttovolte
        ,sum(vonr_ho_succtovolte_busy) vonr_ho_succtovolte
        ,sum(vonr_ho_succtovolte_busy)/sum(vonr_ho_atttovolte_busy) vonr_ho_succtovolte_rate
        ,sum(vonr_rtp_rxpktul_busy) vonr_rtp_rxpktul
        ,sum(vonr_rtp_losspktul_busy) vonr_rtp_losspktul
        ,sum(vonr_rtp_losspktul_busy)/sum(vonr_rtp_rxpktul_busy) vonr_rtp_losspktul_rate
        ,sum(vonr_rtp_rxpktdl_busy) vonr_rtp_rxpktdl
        ,sum(vonr_rtp_losspktdl_busy) vonr_rtp_losspktdl
        ,sum(vonr_rtp_losspktdl_busy)/sum(vonr_rtp_rxpktdl_busy) vonr_rtp_losspktdl_rate
        ,sum(vonr_connreq_busy) vonr_connreq
        ,sum(vonr_connsucc_busy) vonr_connsucc
        ,sum(vonr_connsucc_busy)/sum(vonr_connreq_busy) vonr_connsucc_rate
        ,sum(vonr_releasesum_busy) vonr_releasesum
        ,sum(vonr_normalrelease_busy) vonr_normalrelease
        ,1-sum(vonr_normalrelease_busy) / sum(vonr_releasesum_busy) vonr_drop_rate
        ,sum(rlc_rxbytesul_busy) rlc_rxbytesul
        ,sum(rlc_lastrxbytesul_busy) rlc_lastrxbytesul
        ,sum(rlc_rxtimeul_exceptlastslot_busy) rlc_rxtimeul_exceptlastslot
        ,sum((rlc_rxbytesul_busy - rlc_lastrxbytesul_busy)*8) / sum(rlc_rxtimeul_exceptlastslot_busy/1000) uexp_meanspeedul
        ,sum(rlc_txbytesdl_busy) rlc_txbytesdl
        ,sum(rlc_lasttxbytesdl_busy) rlc_lasttxbytesdl
        ,sum(rlc_txtimedl_exceptlastslot_busy) rlc_txtimedl_exceptlastslot
        ,sum((rlc_txbytesdl_busy - rlc_lasttxbytesdl_busy)*8) / sum(rlc_txtimedl_exceptlastslot_busy/1000) uexp_meanspeeddl
        ,sum(rlc_rxbytesul_busy + rlc_txbytesdl_busy) flux_pm
        ,sum(NVL(cqi_numintable_cqi10_busy,0) + NVL(cqi_numintable_cqi11_busy,0) + NVL(cqi_numintable_cqi12_busy,0) + NVL(cqi_numintable_cqi13_busy,0) + NVL(cqi_numintable_cqi14_busy,0) + NVL(cqi_numintable_cqi15_busy,0) + NVL(cqi_numintable2_cqi7_busy,0) + NVL(cqi_numintable2_cqi8_busy,0) + NVL(cqi_numintable2_cqi9_busy,0) + NVL(cqi_numintable2_cqi10_busy,0) + NVL(cqi_numintable2_cqi11_busy,0) + NVL(cqi_numintable2_cqi12_busy,0) + NVL(cqi_numintable2_cqi13_busy,0) + NVL(cqi_numintable2_cqi14_busy,0) + NVL(cqi_numintable2_cqi15_busy,0))  cqi_good_cnt
        ,sum(NVL(cqi_numintable_cqi0_busy,0) + NVL(cqi_numintable_cqi1_busy,0) + NVL(cqi_numintable_cqi2_busy,0) + NVL(cqi_numintable_cqi3_busy,0) + NVL(cqi_numintable_cqi4_busy,0) + NVL(cqi_numintable_cqi5_busy,0) + NVL(cqi_numintable_cqi6_busy,0) + NVL(cqi_numintable_cqi7_busy,0) + NVL(cqi_numintable_cqi8_busy,0) + NVL(cqi_numintable_cqi9_busy,0) + NVL(cqi_numintable_cqi10_busy,0) + NVL(cqi_numintable_cqi11_busy,0) + NVL(cqi_numintable_cqi12_busy,0) + NVL(cqi_numintable_cqi13_busy,0) + NVL(cqi_numintable_cqi14_busy,0) + NVL(cqi_numintable_cqi15_busy,0) + NVL(cqi_numintable2_cqi0_busy,0) + NVL(cqi_numintable2_cqi1_busy,0) + NVL(cqi_numintable2_cqi2_busy,0) + NVL(cqi_numintable2_cqi3_busy,0) + NVL(cqi_numintable2_cqi4_busy,0) + NVL(cqi_numintable2_cqi5_busy,0) + NVL(cqi_numintable2_cqi6_busy,0) + NVL(cqi_numintable2_cqi7_busy,0) + NVL(cqi_numintable2_cqi8_busy,0) + NVL(cqi_numintable2_cqi9_busy,0) + NVL(cqi_numintable2_cqi10_busy,0) + NVL(cqi_numintable2_cqi11_busy,0) + NVL(cqi_numintable2_cqi12_busy,0) + NVL(cqi_numintable2_cqi13_busy,0) + NVL(cqi_numintable2_cqi14_busy,0) + NVL(cqi_numintable2_cqi15_busy,0)) cqi_total_cnt
        ,sum(NVL(cqi_numintable_cqi10_busy,0) + NVL(cqi_numintable_cqi11_busy,0) + NVL(cqi_numintable_cqi12_busy,0) + NVL(cqi_numintable_cqi13_busy,0) + NVL(cqi_numintable_cqi14_busy,0) + NVL(cqi_numintable_cqi15_busy,0) + NVL(cqi_numintable2_cqi7_busy,0) + NVL(cqi_numintable2_cqi8_busy,0) + NVL(cqi_numintable2_cqi9_busy,0) + NVL(cqi_numintable2_cqi10_busy,0) + NVL(cqi_numintable2_cqi11_busy,0) + NVL(cqi_numintable2_cqi12_busy,0) + NVL(cqi_numintable2_cqi13_busy,0) + NVL(cqi_numintable2_cqi14_busy,0) + NVL(cqi_numintable2_cqi15_busy,0)) / sum(NVL(cqi_numintable_cqi0_busy,0) + NVL(cqi_numintable_cqi1_busy,0) + NVL(cqi_numintable_cqi2_busy,0) + NVL(cqi_numintable_cqi3_busy,0) + NVL(cqi_numintable_cqi4_busy,0) + NVL(cqi_numintable_cqi5_busy,0) + NVL(cqi_numintable_cqi6_busy,0) + NVL(cqi_numintable_cqi7_busy,0) + NVL(cqi_numintable_cqi8_busy,0) + NVL(cqi_numintable_cqi9_busy,0) + NVL(cqi_numintable_cqi10_busy,0) + NVL(cqi_numintable_cqi11_busy,0) + NVL(cqi_numintable_cqi12_busy,0) + NVL(cqi_numintable_cqi13_busy,0) + NVL(cqi_numintable_cqi14_busy,0) + NVL(cqi_numintable_cqi15_busy,0) + NVL(cqi_numintable2_cqi0_busy,0) + NVL(cqi_numintable2_cqi1_busy,0) + NVL(cqi_numintable2_cqi2_busy,0) + NVL(cqi_numintable2_cqi3_busy,0) + NVL(cqi_numintable2_cqi4_busy,0) + NVL(cqi_numintable2_cqi5_busy,0) + NVL(cqi_numintable2_cqi6_busy,0) + NVL(cqi_numintable2_cqi7_busy,0) + NVL(cqi_numintable2_cqi8_busy,0) + NVL(cqi_numintable2_cqi9_busy,0) + NVL(cqi_numintable2_cqi10_busy,0) + NVL(cqi_numintable2_cqi11_busy,0) + NVL(cqi_numintable2_cqi12_busy,0) + NVL(cqi_numintable2_cqi13_busy,0) + NVL(cqi_numintable2_cqi14_busy,0) + NVL(cqi_numintable2_cqi15_busy,0)) cqi_good_rate
        ,sum(prb_useddl_busy) prb_useddl
        ,sum(prb_availdl_busy) prb_availdl
        ,sum(prb_useddl_busy)/sum(prb_availdl_busy) prb_use_dl_rate
        ,avg(if(phy_meannlperprbul_busy not in ('Nan','NaN','NAN'),phy_meannlperprbul_busy,null)) phy_meannlperprbul
        ,case when nvl(sum(qos_initialestabsucc_busy)/sum(qos_initialestabreq_busy),1)*nvl(sum(ng_connsucc_busy)/sum(ng_connatt_busy),1)*nvl(sum(rrc_connsucc_busy)/sum(rrc_connreq_busy),1)<=0.9 then 1 else 0 end is_bad_access
        -- ,case when (sum(qos_initialestabsucc_busy)/sum(qos_initialestabreq_busy))*(sum(ng_connsucc_busy)/sum(ng_connatt_busy))*(sum(rrc_connsucc_busy)/sum(rrc_connreq_busy))<=0.9 then 1 else 0 end is_bad_access
    FROM
        dm_pm_nr_highspeedrail_cel_d
    WHERE p_provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_nr_highspeedrail_cel_index_d.p_date$'
    group by
        cellkey
        ,p_provincecode
)  pm
on base.cellkey = pm.cellkey
    and base.provincecode = pm.provincecode
left join
(
    -- volte
    select
        concat(eci / 256,'_',eci % 256) cellkey
        ,p_provincecode provincecode
        ,sum(volte_call_req) as volte_call_req
        ,sum(volte_call_delay_mw*volte_call_req)/sum(volte_call_req) as volte_call_delay
    from
        subject_overview_cell
    WHERE p_provincecode = $dm_nr_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_nr_highspeedrail_cel_index_d.p_date$'
    group by
                cellkey
        ,p_provincecode
) volte
on base.cellkey = volte.cellkey
    and base.provincecode = volte.provincecode
left join
    cm
on base.cellkey = cm.cellkey
;


