-- 20250718 updateby : goupengcheng 10207
-- algorithm : 修改小区表

SET hive.enforce.bucketing=TRUE;
SET hive.exec.compress.output=TRUE;
SET mapred.output.compress=TRUE;
SET mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
SET io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;


-- 减少小文件，开启自适应框架
set spark.sql.adaptive.enabled = true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

-- 高铁小区
cache table base as
SELECT
    p_date
    ,'4G' as net_type
    ,provincecode
    ,citycode
    ,lineid AS line_id
    ,line_name
--     ,section_id_1km
    ,cellkey
    ,districtcode
    ,ROW_NUMBER() OVER(PARTITION BY lineid,cellkey ORDER BY p_date DESC) rn
FROM
    -- 切换数据源
    dm_highrail_user_line_lte_all_cell_use_d
--添加省分区过滤条件
WHERE p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
    AND p_date = '$dm_lte_highspeedrail_cel_index_d.p_date$'
    --添加是否场景小区过滤条件
    AND valid_flag = 1
    -- dm_highrail_user_line_lte_all_cell_d
-- WHERE
    -- p_date = '$dm_lte_highspeedrail_cel_index_d.p_date$'
    -- AND provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
HAVING rn = 1
;

-- 电联工参
cache table cm as
SELECT
    cell_lon
    ,cell_lat
    ,azimuth
    ,cell_name
    ,is_indoor
    ,freq
    ,cellkey
    ,pci
    ,height
    ,bandwidth
    ,master_operators
   ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDEr BY cell_lon DESC) rn
FROM
(
    -- 电信工参
    SELECT
        celllon as cell_lon
        ,celllat as cell_lat
        ,azimuth as azimuth
        ,cellname as cell_name
        ,bandclass as freq
        ,case when covertype=2 then 1 else 0 end as is_indoor
        ,reportcellkey as cellkey
        ,PCI
        ,height
        ,dlband bandwidth
        ,'电信承建' master_operators
    from
        lte_cm_projdata
    where p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
    union ALL
    -- 联通工参
    select
        cell_lon
        ,cell_lat
        ,azimuth
        ,cell_name
        ,freq
        ,indoor_flag as is_indoor
        ,cellkey
        ,PCI
        ,cell_height height
        ,bandwidth_dl bandwidth
        ,'联通承建' master_operators
    from
        lte_cucc_cm_projdata
    where p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
        and contractor_plmn = 46001
        and share_flag = 1
) T
HAVING rn = 1
;

-- 地市配置表 回填名称
cache table city as
select
    provincecode
    ,province_name
    ,city_id
    ,city_name
from
    cfg_city
;

INSERT OVERWRITE TABLE dm_lte_highspeedrail_cel_index_d
partition(
    p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
    ,p_date = '$dm_lte_highspeedrail_cel_index_d.p_date$'
)
SELECT
    base.p_date
    ,base.net_type
    ,base.provincecode
    ,base.citycode
    ,city.province_name
    ,city.city_name
    ,base.line_id
    ,base.line_name
    ,base.cellkey
    ,cm.cell_lon
    ,cm.cell_lat
    ,cm.azimuth
    ,cm.cell_name
    ,cm.is_indoor
    ,cm.freq
    ,cm.pci
    ,cm.height
    ,cm.bandwidth
    ,cm.master_operators
    ,rsrpcount
    ,avgrsrp
    ,mod3interfer_mrcount
    ,weakcover_mrcount
    ,overlap_mrcount
    ,mod3interfer_mrratio
    ,weakcover_mrratio
    ,overlap_mrratio
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_110_rate
    ,rsrpgoodcount_105_rate
    ,flux_web
    ,flux_video
    ,ul_mos_sum
    ,ul_mos_nonvoid_cnt
    ,ul_mos_avg
    ,ul_mos35_cnt
    ,ul_mos35_cnt_rate
    ,dl_mos_sum
    ,dl_mos_nonvoid_cnt
    ,dl_mos_avg
    ,dl_mos35_cnt
    ,dl_mos_35cnt_rate
    ,volte_call_req
    ,volte_call_delay
    ,cell_servtime_rate
    ,pdcp_sdulosspktul_qci1
    ,pdcp_sdupktul_qci1
    ,pdcp_sdulosspktul_qci1_rate
    ,pdcp_sdulosspktdl_qci1
    ,pdcp_sdupktdl_qci1
    ,pdcp_sdulosspktdl_qci1_rate
    ,prb_dl_avail
    ,puschprbtotmeandl
    ,puschprbtotmeandl_date
    ,rrc_attconnestab_ue
    ,rrc_succconnestab_ue
    ,rrc_attconnestab_net
    ,rrc_succconnestab_net
    ,rrc_succconnestab_rate
    ,s1sig_attconnestab
    ,s1sig_succconnestab
    ,s1sig_succconnestab_rate
    ,erab_initattestab
    ,erab_initsuccestab
    ,erab_addattestab
    ,erab_addsuccestab
    ,erab_succestab_rate
    ,access_success_rate
    ,rrc_attconnreestab
    ,rrc_succconnreestab
    ,rrc_succconnreestab_rate
    ,erab_abnormrel
    ,erab_normrel
    ,erab_drop_rate
    ,pdcp_sduoctul
    ,pdcp_sdutailflowul
    ,pdcp_thrptimeul
    ,pdcp_tailtimeul
    ,uexp_meanspeedul
    ,pdcp_sduoctdl
    ,pdcp_sdutailflowdl
    ,pdcp_thrptimedl
    ,pdcp_tailtimedl
    ,uexp_meanspeeddl
    ,flux_pm
    ,erab_initattestab_qci1
    ,erab_initsuccestab_qci1
    ,erab_addattestab_qci1
    ,erab_addsuccestab_qci1
    ,erab_succestab_rate_qci1
    ,access_success_rate_qci1
    ,erab_abnormrel_qci1
    ,erab_normrel_qci1
    ,erab_drop_rate_qci1
    ,cqi_good_cnt
    ,cqi_total_cnt
    ,cqi_good_rate
    ,ho_succoutintraenb
    ,ho_succouts1
    ,ho_succoutx2
    ,ho_attoutintraenb
    ,ho_attouts1
    ,ho_attoutx2
    ,ho_succ_rate
    ,is_bad_cover
    ,is_bad_access
    ,case when is_bad_cover=1 or is_bad_access=1 then 1 else 0 end is_bad
from
    base
left join
    city
on base.citycode = city.city_id
left join
(
    -- 覆盖指标
    select
        p_provincecode provincecode
        ,cellkey
        ,sum(rsrpcount) as rsrpcount
        ,sum(totalrsrp)/sum(rsrpcount) as avgrsrp
        ,sum(mod3interfer_mrcount) as mod3interfer_mrcount
        ,sum(weakcover_mrcount) as weakcover_mrcount
        ,sum(overlap_mrcount) as overlap_mrcount
        ,sum(mod3interfer_mrcount)/sum(rsrpcount) as mod3interfer_mrratio
        ,sum(weakcover_mrcount)/sum(rsrpcount) as weakcover_mrratio
        ,sum(overlap_mrcount)/sum(rsrpcount) as overlap_mrratio
        ,sum(case when rsrpcount-weakcover_mrcount>0 then rsrpcount-weakcover_mrcount else 0 end) as rsrpgoodcount_110
        ,sum(rsrpgoodcount) as rsrpgoodcount_105
        ,sum(case when rsrpcount-weakcover_mrcount>0 then rsrpcount-weakcover_mrcount else 0 end)/sum(rsrpcount) as rsrpgoodcount_110_rate
        ,sum(rsrpgoodcount)/sum(rsrpcount) as rsrpgoodcount_105_rate
        ,case when sum(totalrsrp)/sum(rsrpcount) <-105 and sum(case when rsrpcount-weakcover_mrcount>0 then rsrpcount-weakcover_mrcount else 0 end)/sum(rsrpcount)<0.75 then 1 else 0 end is_bad_cover
    from
        aggr_lte_highspeedrail_coverage_celgrd_d
    WHERE p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_lte_highspeedrail_cel_index_d.p_date$'
    -- (
        -- SELECT
            -- totalrsrp
            -- ,rsrpcount
            -- ,totaldlsinr
            -- ,dlsinrcount
            -- ,mod3interfer_mrcount
            -- ,weakcover_mrcount
            -- ,overlap_mrcount
            -- ,overshoot_mrcount
            -- ,cellkey
            -- ,p_provincecode
            -- ,citycode
            -- ,districtcode
            -- ,rsrpgoodcount
        -- FROM
            -- aggr_lte_highspeedrail_coverage_celgrd_d
        -- WHERE p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
            -- AND p_date = '$dm_lte_highspeedrail_cel_index_d.p_date$'
    -- )
    group by
        p_provincecode
        ,cellkey
) celgrd
on base.cellkey = celgrd.cellkey
    and base.provincecode = celgrd.provincecode
left join
(
    -- web
    SELECT
        sum(NVL(outputoctets_sum,0) + NVL(inputoctets_sum ,0)) /1024/1024 AS flux_web
        ,cellkey
        ,p_provincecode provincecode
    FROM
        aggr_lte_highspeedrail_web_cel_d
    WHERE p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_lte_highspeedrail_cel_index_d.p_date$'
    group by
        p_provincecode
        ,cellkey
) web
on base.cellkey = web.cellkey
    and base.provincecode = web.provincecode
left join
(
    -- video
    SELECT
        sum(NVL(outputoctets_sum,0) + NVL(inputoctets_sum,0)) /1024/1024 as flux_video
        ,cellkey
        ,p_provincecode provincecode
    FROM
        aggr_lte_highspeedrail_video_cel_d
    WHERE p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_lte_highspeedrail_cel_index_d.p_date$'
    group by
        p_provincecode
        ,cellkey
) video
on base.cellkey = video.cellkey
    and base.provincecode = video.provincecode
left join
(
    -- gmsession
    SELECT
        sum(ul_mos_sum) as ul_mos_sum
        ,sum(ul_mos_nonvoid_cnt) as ul_mos_nonvoid_cnt
        ,sum(ul_mos_sum)/sum(ul_mos_nonvoid_cnt) as ul_mos_avg
        ,sum(ul_mos3_cnt+ul_mos4_cnt+ul_mos5_cnt) as ul_mos35_cnt
        ,sum(ul_mos3_cnt+ul_mos4_cnt+ul_mos5_cnt)/sum(ul_mos_nonvoid_cnt) as ul_mos35_cnt_rate
        ,sum(dl_mos_sum) as dl_mos_sum
        ,sum(dl_mos_nonvoid_cnt) as dl_mos_nonvoid_cnt
        ,sum(dl_mos_sum)/sum(dl_mos_nonvoid_cnt) as dl_mos_avg
        ,sum(dl_mos3_cnt+dl_mos4_cnt+dl_mos5_cnt) as dl_mos35_cnt
        ,sum(dl_mos3_cnt+dl_mos4_cnt+dl_mos5_cnt)/sum(dl_mos_nonvoid_cnt) as dl_mos_35cnt_rate
        ,cellkey
        ,p_provincecode provincecode
    FROM
        aggr_volte_highspeedrail_gmsession_cel_d
    WHERE p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_lte_highspeedrail_cel_index_d.p_date$'
    group by
        p_provincecode
        ,cellkey
) gmsession
on base.cellkey = gmsession.cellkey
    and base.provincecode = gmsession.provincecode
left join
(
    -- pm
    SELECT
        cellkey
            ,p_provincecode as provincecode
            ,avg(cell_servtime_rate_4g) as cell_servtime_rate
            ,sum(pdcp_sdulosspktul_qci1_busy) as pdcp_sdulosspktul_qci1
            ,sum(pdcp_sdupktul_qci1_busy) as pdcp_sdupktul_qci1
            ,sum(pdcp_sdulosspktul_qci1_busy)/sum(pdcp_sdupktul_qci1_busy) as pdcp_sdulosspktul_qci1_rate
            ,sum(pdcp_sdulosspktdl_qci1_busy) as pdcp_sdulosspktdl_qci1
            ,sum(pdcp_sdupktdl_qci1_busy) as pdcp_sdupktdl_qci1
            ,sum(pdcp_sdulosspktdl_qci1_busy)/sum(pdcp_sdupktdl_qci1_busy) as pdcp_sdulosspktdl_qci1_rate
            ,sum(prb_dl_avail_busy) as prb_dl_avail
            ,sum(puschprbtotmeandl_busy) as puschprbtotmeandl
            ,sum(puschprbtotmeandl_busy)/sum(prb_dl_avail_busy) as puschprbtotmeandl_date
            ,sum(rrc_attconnestab_ue_busy) as rrc_attconnestab_ue
            ,sum(rrc_succconnestab_ue_busy) as rrc_succconnestab_ue
            ,sum(rrc_attconnestab_net_busy) as rrc_attconnestab_net
            ,sum(rrc_succconnestab_net_busy) as rrc_succconnestab_net
            ,sum(rrc_succconnestab_ue_busy+rrc_succconnestab_net_busy)/sum(rrc_attconnestab_ue_busy+rrc_attconnestab_net_busy) as rrc_succconnestab_rate
            ,sum(s1sig_attconnestab_busy) as s1sig_attconnestab
            ,sum(s1sig_succconnestab_busy) as s1sig_succconnestab
            ,sum(s1sig_succconnestab_busy)/sum(s1sig_attconnestab_busy) as s1sig_succconnestab_rate
            ,sum(erab_initattestab_qci1_busy) as erab_initattestab
            ,sum(erab_initsuccestab_qci1_busy) as erab_initsuccestab
            ,sum(erab_addattestab_qci1_busy) as erab_addattestab
            ,sum(erab_addsuccestab_qci1_busy) as erab_addsuccestab
            ,sum(erab_initsuccestab_qci1_busy+erab_addsuccestab_qci1_busy)/sum(erab_initattestab_qci1_busy+erab_addattestab_qci1_busy) as erab_succestab_rate
            ,(sum(rrc_succconnestab_ue_busy+rrc_succconnestab_net_busy)/sum(rrc_attconnestab_ue_busy+rrc_attconnestab_net_busy))*(sum(s1sig_succconnestab_busy)/sum(s1sig_attconnestab_busy))*(sum(erab_initsuccestab_qci1_busy+erab_addsuccestab_qci1_busy)/sum(erab_initattestab_qci1_busy+erab_addattestab_qci1_busy)) as access_success_rate
            ,sum(rrc_attconnreestab_busy) as rrc_attconnreestab
            ,sum(rrc_succconnreestab_busy) as rrc_succconnreestab
            ,sum(rrc_succconnreestab_busy)/sum(rrc_attconnreestab_busy) as rrc_succconnreestab_rate
            ,sum(erab_abnormrel_qci1_busy) as erab_abnormrel
            ,sum(erab_normrel_qci1_busy) as erab_normrel
            ,sum(erab_abnormrel_qci1_busy)/sum(erab_abnormrel_qci1_busy+erab_normrel_qci1_busy) as erab_drop_rate
            ,sum(pdcp_sduoctul_busy) as pdcp_sduoctul
            ,sum(pdcp_sdutailflowul_busy) as pdcp_sdutailflowul
            ,sum(pdcp_thrptimeul_busy) as pdcp_thrptimeul
            ,sum(pdcp_tailtimeul_busy) as pdcp_tailtimeul
            ,sum((pdcp_sduoctul_busy-pdcp_sdutailflowul_busy)*8)/sum(( pdcp_thrptimeul_busy-pdcp_tailtimeul_busy)/1000) as uexp_meanspeedul
            ,sum(pdcp_sduoctdl_busy) as pdcp_sduoctdl
            ,sum(pdcp_sdutailflowdl_busy) as pdcp_sdutailflowdl
            ,sum(pdcp_thrptimedl_busy) as pdcp_thrptimedl
            ,sum(pdcp_tailtimedl_busy) as pdcp_tailtimedl
            ,sum((pdcp_sduoctdl_busy-pdcp_sdutailflowdl_busy)*8)/sum(( pdcp_thrptimedl_busy-pdcp_tailtimedl_busy)/1000) as uexp_meanspeeddl
            ,sum(pdcp_sduoctul_busy + pdcp_sduoctdl_busy) as flux_pm
            ,sum(erab_initattestab_qci1_busy) as erab_initattestab_qci1
            ,sum(erab_initsuccestab_qci1_busy) as erab_initsuccestab_qci1
            ,sum(erab_addattestab_qci1_busy) as erab_addattestab_qci1
            ,sum(erab_addsuccestab_qci1_busy) as erab_addsuccestab_qci1
            ,sum(erab_initsuccestab_qci1_busy+erab_addsuccestab_qci1_busy)/sum(erab_initattestab_qci1_busy+erab_addattestab_qci1_busy) as erab_succestab_rate_qci1
            ,(sum(rrc_succconnestab_ue_busy+rrc_succconnestab_net_busy)/sum(rrc_attconnestab_ue_busy+rrc_attconnestab_net_busy))*(sum(s1sig_succconnestab_busy)/sum(s1sig_attconnestab_busy))*(sum(erab_initsuccestab_qci1_busy+erab_addsuccestab_qci1_busy)/sum(erab_initattestab_qci1_busy+erab_addattestab_qci1_busy)) as access_success_rate_qci1
            ,sum(erab_abnormrel_qci1_busy) as erab_abnormrel_qci1
            ,sum(erab_normrel_qci1_busy) as erab_normrel_qci1
            ,sum(erab_abnormrel_qci1_busy)/sum(erab_abnormrel_qci1_busy+erab_normrel_qci1_busy) as erab_drop_rate_qci1
            ,sum(cqi7_busy+cqi8_busy+cqi9_busy+cqi10_busy+cqi11_busy+cqi12_busy+cqi13_busy+cqi14_busy+cqi15_busy) as cqi_good_cnt
            ,sum(cqi_busy) as cqi_total_cnt
            ,sum(cqi7_busy+cqi8_busy+cqi9_busy+cqi10_busy+cqi11_busy+cqi12_busy+cqi13_busy+cqi14_busy+cqi15_busy)/sum(cqi_busy) as cqi_good_rate
            ,sum(ho_succoutintraenb_busy) as ho_succoutintraenb
            ,sum(ho_succoutx2_busy) as ho_succouts1
            ,sum(ho_succouts1_busy) as ho_succoutx2
            ,sum(ho_attoutintraenb_busy) as ho_attoutintraenb
            ,sum(ho_attoutx2_busy) as ho_attouts1
            ,sum(ho_attouts1_busy) as ho_attoutx2
            ,sum(ho_succoutintraenb_busy+ho_succoutx2_busy+ho_succouts1_busy) / sum(ho_attoutintraenb_busy+ho_attoutx2_busy+ho_attouts1_busy) as ho_succ_rate
            ,case when sum(rrc_succconnestab_ue_busy+rrc_succconnestab_net_busy)/sum(rrc_attconnestab_ue_busy+rrc_attconnestab_net_busy)<=0.9 then 1 else 0 end is_bad_access
    FROM
        dm_pm_lte_highspeedrail_cel_d
    WHERE p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_lte_highspeedrail_cel_index_d.p_date$'
    group by
        cellkey
        ,p_provincecode
)  pm
on base.cellkey = pm.cellkey
    and base.provincecode = pm.provincecode
left join
(
    -- volte
    select
        concat(eci / 256,'_',eci % 256) cellkey
        ,p_provincecode provincecode
        ,sum(volte_call_req) as volte_call_req
        ,sum(volte_call_delay_mw*volte_call_req)/sum(volte_call_req) as volte_call_delay
    from
        subject_overview_cell
    WHERE p_provincecode = $dm_lte_highspeedrail_cel_index_d.p_provincecode$
        AND p_date = '$dm_lte_highspeedrail_cel_index_d.p_date$'
    group by
        cellkey
        ,p_provincecode
) volte
on
    base.cellkey = volte.cellkey
    and base.provincecode = volte.provincecode
left join
    cm
on base.cellkey = cm.cellkey
;

