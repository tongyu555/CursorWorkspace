-- 20250718 updateby : goupengcheng 10207
-- algorithm : 修改小区表

-- 减少小文件，开启自适应框架
set spark.sql.adaptive.enabled = true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

-- 高铁配置表回填地区信息
cache table m100_withcity
select
     m100.lineid
    ,m100.line_name
    ,m100.provincecode
    ,cfg.province_name
    ,m100.citycode
    ,cfg.city_name
    ,m100.section_id_1km
    ,concat_ws('-', line_name, province_name, city_name, section_id_1km) section_name_1km
from
(
    -- 高铁配置表
    select
        id lineid
        ,name line_name
        ,provincecode
        ,citycode
        ,FLOOR(section_id / 10)  section_id_1km
    from
        cfg_highrail_100m_section
    where p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
        AND length(id) = 10
) m100
INNER JOIN
(
    -- 目前建维优应用纳管的线路id
    SELECT
        line_id
    FROM
        cfg_highspeedrail_platform
    GROUP BY line_id
) A2
ON m100.lineid = A2.line_id
left join
(
    select
        distinct
        provincecode
        ,province_name
        ,city_id
        ,city_name
    from
        cfg_district
) cfg
on m100.citycode = cfg.city_id
;

-- 4G小区汇总到路段指标
cache table dm_lte_cel as
select
    lineid
    ,t2.section_id_1km
    ,count(distinct t1.cellkey) as cell_cnt_4g
    ,count(distinct t1.cellkey)-count(distinct case when master_operators='联通承建' then t1.cellkey else null end) as cell_cnt_4g_ctcc
    ,count(distinct case when master_operators='联通承建' then t1.cellkey else null end) as cell_cnt_4g_cucc
    ,sum(ul_mos_sum)/sum(ul_mos_nonvoid_cnt) as ul_mos_avg_4g
    ,sum(dl_mos_sum)/sum(dl_mos_nonvoid_cnt) as dl_mos_avg_4g
    ,avg(cell_servtime_rate) as cell_servtime_rate_4g
    ,sum(pdcp_sdulosspktul_qci1)/sum(pdcp_sdupktul_qci1) as pdcp_sdulosspktul_qci1_rate
    ,sum(pdcp_sdulosspktdl_qci1)/sum(pdcp_sdupktdl_qci1) as pdcp_sdulosspktdl_qci1_rate
    ,sum((pdcp_sduoctul - pdcp_sdutailflowul)*8)/sum(( pdcp_thrptimeul - pdcp_tailtimeul)/1000) as uexp_meanspeedul_4g
    ,sum((pdcp_sduoctdl - pdcp_sdutailflowdl)*8)/sum(( pdcp_thrptimedl - pdcp_tailtimedl)/1000) as uexp_meanspeeddl_4g
    ,sum(erab_abnormrel_qci1) as erab_abnormrel_qci1
    ,sum(erab_normrel_qci1) as erab_normrel_qci1
    ,sum(erab_abnormrel_qci1)/sum(erab_abnormrel_qci1 + erab_normrel_qci1) as erab_drop_qci1_rate
    ,nvl(sum(NVL(rrc_succconnestab_ue,0) + NVL(rrc_succconnestab_net,0)) / sum(NVL(rrc_attconnestab_ue,0) + NVL(rrc_attconnestab_net,0)),1) * nvl(sum(s1sig_succconnestab) / sum(s1sig_attconnestab),1) * nvl(sum(NVL(erab_initsuccestab_qci1,0) + NVL(erab_addsuccestab_qci1,0)) / sum(NVL(erab_initattestab_qci1,0) + NVL(erab_addattestab_qci1,0)),1) as access_success_qci1_rate
    ,sum(puschprbtotmeandl)/sum(prb_dl_avail) as prb_use_dl_rate_4g
    ,sum(cqi_good_cnt)/sum(cqi_total_cnt) as cqi_good_rate_4g
    ,sum(erab_abnormrel)/sum(NVL(erab_abnormrel,0) + NVL(erab_normrel,0)) as erab_drop_rate
    ,sum(NVL(rrc_succconnestab_ue,0) + NVL(rrc_succconnestab_net,0))/sum(NVL(rrc_attconnestab_ue,0) + NVL(rrc_attconnestab_net,0)) as rrc_connsucc_rate_4g
    ,nvl(sum(NVL(rrc_succconnestab_ue,0) + NVL(rrc_succconnestab_net,0)) / sum(NVL(rrc_attconnestab_ue,0) + NVL(rrc_attconnestab_net,0)),1) * nvl(sum(s1sig_succconnestab) / sum(s1sig_attconnestab),1) * nvl(sum(NVL(erab_initsuccestab,0) + NVL(erab_addsuccestab,0)) / sum(NVL(erab_initattestab,0) + NVL(erab_addattestab,0)),1) as access_success_rate_4g
    ,sum(flux_web) flux_web
    ,sum(flux_video) flux_video
    ,first(p_date) p_date
from
(
    -- 之前是select *   需确认字段是否正确
    select
        lineid
        ,cellkey
        ,master_operators
        ,rsrpcount
        ,avgrsrp
        ,mod3interfer_mrcount
        ,weakcover_mrcount
        ,overlap_mrcount
        ,mod3interfer_mrratio
        ,weakcover_mrratio
        ,overlap_mrratio
        ,rsrpgoodcount_110
        ,rsrpgoodcount_105
        ,rsrpgoodcount_110_rate
        ,rsrpgoodcount_105_rate
        ,flux_web
        ,flux_video
        ,ul_mos_sum
        ,ul_mos_nonvoid_cnt
        ,ul_mos_avg
        ,ul_mos35_cnt
        ,ul_mos35_cnt_rate
        ,dl_mos_sum
        ,dl_mos_nonvoid_cnt
        ,dl_mos_avg
        ,dl_mos35_cnt
        ,dl_mos_35cnt_rate
        ,volte_call_req
        ,volte_call_delay
        ,cell_servtime_rate
        ,pdcp_sdulosspktul_qci1
        ,pdcp_sdupktul_qci1
        ,pdcp_sdulosspktul_qci1_rate
        ,pdcp_sdulosspktdl_qci1
        ,pdcp_sdupktdl_qci1
        ,pdcp_sdulosspktdl_qci1_rate
        ,prb_dl_avail
        ,puschprbtotmeandl
        ,puschprbtotmeandl_date
        ,rrc_attconnestab_ue
        ,rrc_succconnestab_ue
        ,rrc_attconnestab_net
        ,rrc_succconnestab_net
        ,rrc_succconnestab_rate
        ,s1sig_attconnestab
        ,s1sig_succconnestab
        ,s1sig_succconnestab_rate
        ,erab_initattestab
        ,erab_initsuccestab
        ,erab_addattestab
        ,erab_addsuccestab
        ,erab_succestab_rate
        ,access_success_rate
        ,rrc_attconnreestab
        ,rrc_succconnreestab
        ,rrc_succconnreestab_rate
        ,erab_abnormrel
        ,erab_normrel
        ,erab_drop_rate
        ,pdcp_sduoctul
        ,pdcp_sdutailflowul
        ,pdcp_thrptimeul
        ,pdcp_tailtimeul
        ,uexp_meanspeedul
        ,pdcp_sduoctdl
        ,pdcp_sdutailflowdl
        ,pdcp_thrptimedl
        ,pdcp_tailtimedl
        ,uexp_meanspeeddl
        ,flux_pm
        ,erab_initattestab_qci1
        ,erab_initsuccestab_qci1
        ,erab_addattestab_qci1
        ,erab_addsuccestab_qci1
        ,erab_succestab_rate_qci1
        ,access_success_rate_qci1
        ,erab_abnormrel_qci1
        ,erab_normrel_qci1
        ,erab_drop_rate_qci1
        ,cqi_good_cnt
        ,cqi_total_cnt
        ,cqi_good_rate
        ,ho_succoutintraenb
        ,ho_succouts1
        ,ho_succoutx2
        ,ho_attoutintraenb
        ,ho_attouts1
        ,ho_attoutx2
        ,ho_succ_rate
        ,p_date
    from
        dm_lte_highspeedrail_cel_index_d
    where p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
        and p_date = '$dm_highspeedrail_section_index_d.p_date$'
        -- select
        -- *
    -- from
    -- dm_lte_highspeedrail_cel_index_d
    -- where
    -- p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
    -- and p_date = '$dm_highspeedrail_section_index_d.p_date$'
) t1
inner join
(
    -- 回填路段id
    select
        cellkey
        ,section_id_1km
        ,lineid AS line_id
    from
        -- 切换数据源
        dm_highrail_user_line_lte_all_cell_use_d
    --添加省分区过滤条件
    WHERE p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
        AND p_date = '$dm_highspeedrail_section_index_d.p_date$'
        --添加是否场景小区过滤条件
        AND valid_flag = 1
-- dm_highrail_user_line_lte_all_cell_d
-- where
-- p_date = '$dm_highspeedrail_section_index_d.p_date$'
) t2
on t1.cellkey = t2.cellkey
    AND t1.lineid = t2.line_id
group by
    lineid
    ,t2.section_id_1km
;

-- 5G小区汇总到路段指标
cache table dm_nr_cel as
select
    lineid
    ,t2.section_id_1km
    ,count(distinct t1.cellkey) as cell_cnt_5g
    ,count(distinct t1.cellkey)-count(distinct case when master_operators='联通承建' then t1.cellkey else null end) as cell_cnt_5g_ctcc
    ,count(distinct case when master_operators='联通承建' then t1.cellkey else null end) as cell_cnt_5g_cucc
    ,nvl(sum(qos_initialestabsucc)/sum(qos_initialestabreq),1)*nvl(sum(ng_connsucc)/sum(ng_connatt),1)*nvl(sum(rrc_connsucc)/sum(rrc_connreq),1) as access_success_rate_5g
    ,sum((rlc_txbytesdl - rlc_lasttxbytesdl)*8) / sum(rlc_txtimedl_exceptlastslot/1000) as uexp_meanspeeddl_5g
    ,sum(cqi_good_cnt)/sum(cqi_total_cnt) as cqi_good_rate_5g
    ,1-sum(ue_normalcontextrelease)/sum(ue_contextrelease) as uecntx_drop_rate_5g
    ,sum(prb_useddl)/sum(prb_availdl) as prb_use_dl_rate_5g
    ,sum(flux_web) flux_web
    ,sum(flux_video) flux_video
    ,sum(rrc_connsucc)/sum(rrc_connreq) rrc_connsucc_rate_5g
from
(
    -- 之前是select *   需确认字段是否正确
    select
        lineid
        ,cellkey
        ,master_operators
        ,rsrpcount
        ,avgrsrp
        ,mod3interfer_mrcount
        ,weakcover_mrcount
        ,overlap_mrcount
        ,mod3interfer_mrratio
        ,weakcover_mrratio
        ,overlap_mrratio
        ,rsrpgoodcount_110
        ,rsrpgoodcount_105
        ,rsrpgoodcount_110_rate
        ,rsrpgoodcount_105_rate
        ,flux_web
        ,flux_video
        ,rrc_connreq
        ,rrc_connsucc
        ,rrc_connsucc_rate
        ,qos_initialestabsucc
        ,qos_initialestabreq
        ,ng_connsucc
        ,ng_connatt
        ,access_success_rate
        ,ue_normalcontextrelease
        ,ue_contextrelease
        ,uecntx_drop_cnt
        ,uecntx_drop_rate
        ,ho_succintragnb
        ,ho_succbyxn
        ,ho_succbyng
        ,ho_attintragnb
        ,ho_attbyxn
        ,ho_attbyng
        ,ho_succ_rate
        ,rrc_connreestabreq
        ,rrc_connreestabsucc
        ,rrc_connreestabsucc_rate
        ,vonr_ho_atttovolte
        ,vonr_ho_succtovolte
        ,vonr_ho_succtovolte_rate
        ,vonr_rtp_rxpktul
        ,vonr_rtp_losspktul
        ,vonr_rtp_losspktul_rate
        ,vonr_rtp_rxpktdl
        ,vonr_rtp_losspktdl
        ,vonr_rtp_losspktdl_rate
        ,vonr_connreq
        ,vonr_connsucc
        ,vonr_connsucc_rate
        ,vonr_releasesum
        ,vonr_normalrelease
        ,vonr_drop_rate
        ,rlc_rxbytesul
        ,rlc_lastrxbytesul
        ,rlc_rxtimeul_exceptlastslot
        ,uexp_meanspeedul
        ,rlc_txbytesdl
        ,rlc_lasttxbytesdl
        ,rlc_txtimedl_exceptlastslot
        ,uexp_meanspeeddl
        ,flux_pm
        ,cqi_good_cnt
        ,cqi_total_cnt
        ,cqi_good_rate
        ,prb_useddl
        ,prb_availdl
        ,prb_use_dl_rate
        ,phy_meannlperprbul
    from
        dm_nr_highspeedrail_cel_index_d
    where p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
        and p_date = '$dm_highspeedrail_section_index_d.p_date$'
        -- select
        -- *
    -- from
    -- dm_nr_highspeedrail_cel_index_d
    -- where
    -- p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
    -- and p_date = '$dm_highspeedrail_section_index_d.p_date$'
) t1
inner join
(
    -- 回填路段id
    select
        cellkey
        ,section_id_1km
        ,lineid AS line_id
    from
        -- 切换数据源
        dm_highrail_user_line_nr_all_cell_use_d
    --添加省分区过滤条件
    WHERE p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
        AND p_date = '$dm_highspeedrail_section_index_d.p_date$'
        --添加是否场景小区过滤条件
        AND valid_flag = 1
-- dm_highrail_user_line_nr_all_cell_d
-- where
-- p_date = '$dm_highspeedrail_section_index_d.p_date$'
) t2
on t1.cellkey = t2.cellkey
    AND t1.lineid = t2.line_id
group by
    lineid
    ,t2.section_id_1km
;


-- 规划站数据
cache table dm_station as
select
    line_id AS lineid
    ,FLOOR(first_section_id / 10)  as section_id_1km
    ,count(distinct case when net_type='4G' and indoor_flag=1 then station_id else null end) as plan_stations_indoor_cnt_4g_300
    ,count(distinct case when net_type='4G' and indoor_flag=0 then station_id else null end) as plan_stations_outdoor_cnt_4g_300
    ,count(distinct case when net_type='5G' and indoor_flag=1 then station_id else null end) as plan_stations_indoor_cnt_5g_300
    ,count(distinct case when net_type='5G' and indoor_flag=0 then station_id else null end) as plan_stations_outdoor_cnt_5g_300
    ,count(distinct case when net_type='4G' then station_id else null end) as plan_stations_cnt_4g
    ,count(distinct case when net_type='5G' then station_id else null end) as plan_stations_cnt_5g
from
    dm_highspeedrail_station_index_m
where p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
    AND p_year = substr(ADD_MONTHS('$dm_highspeedrail_section_index_d.p_date$',-1),1, 4)
    and p_month =  CAST(substr(ADD_MONTHS('$dm_highspeedrail_section_index_d.p_date$',-1),6, 2) AS INT)
group by
    line_id
    ,FLOOR(first_section_id / 10)
;

-- 4G覆盖
cache table aggr_lte_sec as
select
    line_id AS lineid
    ,FLOOR(section_id / 10)  as section_id_1km
    ,sum(mr_nums)/7 as rsrpcount_4g
    ,sum(mr_nums*avg_rsrp)/sum(mr_nums) as avgrsrp_4g
    ,sum(rsrpgoodcount_105) as rsrpgoodcount_4g_105
    ,sum(rsrpgoodcount_110) as rsrpgoodcount_4g_110
    ,sum(rsrpgoodcount_105)/sum(mr_nums) as rsrpgoodcount_rate_4g_105
    ,sum(rsrpgoodcount_110)/sum(mr_nums) as rsrpgoodcount_rate_4g_110
    ,sum(weakcover_mr_nums)/sum(mr_nums) as weakcover_mrratio_4g
    ,sum(overlap_mr_nums)/sum(mr_nums) as overlap_mrratio_4g
    ,sum(mod3_mr_nums)/sum(mr_nums) as mod3interfer_mrratio_4g
    ,sum(is_section_coverage_110) / COUNT(DISTINCT line_id,section_id) as section_1km_coverage_4g_110
    ,sum(is_section_coverage_105) / COUNT(DISTINCT line_id,section_id) as section_1km_coverage_4g_105
    ,sum(mr_nums) mr_nums
from
    aggr_highrail_user_line_section_lte_index_d
where p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
    and p_date = '$dm_highspeedrail_section_index_d.p_date$'
group by
    line_id
    ,FLOOR(section_id / 10)
;

-- 5G覆盖
cache table aggr_nr_sec as
select
    line_id AS lineid
    ,FLOOR(section_id / 10)  as section_id_1km
    ,sum(mr_nums)/7 as rsrpcount_5g
    ,sum(mr_nums*avg_rsrp)/sum(mr_nums) as avgrsrp_5g
    ,sum(rsrpgoodcount_105) as rsrpgoodcount_5g_105
    ,sum(rsrpgoodcount_110) as rsrpgoodcount_5g_110
    ,sum(rsrpgoodcount_105)/sum(mr_nums) as rsrpgoodcount_rate_5g_105
    ,sum(rsrpgoodcount_110)/sum(mr_nums) as rsrpgoodcount_rate_5g_110
    ,sum(mr_nums - rsrpgoodcount_105)/sum(mr_nums) as weakcover_mrratio_5g
    ,sum(overlap_mr_nums)/sum(mr_nums) as overlap_mrratio_5g
    ,sum(mod3_mr_nums)/sum(mr_nums) as mod3interfer_mrratio_5g
    ,sum(is_section_coverage_110) / COUNT(DISTINCT line_id,section_id) as section_1km_coverage_5g_110
    ,sum(is_section_coverage_105) / COUNT(DISTINCT line_id,section_id) as section_1km_coverage_5g_105
    ,sum(mr_nums) mr_nums
from
    aggr_highrail_user_line_section_nr_index_d
where p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
    and p_date = '$dm_highspeedrail_section_index_d.p_date$'
group by
    line_id
    ,FLOOR(section_id / 10)
;

-- 4G分频段覆盖
cache table aggr_freq_lte AS
select
    line_id AS lineid
    ,FLOOR(section_id / 10) section_id_1km
    ,sum(if(freq = '800M', mr_nums, 0)) / sum(mr_nums)  rsrpcount_4g_rate_800
    ,sum(if(freq = '1.8G', mr_nums, 0)) / sum(mr_nums) rsrpcount_4g_rate_1800
    ,sum(if(freq = '2.1G', mr_nums, 0)) / sum(mr_nums) rsrpcount_4g_rate_2100
from
    aggr_highrail_user_line_section_grid_lte_index_d
where p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
    and p_date = '$dm_highspeedrail_section_index_d.p_date$'
    and freq!='total'
    and freq!='TOTAL'
group BY
    line_id
    ,FLOOR(section_id / 10)
;

-- 5G分频段覆盖
cache table aggr_freq_nr
select
    line_id AS lineid
    ,FLOOR(section_id / 10) section_id_1km
    ,sum(if(freq = '2.1G', mr_nums, 0)) / sum(mr_nums)  rsrpcount_5g_rate_2100
    ,sum(if(freq = '3.5G', mr_nums, 0)) / sum(mr_nums) rsrpcount_5g_rate_3500
from
    aggr_highrail_user_line_section_grid_nr_index_d
where p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
    and p_date = '$dm_highspeedrail_section_index_d.p_date$'
    and freq!='total'
    and freq!='TOTAL'
group BY
    line_id
    ,FLOOR(section_id / 10)
;

INSERT OVERWRITE TABLE dm_highspeedrail_section_index_d
partition(
    p_provincecode = $dm_highspeedrail_section_index_d.p_provincecode$
    ,p_date = '$dm_highspeedrail_section_index_d.p_date$'
)
SELECT
    '$dm_highspeedrail_section_index_d.p_date$' day
    ,m100_withcity.lineid
    ,line_name
    ,provincecode
    ,province_name
    ,citycode
    ,city_name
    ,m100_withcity.section_id_1km
    ,section_name_1km
    ,cell_cnt_4g
    ,cell_cnt_4g_ctcc
    ,cell_cnt_4g_cucc
    ,cell_cnt_5g
    ,cell_cnt_5g_ctcc
    ,cell_cnt_5g_cucc
    ,plan_stations_indoor_cnt_4g_300
    ,plan_stations_outdoor_cnt_4g_300
    ,plan_stations_indoor_cnt_5g_300
    ,plan_stations_outdoor_cnt_5g_300
    ,plan_stations_cnt_4g
    ,plan_stations_cnt_5g
    ,rsrpcount_4g
    ,avgrsrp_4g
    ,section_1km_coverage_4g_110
    ,section_1km_coverage_4g_105
    ,aggr_lte_sec.mr_nums/(nvl(aggr_lte_sec.mr_nums,0)+nvl(aggr_nr_sec.mr_nums,0)) as rsrpcount_4g_rate
    ,rsrpcount_4g_rate_800
    ,rsrpcount_4g_rate_1800
    ,rsrpcount_4g_rate_2100
    ,rsrpgoodcount_4g_105
    ,rsrpgoodcount_4g_110
    ,rsrpgoodcount_rate_4g_105
    ,rsrpgoodcount_rate_4g_110
    ,weakcover_mrratio_4g
    ,overlap_mrratio_4g
    ,mod3interfer_mrratio_4g
    ,rsrpcount_5g
    ,avgrsrp_5g
    ,section_1km_coverage_5g_110
    ,section_1km_coverage_5g_105
    ,aggr_nr_sec.mr_nums/(nvl(aggr_nr_sec.mr_nums,0)+nvl(aggr_nr_sec.mr_nums,0)) rsrpcount_5g_rate
    ,rsrpcount_5g_rate_2100
    ,rsrpcount_5g_rate_3500
    ,rsrpgoodcount_5g_105
    ,rsrpgoodcount_5g_110
    ,rsrpgoodcount_rate_5g_105
    ,rsrpgoodcount_rate_5g_110
    ,weakcover_mrratio_5g
    ,overlap_mrratio_5g
    ,mod3interfer_mrratio_5g
    ,(nvl(dm_lte_cel.flux_web,0) + nvl(dm_lte_cel.flux_video,0)) / (nvl(dm_lte_cel.flux_web,0) + nvl(dm_lte_cel.flux_video,0) + nvl(dm_nr_cel.flux_web,0) + nvl(dm_nr_cel.flux_video,0))
    ,1-(nvl(dm_lte_cel.flux_web,0) + nvl(dm_lte_cel.flux_video,0)) / (nvl(dm_lte_cel.flux_web,0) + nvl(dm_lte_cel.flux_video,0) + nvl(dm_nr_cel.flux_web,0) + nvl(dm_nr_cel.flux_video,0))
    ,ul_mos_avg_4g
    ,dl_mos_avg_4g
    ,cell_servtime_rate_4g
    ,pdcp_sdulosspktul_qci1_rate
    ,pdcp_sdulosspktdl_qci1_rate
    ,uexp_meanspeedul_4g
    ,uexp_meanspeeddl_4g
    ,erab_abnormrel_qci1
    ,erab_normrel_qci1
    ,erab_drop_qci1_rate
    ,access_success_qci1_rate
    ,prb_use_dl_rate_4g
    ,cqi_good_rate_4g
    ,erab_drop_rate
    ,rrc_connsucc_rate_4g
    ,access_success_rate_4g
    ,rrc_connsucc_rate_5g
    ,access_success_rate_5g
    ,uexp_meanspeeddl_5g
    ,cqi_good_rate_5g
    ,uecntx_drop_rate_5g
    ,prb_use_dl_rate_5g
    ,if(rrc_connsucc_rate_4g<=0.9 or (avgrsrp_4g<-110 and section_1km_coverage_4g_110<0.75), 1, 0) is_bad_section_4g
    ,case when avgrsrp_4g<-110 and section_1km_coverage_4g_110<0.75 then 1 else 0 end as is_cover_bad_section_4g
    ,case when rrc_connsucc_rate_4g<=0.9 then 1 else 0 end as is_quality_bad_section_4g
    ,null is_perception_bad_section_4g
    ,if(rrc_connsucc_rate_5g<=0.9 or (avgrsrp_5g<-105 and section_1km_coverage_5g_105<0.75), 1, 0) is_bad_section_5g----------------
    ,case when avgrsrp_5g<-105 and section_1km_coverage_5g_105<0.75 then 1 else 0 end as is_cover_bad_section_5g
    ,case when rrc_connsucc_rate_5g<=0.9 then 1 else 0 end as is_quality_bad_section_5g
    ,null is_perception_bad_section_5g
FROM
    m100_withcity
left join
    dm_lte_cel
on m100_withcity.section_id_1km = dm_lte_cel.section_id_1km
    AND m100_withcity.lineid = dm_lte_cel.lineid
left join
    dm_nr_cel
on m100_withcity.section_id_1km = dm_nr_cel.section_id_1km
    AND m100_withcity.lineid = dm_nr_cel.lineid
left join
    dm_station
on m100_withcity.section_id_1km = dm_station.section_id_1km
    AND m100_withcity.lineid = dm_station.lineid
left join
    aggr_lte_sec
on m100_withcity.section_id_1km = aggr_lte_sec.section_id_1km
    AND m100_withcity.lineid = aggr_lte_sec.lineid
left join
    aggr_nr_sec
on m100_withcity.section_id_1km = aggr_nr_sec.section_id_1km
    AND m100_withcity.lineid = aggr_nr_sec.lineid
left join
    aggr_freq_lte
on m100_withcity.section_id_1km = aggr_freq_lte.section_id_1km
    AND m100_withcity.lineid = aggr_freq_lte.lineid
left join
    aggr_freq_nr
on m100_withcity.section_id_1km = aggr_freq_nr.section_id_1km
    AND m100_withcity.lineid = aggr_freq_nr.lineid
;
