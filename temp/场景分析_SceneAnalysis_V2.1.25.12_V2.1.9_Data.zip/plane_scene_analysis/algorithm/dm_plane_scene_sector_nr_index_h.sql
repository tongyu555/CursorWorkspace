-- 20250701updateby : goupengcheng 10207
-- algorithm : 更换小区输入表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

INSERT OVERWRITE TABLE dm_plane_scene_sector_nr_index_h
PARTITION (
    p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
    ,p_date = '$dm_plane_scene_sector_nr_index_h.p_date$'
    ,p_hour = $dm_plane_scene_sector_nr_index_h.p_hour$
)
SELECT
    '$dm_plane_scene_sector_nr_index_h.p_date$'         AS day
    ,$dm_plane_scene_sector_nr_index_h.p_hour$           AS hour
    ,$dm_plane_scene_sector_nr_index_h.p_provincecode$   AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,districtcode
    ,district_name
    ,scene_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,'5G'                                                AS net_type
    ,gnbid
    ,cellid
    ,t1.cellkey                                          AS cellkey
    ,cellname
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,height
    ,indoor_flag
    ,azimuth
    ,vendor
    ,bandwidth
    ,cover_rate
    ,is_inside
    ,master_operators
    ,prb_usedul
    ,prb_availul
    ,prb_usedul_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_useddl_rate
    ,flux_ul * cover_rate                                AS flux_ul
    ,flux_dl * cover_rate                                AS flux_dl
    ,flux * cover_rate                                   AS flux
    ,rrc_connreq
    ,rrc_connsucc
    ,rrc_connsucc_rate
    ,ng_connatt
    ,ng_connsucc
    ,ng_connsucc_rate
    ,qos_initialestabreq
    ,qos_initialestabsucc
    ,qos_initialestabsucc_rate
    ,NVL(rrc_connsucc_rate,1) * NVL(ng_connsucc_rate,1) * NVL(qos_initialestabsucc_rate,1)   AS access_success_rate
    ,ue_contextrelease
    ,ue_normalcontextrelease
    ,uecntx_drop_rate
    ,rlc_txbytesdl
    ,rlc_lasttxbytesdl
    ,rlc_txtimedl_exceptlastslot
    ,uexp_meanspeeddl
    ,vonr_rtp_rxpktul
    ,vonr_rtp_losspktul
    ,vonr_rtp_losspktul_rate
    ,vonr_rtp_rxpktdl
    ,vonr_rtp_losspktdl
    ,vonr_rtp_losspktdl_rate
    ,vonr_ho_atttovolte
    ,vonr_ho_succtovolte
    ,vonr_ho_succtovolte_rate
    ,httpwebrspcount
    ,httpwebreqcount
    ,httpwebrsprate
    ,httpwebdspdelay
    ,httpwebscreendelay
    ,videoplaysuccesscount
    ,videoplayrequestcount
    ,videothroughput
    ,videoplaytime_without_halt_sum
    ,videoplayhaltcount
    ,kqi_videoplayhaltcountpermin
    ,times_excellentdownlink
    ,times_inferiordownlink
    ,times_welldownlink
    ,times_excellentstallfrequ
    ,times_inferiorstallfrequ
    ,times_wellstallfrequ
    ,messagesucccount
    ,messagereqcount
    ,messagesucc_rate
    ,gameinteractdelay
    ,rrc_userconnmean
    ,rrc_userconnmax
    ,ho_attsamefreq
    ,ho_succsamefreq
    ,ho_succsamefreq_rate
    ,ho_attdifffreq
    ,ho_succdifffreq
    ,ho_succdifffreq_rate
    ,ho_attfromgutrantoeutran
    ,ho_succfromgutrantoeutran
    ,CASE WHEN ho_succfromgutrantoeutran_rate > 1 THEN 1 ELSE ho_succfromgutrantoeutran_rate END AS ho_succfromgutrantoeutran_rate
    ,scan_pay_suc_cnt
    ,scan_pay_req_cnt
    ,scan_pay_suc_rate
    ,scan_pay_tcpsetupackdelay
FROM
(
    SELECT
        provincecode
       ,province_name
       ,citycode
       ,city_name
       ,districtcode
       ,district_name
       ,scene_type
       ,scene_subclass_id
       ,scene_subclass_name
       ,enbid   AS gnbid
       ,cellid
       ,cellkey
       ,cellname
       ,cell_lon
       ,cell_lat
       ,freq
       ,pci
       ,height
       ,indoor_flag
       ,azimuth
       ,vendor
       ,bandwidth
       ,cover_rate
       ,is_inside
       ,master_operators
    FROM
        cfg_plane_scene_sector_nr_rel_use_d  -- 修改输入表
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
        AND p_date = '$cfg_plane_scene_sector_nr_rel_use_d.p_date$'  -- 修改输入表
        AND valid_flag = 1 -- 添加过滤条件
        AND scene_type = 5
) t1
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])   AS cellkey
       ,SUM(prb_usedul)                                                                 AS prb_usedul
       ,SUM(prb_availul)                                                                AS prb_availul
       ,SUM(prb_usedul) / SUM(prb_availul)                                              AS prb_usedul_rate
       ,SUM(prb_useddl)                                                                 AS prb_useddl
       ,SUM(prb_availdl)                                                                AS prb_availdl
       ,SUM(prb_useddl) / SUM(prb_availdl)                                              AS prb_useddl_rate
    FROM
        fact_pm_nr_celldu_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_nr_index_h.p_hour$
    GROUP BY CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])
) t2
ON t1.cellkey = t2.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(cel_id,'-')[1],'_',SPLIT(cel_id,'-')[2])                                                   AS cellkey
       ,SUM(NVL(rlc_rxbytesul,0) + NVL(nsa_rlc_rxbytesul,0)) / 1024                                                    AS flux_ul
       ,SUM(NVL(rlc_txbytesdl,0) + NVL(nsa_rlc_txbytesdl,0)) / 1024                                                   AS flux_dl
       ,SUM(NVL(rlc_rxbytesul,0) + NVL(nsa_rlc_rxbytesul,0) + NVL(rlc_txbytesdl,0) + NVL(nsa_rlc_txbytesdl,0)) /1024  AS flux
       ,SUM(rlc_txbytesdl)                                                                                      AS rlc_txbytesdl
       ,SUM(rlc_lasttxbytesdl)                                                                                  AS rlc_lasttxbytesdl
       ,SUM(rlc_txtimedl_exceptlastslot)                                                                        AS rlc_txtimedl_exceptlastslot
       ,(SUM(rlc_txbytesdl - rlc_lasttxbytesdl) * 8) / (SUM(rlc_txtimedl_exceptlastslot) / 1000)                AS uexp_meanspeeddl
    FROM
        fact_pm_nr_lceldu_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_nr_index_h.p_hour$
        AND SPLIT(cel_id,'-')[0] = '46011'
    GROUP BY cel_id
) t3
ON t1.cellkey = t3.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])   AS cellkey
       ,SUM(CASE WHEN rrc_connreq < rrc_connsucc THEN rrc_connsucc ELSE rrc_connreq END)                            AS rrc_connreq
       ,SUM(rrc_connsucc)                                                                                           AS rrc_connsucc
       ,NVL(SUM(rrc_connsucc)/SUM(CASE WHEN rrc_connreq < rrc_connsucc THEN rrc_connsucc ELSE rrc_connreq END),1)   AS rrc_connsucc_rate

    FROM
        fact_pm_nr_cellcu_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_nr_index_h.p_hour$
    GROUP BY CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])
) t4
ON t1.cellkey = t4.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(cel_id,'-')[1],'_',SPLIT(cel_id,'-')[2])   AS cellkey
       ,SUM(CASE WHEN ng_connatt < ng_connsucc THEN ng_connsucc ELSE ng_connatt END)                                                                        AS ng_connatt
       ,SUM(ng_connsucc)                                                                                                                                    AS ng_connsucc
       ,NVL(SUM(ng_connsucc)/SUM(CASE WHEN ng_connatt < ng_connsucc THEN ng_connsucc ELSE ng_connatt END),1)                                                AS ng_connsucc_rate
       ,SUM(CASE WHEN qos_initialestabreq < qos_initialestabsucc THEN qos_initialestabsucc ELSE qos_initialestabreq END)                                    AS qos_initialestabreq
       ,SUM(qos_initialestabsucc)                                                                                                                           AS qos_initialestabsucc
       ,NVL(SUM(qos_initialestabsucc)/SUM(CASE WHEN qos_initialestabreq < qos_initialestabsucc THEN qos_initialestabsucc ELSE qos_initialestabreq END),1)   AS qos_initialestabsucc_rate
       ,SUM(ue_contextrelease)                                                                                                                              AS ue_contextrelease
       ,SUM(ue_normalcontextrelease)                                                                                                                        AS ue_normalcontextrelease
       ,NVL(SUM(ue_contextrelease - ue_normalcontextrelease)/SUM(ue_contextrelease),0)                                                                      AS uecntx_drop_rate
       ,SUM(vonr_rtp_rxpktul)                                                                                                                               AS vonr_rtp_rxpktul
       ,SUM(vonr_rtp_losspktul)                                                                                                                             AS vonr_rtp_losspktul
       ,SUM(vonr_rtp_losspktul)/SUM(vonr_rtp_rxpktul)                                                                                                       AS vonr_rtp_losspktul_rate
       ,SUM(vonr_rtp_rxpktdl)                                                                                                                               AS vonr_rtp_rxpktdl
       ,SUM(vonr_rtp_losspktdl)                                                                                                                             AS vonr_rtp_losspktdl
       ,SUM(vonr_rtp_losspktdl)/SUM(vonr_rtp_rxpktdl)                                                                                                       AS vonr_rtp_losspktdl_rate
       ,AVG(rrc_connmean)                                                                                                                                   AS rrc_userconnmean
       ,MAX(rrc_connmax)                                                                                                                                    AS rrc_userconnmax
       ,SUM(ho_attsamefreq)                                                                                                                                 AS ho_attsamefreq
       ,SUM(ho_succsamefreq)                                                                                                                                AS ho_succsamefreq
       ,SUM(ho_succsamefreq) / SUM(ho_succsamefreq)                                                                                                         AS ho_succsamefreq_rate
       ,SUM(ho_attdifffreq)                                                                                                                                 AS ho_attdifffreq
       ,SUM(ho_succdifffreq)                                                                                                                                AS ho_succdifffreq
       ,SUM(ho_succdifffreq) / SUM(ho_attdifffreq)                                                                                                          AS ho_succdifffreq_rate
--       ,SUM(ho_attfromgutrantoeutran)                                                                                                                       AS ho_attfromgutrantoeutran
       ,CASE WHEN SUM(ho_attfromgutrantoeutran) < SUM(ho_succfromgutrantoeutran) THEN SUM(ho_succfromgutrantoeutran) ELSE SUM(ho_attfromgutrantoeutran) end AS ho_attfromgutrantoeutran
       ,SUM(ho_succfromgutrantoeutran)                                                                                                                      AS ho_succfromgutrantoeutran
       ,SUM(ho_succfromgutrantoeutran) / SUM(ho_attfromgutrantoeutran)                                                                                      AS ho_succfromgutrantoeutran_rate
       ,sum(vonr_ho_atttovolte)                                                                                                                             AS vonr_ho_atttovolte
       ,sum(vonr_ho_succtovolte)                                                                                                                            AS vonr_ho_succtovolte
       ,sum(vonr_ho_succtovolte)/sum(vonr_ho_atttovolte)                                                                                                    AS vonr_ho_succtovolte_rate
    FROM
        fact_pm_nr_lcelcu_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_nr_index_h.p_hour$
        AND SPLIT(cel_id,'-')[0] = '46011'
    GROUP BY cel_id
) t5
ON t1.cellkey = t5.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,sum(case when servicetype=88888888 then httpwebrspcount else 0 end)                                                                             AS scan_pay_suc_cnt
       ,sum(case when servicetype=88888888 then httpwebreqcount else 0 end)                                                                             AS scan_pay_req_cnt
       ,sum(case when servicetype=88888888 then httpwebrspcount else 0 end)/sum(case when servicetype=88888888 then httpwebreqcount else 0 end)         AS scan_pay_suc_rate
       ,sum(case when servicetype=88888888 then tcpsetupackdelay_avg*httpwebreqcount else 0 end)/sum(case when servicetype=88888888 then httpwebreqcount else 0 end)    AS scan_pay_tcpsetupackdelay
    FROM
        aggr_5g_im_appcel_e2e_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_nr_index_h.p_hour$
        AND interface = 100
    GROUP BY
        nodebid
       ,cellid
) t6
ON t1.cellkey = t6.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,sum(httpwebrspcount)                                                AS httpwebrspcount
       ,sum(httpwebreqcount)                                                AS httpwebreqcount
       ,sum(httpwebrspcount)/sum(httpwebreqcount)                           AS httpwebrsprate
       ,sum(httpwebdspdelay_avg*httpwebrspcount)/sum(httpwebrspcount)       AS httpwebdspdelay
       ,sum(httpwebscreendelay_avg*httpwebrspcount)/sum(httpwebrspcount)    AS httpwebscreendelay
    FROM
        aggr_5g_web_cel_e2e_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_nr_index_h.p_hour$
        AND interface = 100
    GROUP BY
        nodebid
       ,cellid
) t7
ON t1.cellkey = t7.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,sum(videoplaysuccesscount)                                                                                                          AS videoplaysuccesscount
       ,sum(videoplayrequestcount)                                                                                                          AS videoplayrequestcount
       ,sum(videothroughput*videoplaysuccesscount)/sum(videoplaysuccesscount) / 1024                                                               AS videothroughput
       ,sum(videoplaytime_without_halt_sum)                                                                                                 AS videoplaytime_without_halt_sum
       ,sum(videoplayhaltcount)                                                                                                             AS videoplayhaltcount
       ,case when sum(videoplaytime_without_halt_sum) !=0 then sum(videoplayhaltcount)*60000/sum(videoplaytime_without_halt_sum) else 0 end AS kqi_videoplayhaltcountpermin
       ,sum(times_excellentdownlink)                                                                                                        AS times_excellentdownlink
       ,sum(times_excellentdownlink)                                                                                                        AS times_inferiordownlink
       ,sum(times_welldownlink)                                                                                                             AS times_welldownlink
       ,sum(times_excellentstallfrequ)                                                                                                      AS times_excellentstallfrequ
       ,sum(times_inferiorstallfrequ)                                                                                                       AS times_inferiorstallfrequ
       ,sum(times_wellstallfrequ)                                                                                                           AS times_wellstallfrequ
    FROM
        aggr_5g_video_cel_e2e_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_nr_index_h.p_hour$
        AND interface = 100
    GROUP BY
        nodebid
       ,cellid
) t8
ON t1.cellkey = t8.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,sum(times_excellentsentrate)                                                                                                AS messagesucccount
       ,sum(nvl(times_excellentsentrate,0)+nvl(times_inferiorsentrate,0)+nvl(times_wellsentrate,0))                                 AS messagereqcount
       ,sum(times_excellentsentrate)/sum(nvl(times_excellentsentrate,0)+nvl(times_inferiorsentrate,0)+nvl(times_wellsentrate,0))    AS messagesucc_rate
    FROM
        aggr_5g_im_cel_e2e_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_nr_index_h.p_hour$
        AND interface = 100
    GROUP BY
        nodebid
       ,cellid
) t9
ON t1.cellkey = t9.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,case when sum(httpwebreqcount)  !=0 then sum(gameinteractdelay_sum)/sum(httpwebreqcount) else 0 end AS gameinteractdelay
    FROM
        aggr_5g_game_cel_e2e_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_nr_index_h.p_hour$
        AND interface = 100
    GROUP BY
        nodebid
       ,cellid
) t10
ON t1.cellkey = t10.cellkey
;

