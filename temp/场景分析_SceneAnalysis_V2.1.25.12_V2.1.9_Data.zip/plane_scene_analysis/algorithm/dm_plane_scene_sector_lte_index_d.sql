-- 20250701updateby : goupengcheng 10207
-- algorithm : 更换小区输入表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

INSERT OVERWRITE TABLE dm_plane_scene_sector_lte_index_d
PARTITION (
    p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
    ,p_date = '$dm_plane_scene_sector_lte_index_d.p_date$'
)
SELECT
    '$dm_plane_scene_sector_lte_index_d.p_date$'        AS day
    ,$dm_plane_scene_sector_lte_index_d.p_provincecode$  AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,districtcode
    ,district_name
    ,scene_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,'4G'                            AS net_type
    ,enbid
    ,cellid
    ,t1.cellkey                      AS cellkey
    ,cellname
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,height
    ,indoor_flag
    ,azimuth
    ,vendor
    ,bandwidth
    ,cover_rate
    ,is_inside
    ,t1.master_operators             AS master_operators
    ,is_highload
    ,prb_usedul
    ,prb_availul
    ,prb_usedul_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_useddl_rate
    ,totalrsrp
    ,rsrpcount_scene * cover_rate    AS rsrpcount_scene
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,avgrsrp
    ,flux_ul * cover_rate            AS flux_ul
    ,flux_dl * cover_rate            AS flux_dl
    ,flux * cover_rate               AS flux
    ,cqi_good_count
    ,cqi_total_count
    ,cqi_good_rate
    ,rrc_connreq
    ,rrc_connsucc
    ,rrc_connsucc_rate
    ,s1sig_attconnestab
    ,s1sig_succconnestab
    ,s1sig_succconnestab_rate
    ,erab_attestab
    ,erab_succestab
    ,erab_succestab_rate
    ,access_success_rate
    ,CASE WHEN access_success_rate < 0.98 THEN 1 ELSE 0 END  AS is_bad_access
    ,erab_attestab_qci1
    ,erab_succestab_qci1
    ,erab_succestab_rate_qci1
    ,access_success_rate_qci1
    ,erab_abnormrel
    ,erab_normrel
    ,erab_drop_rate
    ,CASE WHEN erab_drop_rate > 0.02 THEN 1 ELSE 0 END       AS is_bad_drop
    ,erab_abnormrel_qci1
    ,erab_normrel_qci1
    ,erab_drop_qci1_rate
    ,pdcp_sduoctdl
    ,pdcp_sdutailflowdl
    ,pdcp_thrptimedl
    ,pdcp_tailtimedl
    ,uexp_meanspeeddl
    ,CASE WHEN uexp_meanspeeddl / bandwidth < 0.4 THEN 1 ELSE 0 END  AS is_bad_uexp_meanspeeddl
    ,pdcp_sdulosspktul_qci1
    ,pdcp_sdupktul_qci1
    ,pdcp_sdulosspktul_qci1_rate
    ,pdcp_sdulosspktdl_qci1
    ,pdcp_sdupktdl_qci1
    ,pdcp_sdulosspktdl_qci1_rate
    ,CASE WHEN pdcp_sdulosspktul_qci1_rate > 0.01 OR pdcp_sdulosspktdl_qci1_rate > 0.01 THEN 1 ELSE 0 END  AS is_bad_losspkt
    ,videoplay_suc_cnt
    ,videoplay_req_cnt
    ,videoplay_suc_rate
    ,video_good_rate
    ,CASE WHEN access_success_rate < 0.98 OR erab_drop_rate > 0.02 OR uexp_meanspeeddl / bandwidth < 0.4 THEN 1 ELSE 0 END AS is_bad
    ,NULL        AS bad_cause
    ,NULL        AS solution
    ,httpwebrspcount
    ,httpwebreqcount
    ,httpwebrsprate
    ,httpwebdspdelay
    ,httpwebscreendelay
    ,videoplaysuccesscount
    ,videoplayrequestcount
    ,videothroughput
    ,videoplaytime_without_halt_sum
    ,videoplayhaltcount
    ,kqi_videoplayhaltcountpermin
    ,times_excellentdownlink
    ,times_inferiordownlink
    ,times_welldownlink
    ,times_excellentstallfrequ
    ,times_inferiorstallfrequ
    ,times_wellstallfrequ
    ,messagesucccount
    ,messagereqcount
    ,messagesucc_rate
    ,gameinteractdelay
    ,dnsqueryrspcount
    ,dnsqueryreqcount
    ,dnsquerysuc_rate
    ,ROUND(0.1 * NVL(dnsquerysuc_rate,1) + 0.9 * (NVL(web_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(web_good_rate,1) + NVL(video_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(video_business_good_rate,1) + NVL(game_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(game_good_rate,1) + NVL(im_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(im_good_rate,1)),5) AS kqi_4g_good_rate
    ,web_good_rate
    ,video_business_good_rate
    ,im_good_rate
    ,game_good_rate
    ,scan_pay_suc_cnt
    ,scan_pay_req_cnt
    ,scan_pay_suc_rate
    ,scan_pay_tcpsetupackdelay
    ,wechat_suc_cnt
    ,wechat_req_cnt
    ,wechat_suc_rate
    ,rrc_userconnmean
    ,rrc_userconnmax
    ,phy_rrurxrssimean_chan1
    ,CASE
        WHEN phy_rrurxrssimean_chan1 >= -100    THEN 1
        WHEN phy_rrurxrssimean_chan1_hours >= 6 THEN 1
        ELSE 0
    END AS is_bad_interference
    ,mod3interfer_mrcount
    ,overlap_mrcount
    ,overshoot_mrcount
    ,mod3interfer_mrratio
    ,overlap_mrratio
    ,overshoot_mrratio
    ,rrc_userconnmean_busy
    ,rrc_userconnmax_busy
FROM
(
    SELECT
        provincecode        AS provincecode
       ,province_name       AS province_name
       ,citycode            AS citycode
       ,city_name           AS city_name
       ,districtcode        AS districtcode
       ,district_name       AS district_name
       ,scene_type          AS scene_type
       ,scene_subclass_id   AS scene_subclass_id
       ,scene_subclass_name AS scene_subclass_name
       ,enbid               AS enbid
       ,cellid              AS cellid
       ,cellkey             AS cellkey
       ,cellname            AS cellname
       ,cell_lon            AS cell_lon
       ,cell_lat            AS cell_lat
       ,freq                AS freq
       ,pci                 AS pci
       ,height              AS height
       ,indoor_flag         AS indoor_flag
       ,azimuth             AS azimuth
       ,vendor              AS vendor
       ,bandwidth           AS bandwidth
       ,cover_rate          AS cover_rate
       ,is_inside           AS is_inside
       ,master_operators    AS master_operators
    FROM
        cfg_plane_scene_sector_lte_rel_use_d  -- 修改输入表
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_lte_index_d.p_date$'
        AND valid_flag = 1 -- 添加过滤条件
        AND scene_type != 99
--        AND scene_type IN (1,2,3,4,5,7,8)
) t1
LEFT JOIN
(
    -- 忙时pm
    SELECT
        cellkey
       ,is_highload             AS is_highload
       ,puschprbtotmeanul       AS prb_usedul
       ,prb_ul_avail            AS prb_availul
       ,puschprbtotmeanul_rate  AS prb_usedul_rate
       ,puschprbtotmeandl       AS prb_useddl
       ,prb_dl_avail            AS prb_availdl
       ,puschprbtotmeandl_rate  AS prb_useddl_rate
       ,rrc_userconnmean        AS rrc_userconnmean_busy
       ,rrc_userconnmax         AS rrc_userconnmax_busy
       ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDER BY flux DESC) rn
    FROM
        aggr_lte_load_cell_h
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_lte_index_d.p_date$'
    HAVING rn = 1
) t2
ON t1.cellkey = t2.cellkey
LEFT JOIN
(
    -- mr
    SELECT
        cellkey
       ,case when data_source = 1 then '联通承建' else '电信承建' end AS master_operators
       ,SUM(totalrsrp)              AS totalrsrp
       ,SUM(rsrpcount)              AS rsrpcount_scene
       ,SUM(rsrpcount)              AS rsrpcount
       ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0) + NVL(rsrp_5div_level8mrcount,0))  AS rsrpgoodcount_110
       ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0))   AS rsrpgoodcount_105
       ,NVL(SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0) + NVL(rsrp_5div_level8mrcount,0)) / SUM(rsrpcount),1)  AS rsrpgoodcount_rate_110
       ,NVL(SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0)) / SUM(rsrpcount),1)   AS rsrpgoodcount_rate_105
       ,SUM(totalrsrp) / SUM(rsrpcount) AS avgrsrp
       ,sum(mod3interfer_mrcount)                       AS mod3interfer_mrcount
       ,sum(overlap_mrcount)                            AS overlap_mrcount
       ,sum(overshoot_mrcount)                          AS overshoot_mrcount
       ,nvl(sum(mod3interfer_mrcount)/sum(rsrpcount),0) AS mod3interfer_mrratio
       ,nvl(sum(overlap_mrcount)/sum(rsrpcount),0)      AS overlap_mrratio
       ,nvl(sum(overshoot_mrcount)/sum(rsrpcount),0)    AS overshoot_mrratio
    FROM
        zxvmax.aggr_lte_coverage_cel_refactor_d
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_lte_index_d.p_date$'
    GROUP BY cellkey
    ,case when data_source = 1 then '联通承建' else '电信承建' end

) t3
ON t1.cellkey = t3.cellkey
    AND t1.master_operators = t3.master_operators
LEFT JOIN
(
    -- pm
    SELECT
        CONCAT(related_enb_id,'_',cel_id)   AS cellkey
       ,sum(pdcp_sduoctul)/1024             AS flux_ul
       ,sum(pdcp_sduoctdl)/1024             AS flux_dl
       ,sum(nvl(pdcp_sduoctul,0)+nvl(pdcp_sduoctdl,0))/1024 AS flux
       ,sum(NVL(cqi7,0) + NVL(cqi8,0) + NVL(cqi9,0) + NVL(cqi10,0) + NVL(cqi11,0) + NVL(cqi12,0) + NVL(cqi13,0) + NVL(cqi14,0) + NVL(cqi15,0))  AS cqi_good_count
       ,sum(cqi)    AS cqi_total_count
       ,nvl(sum(NVL(cqi7,0) + NVL(cqi8,0) + NVL(cqi9,0) + NVL(cqi10,0) + NVL(cqi11,0) + NVL(cqi12,0) + NVL(cqi13,0) + NVL(cqi14,0) + NVL(cqi15,0))/sum(cqi),1)  AS cqi_good_rate
       ,sum(case when nvl(rrc_attconnestab_ue,0) + nvl(rrc_attconnestab_net,0) < nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0) then nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0) else nvl(rrc_attconnestab_ue,0) + nvl(rrc_attconnestab_net,0) end)  AS rrc_connreq
       ,sum(nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0)) AS rrc_connsucc
       ,nvl(sum(nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0))/sum(case when nvl(rrc_attconnestab_ue,0) + nvl(rrc_attconnestab_net,0) < nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0) then nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0) else nvl(rrc_attconnestab_ue,0) + nvl(rrc_attconnestab_net,0) end),1)   AS rrc_connsucc_rate
       ,sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end)    AS s1sig_attconnestab
       ,sum(s1sig_succconnestab)    AS s1sig_succconnestab
       ,nvl(sum(s1sig_succconnestab)/sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end),1)    AS s1sig_succconnestab_rate
       ,sum(case when nvl(erab_initattestab,0) + nvl(erab_addattestab,0) < nvl(erab_initsuccestab,0) + nvl(erab_addsuccestab,0) then nvl(erab_initsuccestab,0) + nvl(erab_addsuccestab,0) else nvl(erab_initattestab,0) + nvl(erab_addattestab,0) end)  AS erab_attestab
       ,sum(nvl(erab_initsuccestab,0) + nvl(erab_addsuccestab,0))   AS erab_succestab
       ,nvl(sum(nvl(erab_initsuccestab,0) + nvl(erab_addsuccestab,0))/sum(case when nvl(erab_initattestab,0) + nvl(erab_addattestab,0) < nvl(erab_initsuccestab,0) + nvl(erab_addsuccestab,0) then nvl(erab_initsuccestab,0) + nvl(erab_addsuccestab,0) else nvl(erab_initattestab,0) + nvl(erab_addattestab,0) end),1) AS erab_succestab_rate
       ,nvl(sum(nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0))/sum(case when nvl(rrc_attconnestab_ue,0) + nvl(rrc_attconnestab_net,0) < nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0) then nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0) else nvl(rrc_attconnestab_ue,0) + nvl(rrc_attconnestab_net,0) end),1) * nvl(sum(s1sig_succconnestab)/sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end),1) * nvl(sum(nvl(erab_initsuccestab,0) + nvl(erab_addsuccestab,0))/sum(case when nvl(erab_initattestab,0) + nvl(erab_addattestab,0) < nvl(erab_initsuccestab,0) + nvl(erab_addsuccestab,0) then nvl(erab_initsuccestab,0) + nvl(erab_addsuccestab,0) else nvl(erab_initattestab,0) + nvl(erab_addattestab,0) end),1)  AS access_success_rate
       ,sum(case when nvl(erab_initattestab_qci1,0) + nvl(erab_addattestab_qci1,0) < nvl(erab_initsuccestab_qci1,0) + nvl(erab_addsuccestab_qci1,0) then nvl(erab_initsuccestab_qci1,0) + nvl(erab_addsuccestab_qci1,0) else nvl(erab_initattestab_qci1,0) + nvl(erab_addattestab_qci1,0) end)  AS erab_attestab_qci1
       ,sum(nvl(erab_initsuccestab_qci1,0) + nvl(erab_addsuccestab_qci1,0)) AS erab_succestab_qci1
       ,nvl(sum(nvl(erab_initsuccestab_qci1,0) + nvl(erab_addsuccestab_qci1,0))/sum(case when nvl(erab_initattestab_qci1,0) + nvl(erab_addattestab_qci1,0) < nvl(erab_initsuccestab_qci1,0) + nvl(erab_addsuccestab_qci1,0) then nvl(erab_initsuccestab_qci1,0) + nvl(erab_addsuccestab_qci1,0) else nvl(erab_initattestab_qci1,0) + nvl(erab_addattestab_qci1,0) end),1)   AS erab_succestab_rate_qci1
       ,nvl(sum(nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0))/sum(case when nvl(rrc_attconnestab_ue,0) + nvl(rrc_attconnestab_net,0) < nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0) then nvl(rrc_succconnestab_ue,0) + nvl(rrc_succconnestab_net,0) else nvl(rrc_attconnestab_ue,0) + nvl(rrc_attconnestab_net,0) end),1) * nvl(sum(s1sig_succconnestab)/sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end),1) * nvl(sum(nvl(erab_initsuccestab_qci1,0) + nvl(erab_addsuccestab_qci1,0))/sum(case when nvl(erab_initattestab_qci1,0) + nvl(erab_addattestab_qci1,0) < nvl(erab_initsuccestab_qci1,0) + nvl(erab_addsuccestab_qci1,0) then nvl(erab_initsuccestab_qci1,0) + nvl(erab_addsuccestab_qci1,0) else nvl(erab_initattestab_qci1,0) + nvl(erab_addattestab_qci1,0) end),1)    AS access_success_rate_qci1
       ,sum(erab_abnormrel)                                                                      AS erab_abnormrel
       ,sum(erab_normrel)                                                                        AS erab_normrel
       ,sum(erab_abnormrel)/sum(nvl(erab_abnormrel,0) + nvl(erab_normrel,0))                     AS erab_drop_rate
       ,sum(erab_abnormrel_qci1)                                                                 AS erab_abnormrel_qci1
       ,sum(erab_normrel_qci1)                                                                   AS erab_normrel_qci1
       ,nvl(sum(erab_abnormrel_qci1)/sum(nvl(erab_abnormrel_qci1,0)+nvl(erab_normrel_qci1,0)),0) AS erab_drop_qci1_rate
       ,sum(pdcp_sduoctdl)                                                                       AS pdcp_sduoctdl
       ,sum(pdcp_sdutailflowdl)                                                                  AS pdcp_sdutailflowdl
       ,sum(pdcp_thrptimedl)                                                                     AS pdcp_thrptimedl
       ,sum(pdcp_tailtimedl)                                                                     AS pdcp_tailtimedl
       ,sum((pdcp_sduoctdl-pdcp_sdutailflowdl)*8)/sum(( pdcp_thrptimedl-pdcp_tailtimedl)/1000)   AS uexp_meanspeeddl
       ,sum(pdcp_sdulosspktul_qci1)                                                              AS pdcp_sdulosspktul_qci1
       ,sum(pdcp_sdupktul_qci1)                                                                  AS pdcp_sdupktul_qci1
       ,nvl(sum(pdcp_sdulosspktul_qci1)/sum(pdcp_sdupktul_qci1),0)                               AS pdcp_sdulosspktul_qci1_rate
       ,sum(pdcp_sdulosspktdl_qci1)                                                              AS pdcp_sdulosspktdl_qci1
       ,sum(pdcp_sdupktdl_qci1)                                                                  AS pdcp_sdupktdl_qci1
       ,nvl(sum(pdcp_sdulosspktdl_qci1)/sum(pdcp_sdupktdl_qci1),0)                               AS pdcp_sdulosspktdl_qci1_rate
       ,AVG(rrc_userconnmean)                                                                    AS rrc_userconnmean
       ,MAX(rrc_userconnmax)                                                                     AS rrc_userconnmax
       ,AVG(phy_rrurxrssimean_chan1)                                                             AS phy_rrurxrssimean_chan1
       ,COUNT(DISTINCT IF(phy_rrurxrssimean_chan1 >= -100,p_hour,NULL))                          AS phy_rrurxrssimean_chan1_hours
    FROM
        itg_pm_lte_cel_h_cel_d
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_lte_index_d.p_date$'
    GROUP BY
        related_enb_id
       ,cel_id
) t4
ON t1.cellkey = t4.cellkey
LEFT JOIN
(
    -- video
    SELECT
        cellkey
       ,videoplay_suc_cnt
       ,videoplay_req_cnt
       ,videoplay_suc_rate
       ,videoplaysuccesscount
       ,videoplayrequestcount
       ,videothroughput
       ,videoplaytime_without_halt_sum
       ,videoplayhaltcount
       ,kqi_videoplayhaltcountpermin
       ,times_excellentdownlink
       ,times_inferiordownlink
       ,times_welldownlink
       ,times_excellentstallfrequ
       ,times_inferiorstallfrequ
       ,times_wellstallfrequ
       ,video_duration
       ,CASE
            WHEN NVL(video_good_rate_1,0) <= NVL(video_good_rate_2,0) THEN NVL(video_good_rate_1,0)
            ELSE NVL(video_good_rate_2,0)
        END     AS video_business_good_rate
    FROM
    (
        SELECT
            CONCAT(nodebid,'_',cellid)                                                                                                                  AS cellkey
           ,SUM(duration_sum)                                                                                                                           AS video_duration
           ,sum(videoplaysuccesscount)                                                                                                                  AS videoplay_suc_cnt
           ,sum(videoplayrequestcount)                                                                                                                  AS videoplay_req_cnt
           ,sum(videoplaysuccesscount)/sum(videoplayrequestcount)                                                                                       AS videoplay_suc_rate
           ,sum(videoplaysuccesscount)                                                                                                                  AS videoplaysuccesscount
           ,sum(videoplayrequestcount)                                                                                                                  AS videoplayrequestcount
           ,sum(videothroughput_avg*videoplaysuccesscount)/sum(videoplaysuccesscount)                                                                   AS videothroughput
           ,sum(videoplaytime_without_halt_sum)                                                                                                         AS videoplaytime_without_halt_sum
           ,sum(videoplayhaltcount)                                                                                                                     AS videoplayhaltcount
           ,case when sum(videoplaytime_without_halt_sum) !=0 then sum(videoplayhaltcount)*60000/sum(videoplaytime_without_halt_sum) else 0 end         AS kqi_videoplayhaltcountpermin
           ,sum(times_excellentdownlink)                                                                                                                AS times_excellentdownlink
           ,sum(times_excellentdownlink)                                                                                                                AS times_inferiordownlink
           ,sum(times_welldownlink)                                                                                                                     AS times_welldownlink
           ,sum(times_excellentstallfrequ)                                                                                                              AS times_excellentstallfrequ
           ,sum(times_inferiorstallfrequ)                                                                                                               AS times_inferiorstallfrequ
           ,sum(times_wellstallfrequ)                                                                                                                   AS times_wellstallfrequ
           ,SUM(NVL(times_excellentdownlink,0) + NVL(times_welldownlink,0)) / SUM(NVL(times_excellentdownlink,0) + NVL(times_welldownlink,0) + NVL(times_inferiordownlink,0))   AS video_good_rate_1
           ,SUM(NVL(times_excellentstallfrequ,0) + NVL(times_wellstallfrequ,0)) / SUM(NVL(times_excellentstallfrequ,0) + NVL(times_wellstallfrequ,0) + NVL(times_inferiorstallfrequ,0)) AS video_good_rate_2
        FROM
            aggr_4g_video_cel_e2e_d
        WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
            AND reportdate = '$dm_plane_scene_sector_lte_index_d.p_date$'
        GROUP BY
            nodebid
           ,cellid
    ) t
) t5
ON t1.cellkey = t5.cellkey
LEFT JOIN
(
    -- 业务报表视频得分
    SELECT
        cell_key
       ,AVG(score) / 100  AS video_good_rate
    FROM
        dm_untreport_cell_video_index_d
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_lte_index_d.p_date$'
        AND net_type = 'LTE(LTE)'
    GROUP BY cell_key
) t6
ON t1.cellkey = t6.cell_key
LEFT JOIN
(
    -- http
    SELECT
        CONCAT(nodebid,'_',cellid)                          AS cellkey
       ,SUM(duration_sum)                                   AS web_duration
       ,sum(httpwebrspcount)                                AS httpwebrspcount
       ,sum(httpwebreqcount)                                AS httpwebreqcount
       ,sum(httpwebrspcount)/sum(httpwebreqcount)           AS httpwebrsprate
       ,sum(httpwebdspdelay_sum)/sum(httpwebrspcount)       AS httpwebdspdelay
       ,sum(httpwebscreendelay_sum)/sum(httpwebrspcount)    AS httpwebscreendelay
       ,sum(httpwebrspcount)/sum(httpwebreqcount)           AS web_good_rate
    FROM
        aggr_4g_web_cel_e2e_d
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
        AND reportdate = '$dm_plane_scene_sector_lte_index_d.p_date$'
    GROUP BY
        nodebid
       ,cellid
) t7
ON t1.cellkey = t7.cellkey
LEFT JOIN
(
    -- im
    SELECT
        CONCAT(nodebid,'_',cellid)                                                                                              AS cellkey
       ,SUM(duration_sum)                                                                                                       AS im_duration
       ,SUM(times_excellentsentrate)                                                                                            AS messagesucccount
       ,SUM(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate,0) + NVL(times_wellsentrate,0))                         AS messagereqcount
       ,SUM(times_excellentsentrate) / SUM(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate+times_wellsentrate,0))   AS messagesucc_rate
       ,SUM(times_excellentsentrate) / SUM(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate+times_wellsentrate,0))   AS im_good_rate
    FROM
        aggr_4g_im_cel_e2e_d
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
        AND reportdate = '$dm_plane_scene_sector_lte_index_d.p_date$'
    GROUP BY
        nodebid
       ,cellid
) t8
ON t1.cellkey = t8.cellkey
LEFT JOIN
(
    -- game
    SELECT
        cellkey
       ,game_duration
       ,gameinteractdelay
       ,CASE
            WHEN gameinteractdelay <= 150                       THEN 1
            WHEN 100 - (gameinteractdelay - 150) * 0.75 <= 0    THEN 0
            ELSE (100 - (gameinteractdelay - 150) * 0.75) / 100
        END AS game_good_rate
    FROM
    (
        SELECT
            CONCAT(nodebid,'_',cellid)                                                                                              AS cellkey
           ,SUM(duration_sum)                                                                                                       AS game_duration
           ,CASE WHEN SUM(httpwebreqcount) !=0 THEN SUM(gameinteractdelay_sum) / SUM(httpwebreqcount) ELSE 0 END                    AS gameinteractdelay
        FROM
            aggr_4g_game_cel_e2e_d
        WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
            AND reportdate = '$dm_plane_scene_sector_lte_index_d.p_date$'
        GROUP BY
            nodebid
           ,cellid
    ) t
) t9
ON t1.cellkey = t9.cellkey
LEFT JOIN
(
    -- dns
    SELECT
        cellkey
       ,SUM(dnsqueryrspcount)                           AS dnsqueryrspcount
       ,SUM(dnsqueryreqcount)                           AS dnsqueryreqcount
       ,SUM(dnsqueryrspcount) / SUM(dnsqueryreqcount)   AS dnsquerysuc_rate
    FROM
        aggr_lte_dns_noc_cel_d
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_lte_index_d.p_date$'
    GROUP BY cellkey
) t10
ON t1.cellkey = t10.cellkey
LEFT JOIN
(
    -- 扫码
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,sum(case when servicetype=88888888 then httpwebrspcount else 0 end)                                                                          AS scan_pay_suc_cnt
       ,sum(case when servicetype=88888888 then httpwebreqcount else 0 end)                                                                          AS scan_pay_req_cnt
       ,sum(case when servicetype=88888888 then httpwebrspcount else 0 end)/sum(case when servicetype=88888888 then httpwebreqcount else 0 end)      AS scan_pay_suc_rate
       ,sum(case when servicetype=88888888 then tcpsetupackdelay_sum else 0 end)/sum(case when servicetype=88888888 then httpwebreqcount else 0 end) AS scan_pay_tcpsetupackdelay
       ,sum(case when servicetype=01000202 then httpwebrspcount else 0 end)                                                                          AS wechat_suc_cnt
       ,sum(case when servicetype=01000202 then httpwebreqcount else 0 end)                                                                          AS wechat_req_cnt
       ,sum(case when servicetype=01000202 then httpwebrspcount else 0 end)/sum(case when servicetype=01000202 then httpwebreqcount else 0 end)      AS wechat_suc_rate
    FROM
        aggr_4g_im_usrappcel_e2e_d
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_lte_index_d.p_date$'
    GROUP BY
        nodebid
       ,cellid
) t11
ON t1.cellkey = t11.cellkey
;

