-- 20250701updateby : goupengcheng 10207
-- algorithm : 更换小区输入表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

create temporary function MultiGridToLonLat as 'com.gstools.impala.MultiGridToLonLat';
set spark.sql.autoBroadcastJoinThreshold = 400000000;

CACHE TABLE tmp_nr_cm AS
SELECT
    cellkey
   ,cell_longitude                                      AS cell_lon
   ,cell_latitude                                       AS cell_lat
   ,freq                                                AS freq
   ,pci                                                 AS pci
   ,cell_height                                         AS height
   ,indoor_flag                                         AS indoor_flag
   ,cell_azimuth                                        AS azimuth
   ,REGEXP_REPLACE(gnbname,'\\\\;|,','|')               AS gnbname
   ,REGEXP_REPLACE(cellname,'\\\\;|,','|')              AS cellname
   ,vendor                                              AS vendor
   ,bandwidth_dl                                        AS bandwidth
   ,master_operators                                    AS master_operators
   ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDER BY cell_longitude DESC) rn
FROM
    fact_nr_cm_projdata
WHERE p_provincecode = $dm_plane_scene_nr_coverage_celgrd_d.p_provincecode$
HAVING rn = 1
;

CACHE TABLE tmp_sence_cell AS
SELECT
    scene_type
   ,scene_subclass_id
   ,cellkey
FROM
    cfg_plane_scene_sector_nr_rel_use_d  -- 修改输入表
WHERE p_provincecode = $dm_plane_scene_nr_coverage_celgrd_d.p_provincecode$
    AND p_date = '$dm_plane_scene_nr_coverage_celgrd_d.p_date$'
    AND valid_flag = 1 -- 添加过滤条件
    AND scene_type != 99
GROUP BY
    scene_type
   ,scene_subclass_id
   ,cellkey
;

INSERT OVERWRITE TABLE dm_plane_scene_nr_coverage_celgrd_d
PARTITION (
    p_provincecode = $dm_plane_scene_nr_coverage_celgrd_d.p_provincecode$
    ,p_date = '$dm_plane_scene_nr_coverage_celgrd_d.p_date$'
)
SELECT
    '$dm_plane_scene_nr_coverage_celgrd_d.p_date$'          AS day
    ,$dm_plane_scene_nr_coverage_celgrd_d.p_provincecode$    AS provincecode
    ,t2.province_name                                        AS province_name
    ,t2.citycode                                             AS citycode
    ,t2.city_name                                            AS city_name
    ,t2.districtcode                                         AS districtcode
    ,t2.district_name                                        AS district_name
    ,t2.scene_type                                           AS scene_type
    ,t2.scene_subclass_id                                    AS scene_subclass_id
    ,t2.scene_subclass_name                                  AS scene_subclass_name
    ,gnbid
    ,cellid
    ,t1.cellkey                                              AS cellkey
    ,t1.regionid                                             AS regionid
    ,t1.x_offset_20                                          AS x_offset_20
    ,t1.y_offset_20                                          AS y_offset_20
    ,round((cast(arr_lonlat[0] as double)+cast(arr_lonlat[2] as double))/2,6) as grd_lon
    ,round((cast(arr_lonlat[1] as double)+cast(arr_lonlat[3] as double))/2,6) as grd_lat
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,height
    ,indoor_flag
    ,azimuth
    ,gnbname
    ,cellname
    ,vendor
    ,bandwidth
    ,master_operators
    ,CASE WHEN t4.cellkey IS NOT NULL THEN 1 ELSE 0 END      AS is_scene_cell
    ,totalrsrp
    ,rsrpcount
    ,avgrsrp
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,totalulsinr
    ,ulsinrcount
    ,avgulsinr
    ,mod30interfer_mrcount
    ,overlap_mrcount
    ,overshoot_mrcount
    ,mod30interfer_mrratio
    ,overlap_mrratio
    ,overshoot_mrratio
    ,rsrp110_sinrf3_total
    ,validrsrp_sinr_mrcount_total
    ,rsrp110_sinrf3_rate_total
    ,rsrp110_sinrf3_ctcc
    ,validrsrp_sinr_mrcount_ctcc
    ,rsrp110_sinrf3_rate_ctcc
FROM
(
    SELECT
        SPLIT(cellkey,'_')[0]                                       AS gnbid
       ,SPLIT(cellkey,'_')[1]                                       AS cellid
       ,cellkey                                                     AS cellkey
       ,regionid                                                    AS regionid
       ,x_offset_20                                                 AS x_offset_20
       ,y_offset_20                                                 AS y_offset_20
       ,SPLIT(MultiGridToLonLat(regionid,x_offset_20,y_offset_20,20),',') AS arr_lonlat
       ,sum(case when plmn='46011' then totalssrsrp else 0 end)     AS totalrsrp
       ,sum(case when plmn='46011' then ssrsrpcount else 0 end)     AS rsrpcount
       ,sum(case when plmn='46011' then totalssrsrp else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end) AS avgrsrp
       ,sum(case when plmn='46011' then NVL(ssrsrp_level3mrcount,0) + NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) else 0 end)    AS rsrpgoodcount_110
       ,sum(case when plmn='46011' then NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) else 0 end)  AS rsrpgoodcount_105
       ,nvl(sum(case when plmn='46011' then NVL(ssrsrp_level3mrcount,0) + NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end),1) AS rsrpgoodcount_rate_110
       ,nvl(sum(case when plmn='46011' then NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end),1)   AS rsrpgoodcount_rate_105
       ,sum(case when plmn='46011' then totalsssinr else 0 end)                                                                             AS totalulsinr
       ,sum(case when plmn='46011' then sssinrcount else 0 end)                                                                             AS ulsinrcount
       ,sum(case when plmn='46011' then totalsssinr else 0 end)/sum(case when plmn='46011' then sssinrcount else 0 end)                     AS avgulsinr
       ,sum(case when plmn='46011' then mod30interfer_mrcount else 0 end)                                                                   AS mod30interfer_mrcount
       ,sum(case when plmn='46011' then overlap_mrcount else 0 end)                                                                         AS overlap_mrcount
       ,sum(case when plmn='46011' then overshoot_mrcount else 0 end)                                                                       AS overshoot_mrcount
       ,nvl(sum(case when plmn='46011' then mod30interfer_mrcount else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end),0)    AS mod30interfer_mrratio
       ,nvl(sum(case when plmn='46011' then overlap_mrcount else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end),0)          AS overlap_mrratio
       ,nvl(sum(case when plmn='46011' then overshoot_mrcount else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end),0)        AS overshoot_mrratio
       ,sum(rsrp110_sinrf3)                                                                                                                 AS rsrp110_sinrf3_total
       ,sum(validrsrp_sinr_totalmrcount)                                                                                                    AS validrsrp_sinr_mrcount_total
       ,sum(rsrp110_sinrf3)/sum(validrsrp_sinr_totalmrcount)                                                                                AS rsrp110_sinrf3_rate_total
       ,sum(case when plmn='46011' then rsrp110_sinrf3 else 0 end)                                                                          AS rsrp110_sinrf3_ctcc
       ,sum(case when plmn='46011' then validrsrp_sinr_totalmrcount else 0 end)                                                             AS validrsrp_sinr_mrcount_ctcc
       ,sum(case when plmn='46011' then rsrp110_sinrf3 else 0 end)/sum(case when plmn='46011' then validrsrp_sinr_totalmrcount else 0 end)  AS rsrp110_sinrf3_rate_ctcc
    FROM
        aggr_nr_coverage_celgrd_refactor_d
    WHERE p_provincecode = $dm_plane_scene_nr_coverage_celgrd_d.p_provincecode$
        AND p_date = '$dm_plane_scene_nr_coverage_celgrd_d.p_date$'
        AND regionid IS NOT NULL
        AND x_offset_20 IS NOT NULL
        AND y_offset_20 IS NOT NULL
    GROUP BY
        cellkey
       ,regionid
       ,x_offset_20
       ,y_offset_20
) t1
INNER JOIN
(
    SELECT
        provincecode
       ,province_name
       ,citycode
       ,city_name
       ,districtcode
       ,district_name
       ,scene_type
       ,scene_subclass_id
       ,scene_subclass_name
       ,regionid
       ,x_offset_20
       ,y_offset_20
       ,grid_lon
       ,grid_lat
       ,ROW_NUMBER() OVER(PARTITION BY scene_type,scene_subclass_id,regionid,x_offset_20,y_offset_20 ORDER BY scene_subclass_id DESC) rn
    FROM
        cfg_scene_grid20m_rel
    WHERE p_provincecode = $dm_plane_scene_nr_coverage_celgrd_d.p_provincecode$
        AND p_date = '$dm_plane_scene_nr_coverage_celgrd_d.p_date$'
        AND is_scene_grid = 1
        AND scene_type != 99
--        AND scene_type IN (1,2,3,4,5,7,8)
    HAVING rn = 1
) t2
ON t1.regionid = t2.regionid
    AND t1.x_offset_20 = t2.x_offset_20
    AND t1.y_offset_20 = t2.y_offset_20
LEFT JOIN
    tmp_nr_cm t3
ON t1.cellkey = t3.cellkey
LEFT JOIN
    tmp_sence_cell t4
ON t1.cellkey = t4.cellkey
    AND t2.scene_type = t4.scene_type
    AND t2.scene_subclass_id = t4.scene_subclass_id
;

