-- 20250701updateby : goupengcheng 10207
-- algorithm : 更换小区输入表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

create temporary function MultiGridToLonLat as 'com.gstools.impala.MultiGridToLonLat';
-- set spark.sql.autoBroadcastJoinThreshold = 600000000;

CACHE TABLE tmp_ct_cm AS
SELECT
    reportcellkey                               AS cellkey
   ,celllon                                     AS cell_lon
   ,celllat                                     AS cell_lat
   ,bandclass                                   AS freq
   ,pci                                         AS pci
   ,height                                      AS height
   ,CASE WHEN covertype = 2 THEN 1 ELSE 0 END   AS indoor_flag
   ,azimuth                                     AS azimuth
   ,enodebname                                  AS enbname
   ,cellname                                    AS cellname
   ,vendor                                      AS vendor
   ,dlband                                      AS bandwidth
   ,'电信承建'                                  AS master_operators
   ,ROW_NUMBER() OVER(PARTITION BY reportcellkey ORDER BY celllon DESC) rn
FROM
    lte_cm_projdata
WHERE p_provincecode = $dm_plane_scene_lte_coverage_celgrd_d.p_provincecode$
HAVING rn = 1
;

CACHE TABLE tmp_cu_cm AS
SELECT
    cellkey         AS cellkey
   ,cell_lon        AS cell_lon
   ,cell_lat        AS cell_lat
   ,freq            AS freq
   ,pci             AS pci
   ,cell_height     AS height
   ,indoor_flag     AS indoor_flag
   ,azimuth         AS azimuth
   ,enodeb_name     AS enbname
   ,cell_name       AS cellname
   ,vendor          AS vendor
   ,bandwidth_dl    AS bandwidth
   ,'联通承建'      AS master_operators
   ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDER BY cell_lon DESC) rn
FROM
    lte_cucc_cm_projdata
WHERE p_provincecode = $dm_plane_scene_lte_coverage_celgrd_d.p_provincecode$
HAVING rn = 1
;

CACHE TABLE tmp_sence_cell AS
SELECT
    scene_type
   ,scene_subclass_id
   ,cellkey
FROM
    cfg_plane_scene_sector_lte_rel_use_d -- 修改输入表
WHERE p_provincecode = $dm_plane_scene_lte_coverage_celgrd_d.p_provincecode$
    AND p_date = '$dm_plane_scene_lte_coverage_celgrd_d.p_date$'
    AND valid_flag = 1 -- 添加过滤条件
    AND scene_type != 99
GROUP BY
    scene_type
   ,scene_subclass_id
   ,cellkey
;

INSERT OVERWRITE TABLE dm_plane_scene_lte_coverage_celgrd_d
PARTITION (
    p_provincecode = $dm_plane_scene_lte_coverage_celgrd_d.p_provincecode$
    ,p_date = '$dm_plane_scene_lte_coverage_celgrd_d.p_date$'
)
SELECT
    '$dm_plane_scene_lte_coverage_celgrd_d.p_date$' AS day
    ,$dm_plane_scene_lte_coverage_celgrd_d.p_provincecode$   AS provincecode
    ,t2.province_name        AS province_name
    ,t2.citycode             AS citycode
    ,t2.city_name            AS city_name
    ,t2.districtcode         AS districtcode
    ,t2.district_name        AS district_name
    ,t2.scene_type           AS scene_type
    ,t2.scene_subclass_id    AS scene_subclass_id
    ,t2.scene_subclass_name  AS scene_subclass_name
    ,enbid
    ,cellid
    ,t1.cellkey              AS cellkey
    ,t1.regionid             AS regionid
    ,t1.x_offset_20          AS x_offset_20
    ,t1.y_offset_20          AS y_offset_20
    ,round((cast(arr_lonlat[0] as double)+cast(arr_lonlat[2] as double))/2,6) as grd_lon
    ,round((cast(arr_lonlat[1] as double)+cast(arr_lonlat[3] as double))/2,6) as grd_lat
    ,NVL(t3.cell_lon,t4.cell_lon)                    AS cell_lon
    ,NVL(t3.cell_lat,t4.cell_lat)                    AS cell_lat
    ,NVL(t3.freq,t4.freq)                            AS freq
    ,NVL(t3.pci,t4.pci)                              AS pci
    ,NVL(t3.height,t4.height)                        AS height
    ,NVL(t3.indoor_flag,t4.indoor_flag)              AS indoor_flag
    ,NVL(t3.azimuth,t4.azimuth)                      AS azimuth
    ,NVL(t3.enbname,t4.enbname)                      AS enbname
    ,NVL(t3.cellname,t4.cellname)                    AS cellname
    ,NVL(t3.vendor,t4.vendor)                        AS vendor
    ,NVL(t3.bandwidth,t4.bandwidth)                  AS bandwidth
    ,NVL(t3.master_operators,t4.master_operators)    AS master_operators
    ,CASE WHEN t5.cellkey IS NOT NULL THEN 1 ELSE 0 END AS is_scene_cell
    ,totalrsrp
    ,rsrpcount
    ,avgrsrp
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,totalulsinr
    ,ulsinrcount
    ,avgulsinr
    ,mod3interfer_mrcount
    ,overlap_mrcount
    ,overshoot_mrcount
    ,mod3interfer_mrratio
    ,overlap_mrratio
    ,overshoot_mrratio
FROM
(
    SELECT
        SPLIT(cellkey,'_')[0]   AS enbid
       ,SPLIT(cellkey,'_')[1]   AS cellid
       ,cellkey                 AS cellkey
       ,regionid                AS regionid
       ,x_offset                AS x_offset_20
       ,y_offset                AS y_offset_20
       ,SPLIT(MultiGridToLonLat(regionid,x_offset,y_offset,20),',') as arr_lonlat
       ,SUM(totalrsrp)          AS totalrsrp
       ,SUM(rsrpcount)          AS rsrpcount
       ,SUM(totalrsrp) / SUM(rsrpcount) AS avgrsrp
       ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0) + NVL(rsrp_5div_level8mrcount,0))  AS rsrpgoodcount_110
       ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0))   AS rsrpgoodcount_105
       ,NVL(SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0) + NVL(rsrp_5div_level8mrcount,0)) / SUM(rsrpcount),1)  AS rsrpgoodcount_rate_110
       ,NVL(SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0)) / SUM(rsrpcount),1)   AS rsrpgoodcount_rate_105
       ,SUM(totalulsinr)                                    AS totalulsinr
       ,SUM(ulsinrcount)                                    AS ulsinrcount
       ,SUM(totalulsinr) / SUM(ulsinrcount)                 AS avgulsinr
       ,SUM(mod3interfer_mrcount)                           AS mod3interfer_mrcount
       ,SUM(overlap_mrcount)                                AS overlap_mrcount
       ,SUM(overshoot_mrcount)                              AS overshoot_mrcount
       ,NVL(SUM(mod3interfer_mrcount) / SUM(rsrpcount),0)   AS mod3interfer_mrratio
       ,NVL(SUM(overlap_mrcount) / SUM(rsrpcount),0)        AS overlap_mrratio
       ,NVL(SUM(overshoot_mrcount) / SUM(rsrpcount),0)      AS overshoot_mrratio
    FROM
        zxvmax.aggr_lte_coverage_base_refactor_d
    WHERE p_provincecode = $dm_plane_scene_lte_coverage_celgrd_d.p_provincecode$
        AND p_date = '$dm_plane_scene_lte_coverage_celgrd_d.p_date$'
        AND plmn = '46011'
        AND regionid IS NOT NULL
        AND x_offset IS NOT NULL
        AND y_offset IS NOT NULL
    GROUP BY
        cellkey
       ,regionid
       ,x_offset
       ,y_offset

) t1
INNER JOIN
(
    SELECT
        provincecode
       ,province_name
       ,citycode
       ,city_name
       ,districtcode
       ,district_name
       ,scene_type
       ,scene_subclass_id
       ,scene_subclass_name
       ,regionid
       ,x_offset_20
       ,y_offset_20
       ,grid_lon
       ,grid_lat
       ,ROW_NUMBER() OVER(PARTITION BY scene_type,scene_subclass_id,regionid,x_offset_20,y_offset_20 ORDER BY scene_subclass_id DESC) rn
    FROM
        cfg_scene_grid20m_rel
    WHERE p_provincecode = $dm_plane_scene_lte_coverage_celgrd_d.p_provincecode$
        AND p_date = '$dm_plane_scene_lte_coverage_celgrd_d.p_date$'
        AND is_scene_grid = 1
        AND scene_type != 99
--        AND scene_type IN (1,2,3,4,5,7,8)
    HAVING rn = 1
) t2
ON t1.regionid = t2.regionid
    AND t1.x_offset_20 = t2.x_offset_20
    AND t1.y_offset_20 = t2.y_offset_20
LEFT JOIN
    tmp_ct_cm t3
ON t1.cellkey = t3.cellkey
LEFT JOIN
    tmp_cu_cm t4
ON t1.cellkey = t4.cellkey
LEFT JOIN
    tmp_sence_cell t5
ON t1.cellkey = t5.cellkey
    AND t2.scene_type = t5.scene_type
    AND t2.scene_subclass_id = t5.scene_subclass_id
;

