-- 20250701updateby : goupengcheng 10207
-- algorithm : 新增维度字段

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

INSERT OVERWRITE TABLE dm_plane_scene_lte_coverage_grd_d
PARTITION (
    p_provincecode = $dm_plane_scene_lte_coverage_grd_d.p_provincecode$
    ,p_date = '$dm_plane_scene_lte_coverage_grd_d.p_date$'
)
SELECT
    '$dm_plane_scene_lte_coverage_grd_d.p_date$'        AS day
    ,$dm_plane_scene_lte_coverage_grd_d.p_provincecode$  AS provincecode
    ,province_name                                       AS province_name
    ,citycode                                            AS citycode
    ,city_name                                           AS city_name
    ,districtcode                                        AS districtcode
    ,district_name                                       AS district_name
    ,scene_type                                          AS scene_type
    ,scene_subclass_id                                   AS scene_subclass_id
    ,scene_subclass_name                                 AS scene_subclass_name
    ,regionid                                            AS regionid
    ,x_offset_20                                         AS x_offset_20
    ,y_offset_20                                         AS y_offset_20
    ,sum(totalrsrp)                                      AS totalrsrp
    ,sum(rsrpcount)                                      AS rsrpcount
    ,sum(totalrsrp)/sum(rsrpcount)                       AS avgrsrp
    ,sum(rsrpgoodcount_110)                              AS rsrpgoodcount_110
    ,sum(rsrpgoodcount_105)                              AS rsrpgoodcount_105
    ,nvl(sum(rsrpgoodcount_110)/sum(rsrpcount),1)        AS rsrpgoodcount_rate_110
    ,nvl(sum(rsrpgoodcount_105)/sum(rsrpcount),1)        AS rsrpgoodcount_rate_105
    ,sum(totalulsinr)                                    AS totalulsinr
    ,sum(ulsinrcount)                                    AS ulsinrcount
    ,sum(totalulsinr)/sum(ulsinrcount)                   AS avgulsinr
    ,sum(mod3interfer_mrcount)                           AS mod3interfer_mrcount
    ,sum(overlap_mrcount)                                AS overlap_mrcount
    ,sum(overshoot_mrcount)                              AS overshoot_mrcount
    ,nvl(sum(mod3interfer_mrcount)/sum(rsrpcount),0)     AS mod3interfer_mrratio
    ,nvl(sum(overlap_mrcount)/sum(rsrpcount),0)          AS overlap_mrratio
    ,nvl(sum(overshoot_mrcount)/sum(rsrpcount),0)        AS overshoot_mrratio
    -- 新增维度字段
    ,freq
FROM
    dm_plane_scene_lte_coverage_celgrd_d
WHERE p_provincecode = $dm_plane_scene_lte_coverage_grd_d.p_provincecode$
    AND p_date = '$dm_plane_scene_lte_coverage_grd_d.p_date$'
GROUP BY
    province_name
    ,citycode
    ,city_name
    ,districtcode
    ,district_name
    ,scene_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,regionid
    ,x_offset_20
    ,y_offset_20
    ,freq
;

