-- 20250701updateby : goupengcheng 10207
-- algorithm : 更换小区输入表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

INSERT OVERWRITE TABLE dm_plane_scene_sector_lte_index_h
PARTITION (
    p_provincecode = $dm_plane_scene_sector_lte_index_h.p_provincecode$
    ,p_date = '$dm_plane_scene_sector_lte_index_h.p_date$'
    ,p_hour = $dm_plane_scene_sector_lte_index_h.p_hour$
)
SELECT
    '$dm_plane_scene_sector_lte_index_h.p_date$'        AS day
    ,$dm_plane_scene_sector_lte_index_h.p_hour$          AS hour
    ,$dm_plane_scene_sector_lte_index_h.p_provincecode$  AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,districtcode
    ,district_name
    ,scene_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,'4G'                                                AS net_type
    ,enbid
    ,cellid
    ,t1.cellkey                                          AS cellkey
    ,cellname
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,height
    ,indoor_flag
    ,azimuth
    ,vendor
    ,bandwidth
    ,prb_usedul
    ,prb_availul
    ,prb_usedul_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_useddl_rate
    ,flux_ul * cover_rate                                AS flux_ul
    ,flux_dl * cover_rate                                AS flux_dl
    ,flux * cover_rate                                   AS flux
    ,rrc_connreq
    ,rrc_connsucc
    ,rrc_connsucc_rate
    ,s1sig_attconnestab
    ,s1sig_succconnestab
    ,s1sig_succconnestab_rate
    ,erab_attestab
    ,erab_succestab
    ,erab_succestab_rate
    ,access_success_rate
    ,erab_abnormrel
    ,erab_normrel
    ,erab_drop_rate
    ,pdcp_sduoctdl
    ,pdcp_sdutailflowdl
    ,pdcp_thrptimedl
    ,pdcp_tailtimedl
    ,uexp_meanspeeddl
    ,pdcp_sdulosspktul_qci1
    ,pdcp_sdupktul_qci1
    ,pdcp_sdulosspktul_qci1_rate
    ,pdcp_sdulosspktdl_qci1
    ,pdcp_sdupktdl_qci1
    ,pdcp_sdulosspktdl_qci1_rate
    ,httpwebrspcount
    ,httpwebreqcount
    ,httpwebrsprate
    ,httpwebdspdelay
    ,httpwebscreendelay
    ,videoplaysuccesscount
    ,videoplayrequestcount
    ,videothroughput
    ,videoplaytime_without_halt_sum
    ,videoplayhaltcount
    ,kqi_videoplayhaltcountpermin
    ,times_excellentdownlink
    ,times_inferiordownlink
    ,times_welldownlink
    ,times_excellentstallfrequ
    ,times_inferiorstallfrequ
    ,times_wellstallfrequ
    ,messagesucccount
    ,messagereqcount
    ,messagesucc_rate
    ,gameinteractdelay
    ,rrc_userconnmax
    ,rrc_userconnmean
    ,ho_attoutintrafreq
    ,ho_succoutintrafreq
    ,ho_succoutintrafreq_rate
    ,ho_attoutinterfreq
    ,ho_succoutinterfreq
    ,ho_succoutinterfreq_rate
    ,scan_pay_suc_cnt
    ,scan_pay_req_cnt
    ,scan_pay_suc_rate
    ,scan_pay_tcpsetupackdelay
    ,master_operators
FROM
(
    SELECT
        provincecode
       ,province_name
       ,citycode
       ,city_name
       ,districtcode
       ,district_name
       ,scene_type
       ,scene_subclass_id
       ,scene_subclass_name
       ,enbid
       ,cellid
       ,cellkey
       ,cellname
       ,cell_lon
       ,cell_lat
       ,freq
       ,pci
       ,height
       ,indoor_flag
       ,azimuth
       ,vendor
       ,bandwidth
       ,cover_rate
       ,master_operators
    FROM
        cfg_plane_scene_sector_lte_rel_use_d  -- 修改输入表
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_h.p_provincecode$
        AND p_date = '$cfg_plane_scene_sector_lte_rel_use_d.p_date$'  -- 修改输入表
        AND valid_flag = 1 -- 添加过滤条件
        AND scene_type = 5
) t1
LEFT JOIN
(
    SELECT
        CONCAT(related_enb_id,'_',cel_id)   AS cellkey
       ,nvl(sum(pdcp_sduoctul)/1024,0)                      AS flux_ul
       ,nvl(sum(pdcp_sduoctdl)/1024,0)                      AS flux_dl
       ,sum(nvl(pdcp_sduoctul,0)+nvl(pdcp_sduoctdl,0))/1024 AS flux
       ,sum(case when nvl(rrc_attconnestab_ue,0)+nvl(rrc_attconnestab_net,0) < nvl(rrc_succconnestab_ue,0)+nvl(rrc_succconnestab_net,0) then nvl(rrc_succconnestab_ue,0)+nvl(rrc_succconnestab_net,0) else nvl(rrc_attconnestab_ue,0)+nvl(rrc_attconnestab_net,0) end)  AS rrc_connreq
       ,sum(nvl(rrc_succconnestab_ue,0)+nvl(rrc_succconnestab_net,0))   AS rrc_connsucc
       ,nvl(sum(nvl(rrc_succconnestab_ue,0)+nvl(rrc_succconnestab_net,0))/sum(case when nvl(rrc_attconnestab_ue,0)+nvl(rrc_attconnestab_net,0) < nvl(rrc_succconnestab_ue,0)+nvl(rrc_succconnestab_net,0) then nvl(rrc_succconnestab_ue,0)+nvl(rrc_succconnestab_net,0) else nvl(rrc_attconnestab_ue,0)+nvl(rrc_attconnestab_net,0) end),1) AS rrc_connsucc_rate
       ,sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end)    AS s1sig_attconnestab
       ,sum(s1sig_succconnestab)    AS s1sig_succconnestab
       ,nvl(sum(s1sig_succconnestab)/sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end),1)    AS s1sig_succconnestab_rate
       ,sum(case when nvl(erab_initattestab,0)+nvl(erab_addattestab,0) < nvl(erab_initsuccestab,0)+nvl(erab_addsuccestab,0) then nvl(erab_initsuccestab,0)+nvl(erab_addsuccestab,0) else nvl(erab_initattestab,0)+nvl(erab_addattestab,0) end)  AS erab_attestab
       ,sum(nvl(erab_initsuccestab,0)+nvl(erab_addsuccestab,0)) AS erab_succestab
       ,nvl(sum(nvl(erab_initsuccestab,0)+nvl(erab_addsuccestab,0))/sum(case when nvl(erab_initattestab,0)+nvl(erab_addattestab,0) < nvl(erab_initsuccestab,0)+nvl(erab_addsuccestab,0) then nvl(erab_initsuccestab,0)+nvl(erab_addsuccestab,0) else nvl(erab_initattestab,0)+nvl(erab_addattestab,0) end),1)   AS erab_succestab_rate
       ,nvl(sum(nvl(rrc_succconnestab_ue,0)+nvl(rrc_succconnestab_net,0))/sum(case when nvl(rrc_attconnestab_ue,0)+nvl(rrc_attconnestab_net,0) < nvl(rrc_succconnestab_ue,0)+nvl(rrc_succconnestab_net,0) then nvl(rrc_succconnestab_ue,0)+nvl(rrc_succconnestab_net,0) else nvl(rrc_attconnestab_ue,0)+nvl(rrc_attconnestab_net,0) end),1) * nvl(sum(s1sig_succconnestab)/sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end),1) * nvl(sum(nvl(erab_initsuccestab,0)+nvl(erab_addsuccestab,0))/sum(case when nvl(erab_initattestab,0)+nvl(erab_addattestab,0) < nvl(erab_initsuccestab,0)+nvl(erab_addsuccestab,0) then nvl(erab_initsuccestab,0)+nvl(erab_addsuccestab,0) else nvl(erab_initattestab,0)+nvl(erab_addattestab,0) end),1)  AS access_success_rate
       ,sum(erab_abnormrel)                                                                     AS erab_abnormrel
       ,sum(erab_normrel)                                                                       AS erab_normrel
       ,sum(erab_abnormrel)/sum(nvl(erab_abnormrel,0)+nvl(erab_normrel,0))                      AS erab_drop_rate
       ,sum(pdcp_sduoctdl)                                                                      AS pdcp_sduoctdl
       ,sum(pdcp_sdutailflowdl)                                                                 AS pdcp_sdutailflowdl
       ,sum(pdcp_thrptimedl)                                                                    AS pdcp_thrptimedl
       ,sum(pdcp_tailtimedl)                                                                    AS pdcp_tailtimedl
       ,sum((pdcp_sduoctdl-pdcp_sdutailflowdl)*8)/sum((pdcp_thrptimedl-pdcp_tailtimedl)/1000)   AS uexp_meanspeeddl
       ,sum(pdcp_sdulosspktul_qci1)                                                             AS pdcp_sdulosspktul_qci1
       ,sum(pdcp_sdupktul_qci1)                                                                 AS pdcp_sdupktul_qci1
       ,nvl(sum(pdcp_sdulosspktul_qci1)/sum(pdcp_sdupktul_qci1),0)                              AS pdcp_sdulosspktul_qci1_rate
       ,sum(pdcp_sdulosspktdl_qci1)                                                             AS pdcp_sdulosspktdl_qci1
       ,sum(pdcp_sdupktdl_qci1)                                                                 AS pdcp_sdupktdl_qci1
       ,nvl(sum(pdcp_sdulosspktdl_qci1)/sum(pdcp_sdupktdl_qci1),0)                              AS pdcp_sdulosspktdl_qci1_rate
       ,avg(rrc_userconnmax)                                                                    AS rrc_userconnmax
       ,max(rrc_userconnmean)                                                                   AS rrc_userconnmean
       ,sum(ho_attoutintrafreq)                                                                 AS ho_attoutintrafreq
       ,sum(ho_succoutintrafreq)                                                                AS ho_succoutintrafreq
       ,sum(ho_succoutintrafreq)/sum(ho_attoutintrafreq)                                        AS ho_succoutintrafreq_rate
       ,sum(ho_attoutinterfreq)                                                                 AS ho_attoutinterfreq
       ,sum(ho_succoutinterfreq)                                                                AS ho_succoutinterfreq
       ,sum(ho_succoutinterfreq)/sum(ho_attoutinterfreq)                                        AS ho_succoutinterfreq_rate
    FROM
        itg_pm_lte_cel_h_cel_d
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_lte_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_lte_index_h.p_hour$
    GROUP BY
        related_enb_id
       ,cel_id
) t2
ON t1.cellkey = t2.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,sum(case when servicetype=88888888 then httpwebrspcount else 0 end)                                                                          AS scan_pay_suc_cnt
       ,sum(case when servicetype=88888888 then httpwebreqcount else 0 end)                                                                          AS scan_pay_req_cnt
       ,sum(case when servicetype=88888888 then httpwebrspcount else 0 end)/sum(case when servicetype=88888888 then httpwebreqcount else 0 end)      AS scan_pay_suc_rate
       ,sum(case when servicetype=88888888 then tcpsetupackdelay_sum else 0 end)/sum(case when servicetype=88888888 then httpwebreqcount else 0 end) AS scan_pay_tcpsetupackdelay
       ,sum(times_excellentsentrate)                                                                                                                 AS messagesucccount
       ,sum(nvl(times_excellentsentrate,0)+nvl(times_inferiorsentrate,0)+nvl(times_wellsentrate,0))                                                  AS messagereqcount
       ,sum(times_excellentsentrate)/sum(nvl(times_excellentsentrate,0)+nvl(times_inferiorsentrate,0)+nvl(times_wellsentrate,0))                     AS messagesucc_rate
    FROM
        aggr_4g_im_usrappcel_e2e_h
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_h.p_provincecode$
        AND reportdate = '$dm_plane_scene_sector_lte_index_h.p_date$'
        AND reporthour = $dm_plane_scene_sector_lte_index_h.p_hour$
    GROUP BY
        nodebid
       ,cellid
) t3
ON t1.cellkey = t3.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,sum(httpwebrspcount)                                AS httpwebrspcount
       ,sum(httpwebreqcount)                                AS httpwebreqcount
       ,sum(httpwebrspcount)/sum(httpwebreqcount)           AS httpwebrsprate
       ,sum(httpwebdspdelay_sum)/sum(httpwebrspcount)       AS httpwebdspdelay
       ,sum(httpwebscreendelay_sum)/sum(httpwebrspcount)    AS httpwebscreendelay
    FROM
        aggr_4g_web_usrappcel_e2e_h
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_h.p_provincecode$
        AND reportdate = '$dm_plane_scene_sector_lte_index_h.p_date$'
        AND reporthour = $dm_plane_scene_sector_lte_index_h.p_hour$
    GROUP BY
        nodebid
       ,cellid
) t4
ON t1.cellkey = t4.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,sum(videoplaysuccesscount)                                                                                                          AS videoplaysuccesscount
       ,sum(videoplayrequestcount)                                                                                                          AS videoplayrequestcount
       ,sum(videothroughput_avg*videoplaysuccesscount)/sum(videoplaysuccesscount) /1024                                                           AS videothroughput
       ,sum(videoplaytime_without_halt_sum)                                                                                                 AS videoplaytime_without_halt_sum
       ,sum(videoplayhaltcount)                                                                                                             AS videoplayhaltcount
       ,case when sum(videoplaytime_without_halt_sum) !=0 then sum(videoplayhaltcount)*60000/sum(videoplaytime_without_halt_sum) else 0 end AS kqi_videoplayhaltcountpermin
       ,sum(times_excellentdownlink)                                                                                                        AS times_excellentdownlink
       ,sum(times_excellentdownlink)                                                                                                        AS times_inferiordownlink
       ,sum(times_welldownlink)                                                                                                             AS times_welldownlink
       ,sum(times_excellentstallfrequ)                                                                                                      AS times_excellentstallfrequ
       ,sum(times_inferiorstallfrequ)                                                                                                       AS times_inferiorstallfrequ
       ,sum(times_wellstallfrequ)                                                                                                           AS times_wellstallfrequ
    FROM
        aggr_4g_video_usrappcel_e2e_h
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_h.p_provincecode$
        AND reportdate = '$dm_plane_scene_sector_lte_index_h.p_date$'
        AND reporthour = $dm_plane_scene_sector_lte_index_h.p_hour$
    GROUP BY
        nodebid
       ,cellid
) t5
ON t1.cellkey = t5.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,case when sum(httpwebreqcount)  !=0 then sum(gameinteractdelay_sum)/sum(httpwebreqcount) else 0 end AS gameinteractdelay
    FROM
        aggr_4g_game_usrappcel_e2e_h
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_h.p_provincecode$
        AND reportdate = '$dm_plane_scene_sector_lte_index_h.p_date$'
        AND reporthour = $dm_plane_scene_sector_lte_index_h.p_hour$
    GROUP BY
        nodebid
       ,cellid
) t6
ON t1.cellkey = t6.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,is_highload             AS is_highload
       ,puschprbtotmeanul       AS prb_usedul
       ,prb_ul_avail            AS prb_availul
       ,puschprbtotmeanul_rate  AS prb_usedul_rate
       ,puschprbtotmeandl       AS prb_useddl
       ,prb_dl_avail            AS prb_availdl
       ,puschprbtotmeandl_rate  AS prb_useddl_rate
    FROM
        aggr_lte_load_cell_h
    WHERE p_provincecode = $dm_plane_scene_sector_lte_index_h.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_lte_index_h.p_date$'
        AND p_hour = $dm_plane_scene_sector_lte_index_h.p_hour$
) t7
ON t1.cellkey = t7.cellkey
;
