-- 20250701updateby : goupengcheng 10207
-- algorithm : 更换小区输入表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

INSERT OVERWRITE TABLE dm_plane_scene_sector_nr_index_d
PARTITION (
    p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
    ,p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
)
SELECT
    '$dm_plane_scene_sector_nr_index_d.p_date$'         AS day
    ,$dm_plane_scene_sector_nr_index_d.p_provincecode$   AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,districtcode
    ,district_name
    ,scene_type
    ,scene_subclass_id
    ,REGEXP_REPLACE(scene_subclass_name,',','_')         AS scene_subclass_name
    ,'5G'                                                AS net_type
    ,gnbid
    ,cellid
    ,t1.cellkey                                          AS cellkey
    ,REGEXP_REPLACE(cellname,',','_')                    AS cellname
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,height
    ,indoor_flag
    ,azimuth
    ,REGEXP_REPLACE(vendor,',','_')                      AS vendor
    ,bandwidth
    ,cover_rate
    ,is_inside
    ,REGEXP_REPLACE(master_operators,',','_')            AS master_operators
    ,is_highload
    ,prb_usedul
    ,prb_availul
    ,prb_usedul_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_useddl_rate
    ,totalrsrp
    ,rsrpcount_scene * cover_rate                        AS rsrpcount_scene
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,rsrp110_sinrf3_total
    ,validrsrp_sinr_mrcount_total
    ,rsrp110_sinrf3_rate_total
    ,rsrp110_sinrf3_ctcc
    ,validrsrp_sinr_mrcount_ctcc
    ,rsrp110_sinrf3_rate_ctcc
    ,avgrsrp
    ,flux_ul * cover_rate                                AS flux_ul
    ,flux_dl * cover_rate                                AS flux_dl
    ,flux * cover_rate                                   AS flux
    ,cqi_good_count
    ,cqi_total_count
    ,cqi_good_rate
    ,rrc_connreq
    ,rrc_connsucc
    ,rrc_connsucc_rate
    ,ng_connatt
    ,ng_connsucc
    ,ng_connsucc_rate
    ,qos_initialestabreq
    ,qos_initialestabsucc
    ,qos_initialestabsucc_rate
    ,NVL(rrc_connsucc_rate,1) * NVL(ng_connsucc_rate,1) * NVL(qos_initialestabsucc_rate,1)   AS access_success_rate
    ,CASE WHEN NVL(rrc_connsucc_rate,1) * NVL(ng_connsucc_rate,1) * NVL(qos_initialestabsucc_rate,1) < 0.98 THEN 1 ELSE 0 END AS is_bad_access
    ,ue_contextrelease
    ,ue_normalcontextrelease
    ,uecntx_drop_rate
    ,CASE WHEN uecntx_drop_rate > 0.02 THEN 1 ELSE 0 END AS is_bad_drop
    ,vonr_connreq
    ,vonr_connsucc
    ,vonr_connsucc_rate
    ,vonr_releasesum
    ,vonr_normalrelease
    ,vonr_drop_rate
    ,rlc_txbytesdl
    ,rlc_lasttxbytesdl
    ,rlc_txtimedl_exceptlastslot
    ,uexp_meanspeeddl
    ,CASE WHEN freq='3.5G' AND uexp_meanspeeddl / bandwidth < 0.4 THEN 1 WHEN  freq='2.1G' AND uexp_meanspeeddl / bandwidth < 0.5 THEN 1 ELSE 0 END AS is_bad_uexp_meanspeeddl
    ,vonr_rtp_rxpktul
    ,vonr_rtp_losspktul
    ,vonr_rtp_losspktul_rate
    ,vonr_rtp_rxpktdl
    ,vonr_rtp_losspktdl
    ,vonr_rtp_losspktdl_rate
    ,CASE WHEN vonr_rtp_losspktul_rate > 0.01 OR vonr_rtp_losspktdl_rate > 0.01 THEN 1 ELSE 0 END AS is_bad_losspkt
    ,vonr_ho_atttovolte
    ,vonr_ho_succtovolte
    ,vonr_ho_succtovolte_rate
    ,videoplay_suc_cnt
    ,videoplay_req_cnt
    ,videoplay_suc_rate
    ,video_good_rate
    ,CASE
        WHEN NVL(rrc_connsucc_rate,1) * NVL(ng_connsucc_rate,1) * NVL(qos_initialestabsucc_rate,1) < 0.98   THEN 1
        WHEN uecntx_drop_rate > 0.02                                                                        THEN 1
        WHEN freq='3.5G' AND uexp_meanspeeddl / bandwidth < 0.4                                             THEN 1
        WHEN  freq='2.1G' AND uexp_meanspeeddl / bandwidth < 0.5                                            THEN 1
        ELSE 0
    END                                                 AS is_bad
    ,NULL                                                AS bad_cause
    ,NULL                                                AS solution
    ,httpwebrspcount
    ,httpwebreqcount
    ,httpwebrsprate
    ,httpwebdspdelay
    ,httpwebscreendelay
    ,videoplaysuccesscount
    ,videoplayrequestcount
    ,videothroughput
    ,videoplaytime_without_halt_sum
    ,videoplayhaltcount
    ,kqi_videoplayhaltcountpermin
    ,times_excellentdownlink
    ,times_inferiordownlink
    ,times_welldownlink
    ,times_excellentstallfrequ
    ,times_inferiorstallfrequ
    ,times_wellstallfrequ
    ,messagesucccount
    ,messagereqcount
    ,messagesucc_rate
    ,gameinteractdelay
    ,dnsqueryrspcount
    ,dnsqueryreqcount
    ,dnsquerysuc_rate
    ,ROUND(0.1 * NVL(dnsquerysuc_rate,1) + 0.9 * (NVL(web_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(web_good_rate,1) + NVL(video_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(video_business_good_rate,1) + NVL(game_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(game_good_rate,1) + NVL(im_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(im_good_rate,1)),5) AS kqi_4g_good_rate
    ,web_good_rate
    ,video_business_good_rate
    ,im_good_rate
    ,game_good_rate
    ,ho_succintragnb
    ,ho_succbyxn
    ,ho_succbyng
    ,ho_attintragnb
    ,ho_attbyxn
    ,ho_attbyng
    ,ho_succ_rate
    ,epsfb_voice_suc
    ,epsfb_voice_req
    ,epsfb_voice_suc_rate
    ,intra_5gstoepsbydata
    ,intra_5gstoepsbydata / rrc_connsucc AS intra_5gstoepsbydata_rate
    ,scan_pay_suc_cnt
    ,scan_pay_req_cnt
    ,scan_pay_suc_rate
    ,scan_pay_tcpsetupackdelay
    ,wechat_suc_cnt
    ,wechat_req_cnt
    ,wechat_suc_rate
    ,rrc_connmean
    ,rrc_connmax
    ,phy_meannlperprbul
    ,CASE
        WHEN phy_meann_hours >= 6       THEN 1
        WHEN phy_meannlperprbul >= -105 THEN 1
        ELSE 0
    END     AS is_bad_interference
    ,NULL    AS mod30interfer_mrcount
    ,overlap_mrcount
    ,overshoot_mrcount
    ,NULL    AS mod30interfer_mrratio
    ,overlap_mrratio
    ,overshoot_mrratio
    ,rrc_connmean_busy
    ,rrc_connmax_busy
FROM
(
    SELECT
        provincecode
       ,province_name
       ,citycode
       ,city_name
       ,districtcode
       ,district_name
       ,scene_type
       ,scene_subclass_id
       ,scene_subclass_name
       ,enbid   AS gnbid
       ,cellid
       ,cellkey
       ,cellname
       ,cell_lon
       ,cell_lat
       ,freq
       ,pci
       ,height
       ,indoor_flag
       ,azimuth
       ,vendor
       ,bandwidth
       ,cover_rate
       ,is_inside
       ,master_operators
    FROM
        cfg_plane_scene_sector_nr_rel_use_d  -- 修改输入表
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
        -- 添加过滤条件
        AND valid_flag = 1
        AND scene_type != 99
) t1
LEFT JOIN
(
    SELECT
        cellkey
       ,is_highload
       ,prb_usedul
       ,prb_availul
       ,prb_usedul_rate
       ,prb_useddl
       ,prb_availdl
       ,prb_useddl_rate
       ,rrc_userconnmean    AS rrc_connmean_busy
       ,rrc_userconnmax     AS rrc_connmax_busy
       ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDER BY flux DESC) rn
    FROM
        aggr_nr_load_cell_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
    HAVING rn = 1
) t2
ON t1.cellkey = t2.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,sum(CASE WHEN plmn='46011' THEN totalssrsrp ELSE 0 END)    AS totalrsrp
       ,sum(CASE WHEN plmn='46011' THEN ssrsrpcount ELSE 0 END)    AS rsrpcount_scene
       ,sum(CASE WHEN plmn='46011' THEN ssrsrpcount ELSE 0 END)    AS rsrpcount
       ,sum(CASE WHEN plmn='46011' THEN NVL(ssrsrp_level3mrcount,0) + NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) ELSE 0 END)   AS rsrpgoodcount_110
       ,sum(CASE WHEN plmn='46011' THEN NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) ELSE 0 END) AS rsrpgoodcount_105
       ,nvl(sum(CASE WHEN plmn='46011' THEN NVL(ssrsrp_level3mrcount,0) + NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) ELSE 0 END)/sum(CASE WHEN plmn='46011' THEN ssrsrpcount ELSE 0 END),1)   AS rsrpgoodcount_rate_110
       ,nvl(sum(CASE WHEN plmn='46011' THEN NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) ELSE 0 END)/sum(CASE WHEN plmn='46011' THEN ssrsrpcount ELSE 0 END),1) AS rsrpgoodcount_rate_105
       ,sum(rsrp110_sinrf3)                                     AS rsrp110_sinrf3_total
       ,sum(validrsrp_sinr_totalmrcount)                        AS validrsrp_sinr_mrcount_total
       ,sum(rsrp110_sinrf3)/sum(validrsrp_sinr_totalmrcount)    AS rsrp110_sinrf3_rate_total
       ,sum(CASE WHEN plmn='46011' THEN rsrp110_sinrf3 ELSE 0 END)                                     AS rsrp110_sinrf3_ctcc
       ,sum(CASE WHEN plmn='46011' THEN validrsrp_sinr_totalmrcount ELSE 0 END)                        AS validrsrp_sinr_mrcount_ctcc
       ,sum(CASE WHEN plmn='46011' THEN rsrp110_sinrf3 ELSE 0 END)/sum(CASE WHEN plmn='46011' THEN validrsrp_sinr_totalmrcount ELSE 0 END)    AS rsrp110_sinrf3_rate_ctcc
       ,sum(totalssrsrp)/sum(ssrsrpcount)                       AS avgrsrp
       ,sum(overlap_mrcount)                                   AS overlap_mrcount
       ,sum(overshoot_mrcount)                                 AS overshoot_mrcount
       ,nvl(sum(overlap_mrcount)/sum(ssrsrpcount),0)           AS overlap_mrratio
       ,nvl(sum(overshoot_mrcount)/sum(ssrsrpcount),0)         AS overshoot_mrratio
    FROM
        aggr_nr_coverage_cel_refactor_d
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
    GROUP BY cellkey
) t3
ON t1.cellkey = t3.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(cel_id,'-')[1],'_',SPLIT(cel_id,'-')[2])       AS cellkey
       ,SUM(NVL(rlc_rxbytesul,0) + NVL(nsa_rlc_rxbytesul,0)) / 1024 AS flux_ul
       ,SUM(NVL(rlc_txbytesdl,0) + NVL(nsa_rlc_txbytesdl,0)) / 1024 AS flux_dl
       ,SUM(NVL(rlc_rxbytesul,0) + NVL(nsa_rlc_rxbytesul,0) + NVL(rlc_txbytesdl,0) + NVL(nsa_rlc_txbytesdl,0)) / 1024 AS flux
--        ,SUM(NVL(rlc_rxbytesul,0) + NVL(nsa_rlc_rxbytesul,0)) / SUM(NVL(rlc_txbytesdl,0) + NVL(nsa_rlc_txbytesdl,0)) AS flux
       ,sum(rlc_txbytesdl)                                                                  AS rlc_txbytesdl
       ,sum(rlc_lasttxbytesdl)                                                              AS rlc_lasttxbytesdl
       ,sum(rlc_txtimedl_exceptlastslot)                                                    AS rlc_txtimedl_exceptlastslot
       ,(sum(rlc_txbytesdl-rlc_lasttxbytesdl)*8)/(sum(rlc_txtimedl_exceptlastslot)/1000)    AS uexp_meanspeeddl
    FROM
        fact_pm_nr_lceldu_d
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
        AND SPLIT(cel_id,'-')[0] = '46011'
    GROUP BY cel_id
) t4
ON t1.cellkey = t4.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])   AS cellkey
       ,SUM(NVL(cqi_numintable_cqi10,0) + NVL(cqi_numintable_cqi11,0) + NVL(cqi_numintable_cqi12,0) + NVL(cqi_numintable_cqi13,0) + NVL(cqi_numintable_cqi14,0) + NVL(cqi_numintable_cqi15,0) + NVL(cqi_numintable2_cqi7,0) + NVL(cqi_numintable2_cqi8,0) + NVL(cqi_numintable2_cqi9,0) + NVL(cqi_numintable2_cqi10,0) + NVL(cqi_numintable2_cqi11,0) + NVL(cqi_numintable2_cqi12,0) + NVL(cqi_numintable2_cqi13,0) + NVL(cqi_numintable2_cqi14,0) + NVL(cqi_numintable2_cqi15,0))  AS cqi_good_count
       ,SUM(NVL(cqi_numintable_cqi0,0) + NVL(cqi_numintable_cqi1,0) + NVL(cqi_numintable_cqi2,0) + NVL(cqi_numintable_cqi3,0) + NVL(cqi_numintable_cqi4,0) + NVL(cqi_numintable_cqi5,0) + NVL(cqi_numintable_cqi6,0) + NVL(cqi_numintable_cqi7,0) + NVL(cqi_numintable_cqi8,0) + NVL(cqi_numintable_cqi9,0) + NVL(cqi_numintable_cqi10,0) + NVL(cqi_numintable_cqi11,0) + NVL(cqi_numintable_cqi12,0) + NVL(cqi_numintable_cqi13,0) + NVL(cqi_numintable_cqi14,0) + NVL(cqi_numintable_cqi15,0) + NVL(cqi_numintable2_cqi0,0) + NVL(cqi_numintable2_cqi1,0) + NVL(cqi_numintable2_cqi2,0) + NVL(cqi_numintable2_cqi3,0) + NVL(cqi_numintable2_cqi4,0) + NVL(cqi_numintable2_cqi5,0) + NVL(cqi_numintable2_cqi6,0) + NVL(cqi_numintable2_cqi7,0) + NVL(cqi_numintable2_cqi8,0) + NVL(cqi_numintable2_cqi9,0) + NVL(cqi_numintable2_cqi10,0) + NVL(cqi_numintable2_cqi11,0) + NVL(cqi_numintable2_cqi12,0) + NVL(cqi_numintable2_cqi13,0) + NVL(cqi_numintable2_cqi14,0) + NVL(cqi_numintable2_cqi15,0))  AS cqi_total_count
       ,NVL(SUM(NVL(cqi_numintable_cqi10,0) + NVL(cqi_numintable_cqi11,0) + NVL(cqi_numintable_cqi12,0) + NVL(cqi_numintable_cqi13,0) + NVL(cqi_numintable_cqi14,0) + NVL(cqi_numintable_cqi15,0) + NVL(cqi_numintable2_cqi7,0) + NVL(cqi_numintable2_cqi8,0) + NVL(cqi_numintable2_cqi9,0) + NVL(cqi_numintable2_cqi10,0) + NVL(cqi_numintable2_cqi11,0) + NVL(cqi_numintable2_cqi12,0) + NVL(cqi_numintable2_cqi13,0) + NVL(cqi_numintable2_cqi14,0) + NVL(cqi_numintable2_cqi15,0))/sum(NVL(cqi_numintable_cqi0,0) + NVL(cqi_numintable_cqi1,0) + NVL(cqi_numintable_cqi2,0) + NVL(cqi_numintable_cqi3,0) + NVL(cqi_numintable_cqi4,0) + NVL(cqi_numintable_cqi5,0) + NVL(cqi_numintable_cqi6,0) + NVL(cqi_numintable_cqi7,0) + NVL(cqi_numintable_cqi8,0) + NVL(cqi_numintable_cqi9,0) + NVL(cqi_numintable_cqi10,0) + NVL(cqi_numintable_cqi11,0) + NVL(cqi_numintable_cqi12,0) + NVL(cqi_numintable_cqi13,0) + NVL(cqi_numintable_cqi14,0) + NVL(cqi_numintable_cqi15,0) + NVL(cqi_numintable2_cqi0,0) + NVL(cqi_numintable2_cqi1,0) + NVL(cqi_numintable2_cqi2,0) + NVL(cqi_numintable2_cqi3,0) + NVL(cqi_numintable2_cqi4,0) + NVL(cqi_numintable2_cqi5,0) + NVL(cqi_numintable2_cqi6,0) + NVL(cqi_numintable2_cqi7,0) + NVL(cqi_numintable2_cqi8,0) + NVL(cqi_numintable2_cqi9,0) + NVL(cqi_numintable2_cqi10,0) + NVL(cqi_numintable2_cqi11,0) + NVL(cqi_numintable2_cqi12,0) + NVL(cqi_numintable2_cqi13,0) + NVL(cqi_numintable2_cqi14,0) + NVL(cqi_numintable2_cqi15,0)),1)    AS cqi_good_rate
       ,AVG(CASE WHEN phy_meannlperprbul = 'NaN' THEN NULL ELSE CAST(phy_meannlperprbul AS DOUBLE) END)     AS phy_meannlperprbul
       ,COUNT(DISTINCT IF(phy_meannlperprbul >= -105,p_hour,NULL))  AS phy_meann_hours
    FROM
        fact_pm_nr_celldu_h
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
    GROUP BY CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])
) t5
ON t1.cellkey = t5.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])   AS cellkey
       ,sum(case when rrc_connreq < rrc_connsucc then rrc_connsucc else rrc_connreq end)                            AS rrc_connreq
       ,sum(rrc_connsucc)                                                                                           AS rrc_connsucc
       ,nvl(sum(rrc_connsucc)/sum(case when rrc_connreq < rrc_connsucc then rrc_connsucc else rrc_connreq end),1)   AS rrc_connsucc_rate
    FROM
        fact_pm_nr_cellcu_d
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
    GROUP BY CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])
) t6
ON t1.cellkey = t6.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(cel_id,'-')[1],'_',SPLIT(cel_id,'-')[2])   AS cellkey
       ,sum(case when ng_connatt < ng_connsucc then ng_connsucc else ng_connatt end)                                                                        AS ng_connatt
       ,sum(ng_connsucc)                                                                                                                                    AS ng_connsucc
       ,nvl(sum(ng_connsucc)/sum(case when ng_connatt < ng_connsucc then ng_connsucc else ng_connatt end),1)                                                AS ng_connsucc_rate
       ,sum(case when qos_initialestabreq < qos_initialestabsucc then qos_initialestabsucc else qos_initialestabreq end)                                    AS qos_initialestabreq
       ,sum(qos_initialestabsucc)                                                                                                                           AS qos_initialestabsucc
       ,nvl(sum(qos_initialestabsucc)/sum(case when qos_initialestabreq < qos_initialestabsucc then qos_initialestabsucc else qos_initialestabreq end),1)   AS qos_initialestabsucc_rate
       ,sum(ue_contextrelease)                                                                                                                              AS ue_contextrelease
       ,sum(ue_normalcontextrelease)                                                                                                                        AS ue_normalcontextrelease
       ,nvl(sum(ue_contextrelease - ue_normalcontextrelease)/sum(ue_contextrelease),0)                                                                      AS uecntx_drop_rate
       ,sum(vonr_connreq)                                                                                                                                   AS vonr_connreq
       ,sum(vonr_connsucc)                                                                                                                                  AS vonr_connsucc
       ,nvl(sum(vonr_connsucc)/sum(vonr_connreq),1)                                                                                                         AS vonr_connsucc_rate
       ,sum(vonr_releasesum)                                                                                                                                AS vonr_releasesum
       ,sum(vonr_normalrelease)                                                                                                                             AS vonr_normalrelease
       ,nvl(sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum),0)                                                                                 AS vonr_drop_rate
       ,sum(vonr_rtp_rxpktul)                                                                                                                               AS vonr_rtp_rxpktul
       ,sum(vonr_rtp_losspktul)                                                                                                                             AS vonr_rtp_losspktul
       ,sum(vonr_rtp_losspktul)/sum(vonr_rtp_rxpktul)                                                                                                       AS vonr_rtp_losspktul_rate
       ,sum(vonr_rtp_rxpktdl)                                                                                                                               AS vonr_rtp_rxpktdl
       ,sum(vonr_rtp_losspktdl)                                                                                                                             AS vonr_rtp_losspktdl
       ,sum(vonr_rtp_losspktdl)/sum(vonr_rtp_rxpktdl)                                                                                                       AS vonr_rtp_losspktdl_rate
       ,sum(vonr_ho_atttovolte)                                                                                                                             AS vonr_ho_atttovolte
       ,sum(vonr_ho_succtovolte)                                                                                                                            AS vonr_ho_succtovolte
       ,sum(vonr_ho_succtovolte)/sum(vonr_ho_atttovolte)                                                                                                    AS vonr_ho_succtovolte_rate
       ,sum(ho_succintragnb)                                                                                                                                AS ho_succintragnb
       ,sum(ho_succbyxn)                                                                                                                                    AS ho_succbyxn
       ,sum(ho_succbyng)                                                                                                                                    AS ho_succbyng
       ,sum(case when ho_attintragnb<ho_succintragnb then ho_succintragnb else ho_attintragnb end)                                                          AS ho_attintragnb
       ,sum(case when ho_attbyxn<ho_succbyxn then ho_succbyxn else ho_attbyxn end)                                                                          AS ho_attbyxn
       ,sum(case when ho_attbyng<ho_succbyng then ho_succbyng else ho_attbyng end)                                                                          AS ho_attbyng
       ,nvl(sum(nvl(ho_succintragnb,0) + nvl(ho_succbyxn,0) + nvl(ho_succbyng,0))/sum(case when ho_attintragnb<ho_succintragnb then ho_succintragnb else ho_attintragnb end + case when ho_attbyxn<ho_succbyxn then ho_succbyxn else ho_attbyxn end + case when ho_attbyng<ho_succbyng then ho_succbyng else ho_attbyng end),1)  AS ho_succ_rate
       ,sum(ho_5gstoepssuccbyvoice)                                                                                                                         AS epsfb_voice_suc
       ,sum(ho_5gstoepsreqbyvoice)                                                                                                                          AS epsfb_voice_req
       ,sum(ho_5gstoepssuccbyvoice)/sum(ho_5gstoepsreqbyvoice)                                                                                              AS epsfb_voice_suc_rate
       ,sum(intra_5gstoepsbydata)                                                                                                                           AS intra_5gstoepsbydata
       ,AVG(rrc_connmean)                                                                                                                                   AS rrc_connmean
       ,MAX(rrc_connmax)                                                                                                                                    AS rrc_connmax
    FROM
        fact_pm_nr_lcelcu_d
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
        AND SPLIT(cel_id,'-')[0] = '46011'
    GROUP BY cel_id
) t7
ON t1.cellkey = t7.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,video_duration
       ,videoplay_suc_cnt
       ,videoplay_req_cnt
       ,videoplay_suc_rate
       ,videoplaysuccesscount
       ,videoplayrequestcount
       ,videothroughput
       ,videoplaytime_without_halt_sum
       ,videoplayhaltcount
       ,kqi_videoplayhaltcountpermin
       ,times_excellentdownlink
       ,times_inferiordownlink
       ,times_welldownlink
       ,times_excellentstallfrequ
       ,times_inferiorstallfrequ
       ,times_wellstallfrequ
       ,CASE
            WHEN NVL(video_good_rate_1,0) <= NVL(video_good_rate_2,0) THEN NVL(video_good_rate_1,0)
            ELSE NVL(video_good_rate_2,0)
        END     AS video_business_good_rate
    FROM
    (
        SELECT
            CONCAT(nodebid,'_',cellid)                                                                                                          AS cellkey
           ,sum(duration_sum)                                                                                                                   AS video_duration
           ,sum(videoplaysuccesscount)                                                                                                          AS videoplay_suc_cnt
           ,sum(videoplayrequestcount)                                                                                                          AS videoplay_req_cnt
           ,sum(videoplaysuccesscount)/sum(videoplayrequestcount)                                                                               AS videoplay_suc_rate
           ,sum(videoplaysuccesscount)                                                                                                          AS videoplaysuccesscount
           ,sum(videoplayrequestcount)                                                                                                          AS videoplayrequestcount
           ,sum(videothroughput*videoplaysuccesscount)/sum(videoplaysuccesscount)                                                               AS videothroughput
           ,sum(videoplaytime_without_halt_sum)                                                                                                 AS videoplaytime_without_halt_sum
           ,sum(videoplayhaltcount)                                                                                                             AS videoplayhaltcount
           ,case when sum(videoplaytime_without_halt_sum) !=0 then sum(videoplayhaltcount)*60000/sum(videoplaytime_without_halt_sum) else 0 end AS kqi_videoplayhaltcountpermin
           ,sum(times_excellentdownlink)                                                                                                        AS times_excellentdownlink
           ,sum(times_excellentdownlink)                                                                                                        AS times_inferiordownlink
           ,sum(times_welldownlink)                                                                                                             AS times_welldownlink
           ,sum(times_excellentstallfrequ)                                                                                                      AS times_excellentstallfrequ
           ,sum(times_inferiorstallfrequ)                                                                                                       AS times_inferiorstallfrequ
           ,sum(times_wellstallfrequ)                                                                                                           AS times_wellstallfrequ
           ,sum(NVL(times_excellentdownlink,0) + NVL(times_welldownlink,0))/sum(NVL(times_excellentdownlink,0) + NVL(times_welldownlink,0) + NVL(times_inferiordownlink,0))              AS video_good_rate_1
           ,sum(NVL(times_excellentstallfrequ,0) + NVL(times_wellstallfrequ,0))/sum(NVL(times_excellentstallfrequ,0) + NVL(times_wellstallfrequ,0) + NVL(times_inferiorstallfrequ,0))    AS video_good_rate_2
        FROM
            aggr_5g_video_cel_e2e_d
        WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
            AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
            AND interface = 100
        GROUP BY
            nodebid
           ,cellid
    ) t
) t8
ON t1.cellkey = t8.cellkey
LEFT JOIN
(
    SELECT
        cell_key
       ,AVG(score) / 100  AS video_good_rate
    FROM
        dm_untreport_cell_video_index_d
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
        AND net_type = 'NR(NR)'
    GROUP BY cell_key
) t9
ON t1.cellkey = t9.cell_key
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)                                          AS cellkey
       ,sum(duration_sum)                                                   AS web_duration
       ,sum(httpwebrspcount)                                                AS httpwebrspcount
       ,sum(httpwebreqcount)                                                AS httpwebreqcount
       ,sum(httpwebrspcount)/sum(httpwebreqcount)                           AS httpwebrsprate
       ,sum(httpwebdspdelay_avg*httpwebrspcount)/sum(httpwebrspcount)       AS httpwebdspdelay
       ,sum(httpwebscreendelay_avg*httpwebrspcount)/sum(httpwebrspcount)    AS httpwebscreendelay
       ,sum(httpwebrspcount)/sum(httpwebreqcount)                           AS web_good_rate
    FROM
        aggr_5g_web_cel_e2e_d
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
        AND interface = 100
    GROUP BY
        nodebid
       ,cellid
) t10
ON t1.cellkey = t10.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)                                          AS cellkey
       ,sum(duration_sum)                                                   AS im_duration
       ,sum(times_excellentsentrate)                                                                                                    AS messagesucccount
       ,sum(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate,0) + NVL(times_wellsentrate,0))                                 AS messagereqcount
       ,sum(times_excellentsentrate)/sum(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate,0) + NVL(times_wellsentrate,0))    AS messagesucc_rate
       ,sum(times_excellentsentrate)/sum(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate,0) + NVL(times_wellsentrate,0))    AS im_good_rate
    FROM
        aggr_5g_im_cel_e2e_d
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
        AND interface = 100
    GROUP BY
        nodebid
       ,cellid
) t11
ON t1.cellkey = t11.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,game_duration
       ,gameinteractdelay
       ,CASE
            WHEN gameinteractdelay <= 150                       THEN 1
            WHEN 100 - (gameinteractdelay - 150) * 0.75 <= 0    THEN 0
            ELSE (100 - (gameinteractdelay - 150) * 0.75) / 100
        END AS game_good_rate
    FROM
    (
        SELECT
            CONCAT(nodebid,'_',cellid)                                          AS cellkey
           ,sum(duration_sum)                                                   AS game_duration
           ,case when sum(httpwebreqcount)  !=0 then sum(gameinteractdelay_sum)/sum(httpwebreqcount) else 0 end AS gameinteractdelay
        FROM
            aggr_5g_game_cel_e2e_d
        WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
            AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
            AND interface = 100
        GROUP BY
            nodebid
           ,cellid
    ) t
) t12
ON t1.cellkey = t12.cellkey
LEFT JOIN
(
    SELECT
        cell_key                                AS cellkey
       ,sum(dns_succ_cnt)                   AS dnsqueryrspcount
       ,sum(dns_req_cnt)                        AS dnsqueryreqcount
       ,sum(dns_succ_cnt)/sum(dns_req_cnt)  AS dnsquerysuc_rate
    FROM
        aggr_nr_dpi_dns_cel_d
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
        AND interface = 100
    GROUP BY cell_key
) t13
ON t1.cellkey = t13.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,sum(case when servicetype=88888888 then httpwebrspcount else 0 end)                                                                             AS scan_pay_suc_cnt
       ,sum(case when servicetype=88888888 then httpwebreqcount else 0 end)                                                                             AS scan_pay_req_cnt
       ,sum(case when servicetype=88888888 then httpwebrspcount else 0 end)/sum(case when servicetype=88888888 then httpwebreqcount else 0 end)         AS scan_pay_suc_rate
       ,sum(case when servicetype=88888888 then tcpsetupackdelay_avg*httpwebreqcount else 0 end)/sum(case when servicetype=88888888 then httpwebreqcount else 0 end)    AS scan_pay_tcpsetupackdelay
       ,sum(case when servicetype=01000202 then httpwebrspcount else 0 end)                                                                             AS wechat_suc_cnt
       ,sum(case when servicetype=01000202 then httpwebreqcount else 0 end)                                                                             AS wechat_req_cnt
       ,sum(case when servicetype=01000202 then httpwebrspcount else 0 end)/sum(case when servicetype=01000202 then httpwebreqcount else 0 end)         AS wechat_suc_rate
    FROM
        aggr_5g_im_appcel_e2e_d
    WHERE p_provincecode = $dm_plane_scene_sector_nr_index_d.p_provincecode$
        AND p_date = '$dm_plane_scene_sector_nr_index_d.p_date$'
    GROUP BY
        nodebid
       ,cellid
) t14
ON t1.cellkey = t14.cellkey
;

