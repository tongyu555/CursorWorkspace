-- auth: goupengcheng
-- since: 2025-09-02
-- algorithm: 全量场景枚举表

INSERT OVERWRITE TABLE cfg_total_scene_enumeration
PARTITION (p_provincecode = $cfg_total_scene_enumeration.p_provincecode$)
SELECT
    provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,scene_subclass_type
    ,scene_sub_subclass_id
    ,scene_sub_subclass_id_1km
    ,scene_sub_subclass_name
    ,section_type
    ,geom
FROM
(
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,scene_type
        ,scene_subclass_id
        ,scene_subclass_name
        ,NULL AS scene_subclass_type
        ,NULL AS scene_sub_subclass_id
        ,NULL AS scene_sub_subclass_id_1km
        ,NULL AS scene_sub_subclass_name
        ,NULL AS section_type
        ,geom
    FROM
        cfg_scene_list
    WHERE p_provincecode = $cfg_total_scene_enumeration.p_provincecode$
        AND p_date = '$cfg_scene_list.p_date$'
    UNION ALL
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,9                  AS scene_type
        ,subway_line_id     AS scene_subclass_id
        ,subway_line        AS scene_subclass_name
        ,type               AS scene_subclass_type
        ,section_station_id AS scene_sub_subclass_id
        ,NULL               AS scene_sub_subclass_id_1km
        ,name               AS scene_sub_subclass_name
        ,section_type
        ,geom
    FROM
        cfg_subway_section_station
    WHERE provincecode = $cfg_total_scene_enumeration.p_provincecode$
    UNION ALL
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,11                     AS scene_type
        ,line_id                AS scene_subclass_id
        ,line_name              AS scene_subclass_name
        ,scene_subclass_type
        ,scene_subclass_id      AS scene_sub_subclass_id
        ,NULL                   AS scene_sub_subclass_id_1km
        ,scene_subclass_name    AS scene_sub_subclass_name
        ,NULL                   AS section_type
        ,geom
    FROM
        cfg_highway_vector_d
    WHERE provincecode = $cfg_total_scene_enumeration.p_provincecode$
        AND p_date = '$cfg_scene_list.p_date$'
    UNION ALL
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,11                                 AS scene_type
        ,id                                 AS scene_subclass_id
        ,name                               AS scene_subclass_name
        ,2                                  AS scene_subclass_type
        ,section_id                         AS scene_sub_subclass_id
        ,section_id_1km                     AS scene_sub_subclass_id_1km
        ,CONCAT(name,'_',section_id_1km)    AS scene_sub_subclass_name
        ,NULL                               AS section_type
        ,geom
    FROM
        cfg_highway_100m_section
    WHERE p_provincecode = $cfg_total_scene_enumeration.p_provincecode$
    UNION ALL
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,12                                 AS scene_type
        ,scene_subclass_id
        ,scene_subclass_name
        ,0                                  AS scene_subclass_type
        ,scene_sub_subclass_id
        ,scene_sub_subclass_id_1km
        ,scene_sub_subclass_name
        ,NULL                               AS section_type
        ,geom
    from
    (
        SELECT
            id                                          AS scene_subclass_id
            ,name                                       AS scene_subclass_name
            ,p_provincecode                             AS provincecode
            ,citycode
            ,section_id                                 AS scene_sub_subclass_id
            ,FLOOR(section_id / 10)                     AS scene_sub_subclass_id_1km
            ,CONCAT(name,'_',FLOOR(section_id / 10))    AS scene_sub_subclass_name
            ,geom
        from
            cfg_highrail_100m_section
        WHERE p_provincecode = $cfg_total_scene_enumeration.p_provincecode$
            AND LENGTH(id) = 10
            AND FLOOR(citycode/10000) = FLOOR(p_provincecode/10000)
    ) B1
    INNER JOIN
    (
        SELECT
            line_id
        FROM
            cfg_highspeedrail_platform
        GROUP BY line_id
    ) B2
    ON B1.scene_subclass_id = B2.line_id
    INNER JOIN
    (
        SELECT
            province_name
           ,city_id
           ,city_name
        FROM
            cfg_city
        WHERE provincecode = $cfg_total_scene_enumeration.p_provincecode$
        GROUP BY
            province_name
           ,city_id
           ,city_name
    ) B3
    ON B1.citycode = B3.city_id
) A
DISTRIBUTE BY 1
;
