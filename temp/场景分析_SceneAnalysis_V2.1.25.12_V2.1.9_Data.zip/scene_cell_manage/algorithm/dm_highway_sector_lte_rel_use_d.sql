-- auth: goupengcheng
-- since: 2025-07-22
-- algorithm: 高速线路4G小区真实计算清单天表

set spark.sql.adaptive.enabled = true;
set spark.sql.adaptive.minNumPostShufflePartitions = 10;
set spark.sql.adaptive.maxNumPostShufflePartitions = 300;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

INSERT OVERWRITE TABLE dm_highway_sector_lte_rel_use_d
PARTITION (
    p_provincecode = $dm_highway_sector_lte_rel_use_d.p_provincecode$
    ,p_date = '$dm_highway_sector_lte_rel_use_d.p_date$'
)
SELECT
    '$dm_highway_sector_lte_rel_use_d.p_date$'         AS day
    ,$dm_highway_sector_lte_rel_use_d.p_provincecode$  AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,districtcode
    ,district_name
    ,A1.scene_type                                     AS scene_type
    ,A1.line_id                                        AS line_id
    ,line_name
    ,enbid
    ,enbname
    ,cellid
    ,cellkey
    ,master_operators
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,height
    ,indoor_flag
    ,azimuth
    ,cellname
    ,vendor
    ,bandwidth
    ,cover_rate
    ,is_inside
    ,lock_flag
    ,first_date
    ,sustain_days
    ,missing_days
    -- ,case
        -- when C.NVL(automatic_update_flag,1) =1 and BAEFD.valid_flag = 0 and (BAEFD.sustain_days>C.threshold_days) then 1
        -- when C.NVL(automatic_update_flag,1) =1 and BAEFD.valid_flag = 1 and (BAEFD.missing_days>C.threshold_days) and BAEFD.lock_flag = 0 then 0
        -- when C.NVL(automatic_update_flag,1) =0  then BAEFD.valid_flag
        -- else BAEFD.valid_flag end
    ,CASE
        WHEN lock_flag = 1 THEN valid_flag
        WHEN NVL(automatic_update_flag,1) = 1 AND valid_flag = 0 AND sustain_days >= NVL(threshold_days,3) THEN 1
        WHEN NVL(automatic_update_flag,1) = 1 AND valid_flag = 1 AND missing_days >= NVL(threshold_days,3) THEN 0
        ELSE valid_flag
    END AS valid_flag
    ,is_shield
    ,insert_way
    -- case A.valid_flag = 0 and is_shield = 0 and A.sustain_days > B.threshold_days then 1 else 0 end
    -- 此处的valid_flag 为关联后的结果
    ,CASE
        WHEN NVL(automatic_update_flag,1) = 1 AND valid_flag = 1 AND missing_days >= NVL(threshold_days,3) AND sustain_days >= NVL(threshold_days,3) AND is_shield = 0 THEN 1
        WHEN lock_flag = 1 AND valid_flag = 0 AND sustain_days >= NVL(threshold_days,3) AND is_shield = 0 THEN 1
        WHEN valid_flag = 0 AND sustain_days >= NVL(threshold_days,3) AND is_shield = 0 AND NVL(automatic_update_flag,1) = 0 THEN 1
        ELSE 0
    END AS is_add_recommend
    -- case A.valid_flag = 1 and A.missing_days > B.threshold_days then 1 else 0 end
    ,CASE
        WHEN valid_flag = 1 AND missing_days >= NVL(threshold_days,3) AND NVL(automatic_update_flag,1) = 0 THEN 1
        WHEN valid_flag = 1 AND missing_days >= NVL(threshold_days,3) AND lock_flag = 1 THEN 1
        ELSE 0
    END AS is_dele_recommend
    ,CASE WHEN A3.reportcellkey IS NOT NULL THEN 1 ELSE 2 END AS correlation_results
FROM
(
    -- BAEFD
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,districtcode
        ,district_name
        ,B1.scene_type  AS scene_type
        ,B1.line_id     AS line_id
        ,line_name
        ,enbid
        ,enbname
        ,cellid
        ,B1.cellkey     AS cellkey
        ,master_operators
        ,cell_lon
        ,cell_lat
        ,freq
        ,pci
        ,height
        ,indoor_flag
        ,azimuth
        ,cellname
        ,vendor
        ,bandwidth
        ,cover_rate
        ,is_inside
        ,NVL(B3.lock_flag,B1.lock_flag) AS lock_flag
        ,first_date
        ,sustain_days
        ,missing_days
        ,CASE
            WHEN B2.operate_type = '取消屏蔽'   THEN 1
            WHEN B2.operate_type = '屏蔽'       THEN 0
            WHEN B2.cellkey IS NULL             THEN valid_flag
            WHEN B3.lock_flag = 1               THEN valid_flag
            ELSE 0
        END AS valid_flag
        ,CASE
            WHEN B2.operate_type = '屏蔽'       THEN 1
            WHEN B2.operate_type = '取消屏蔽'   THEN 0
            WHEN B2.cellkey IS NULL             THEN is_shield
            WHEN B3.lock_flag = 1               THEN is_shield
            ELSE 0
        END AS is_shield
        ,insert_way
    FROM
    (
        -- BAE
        SELECT
            NVL(C1.provincecode        ,C2.provincecode       ) AS provincecode
            ,NVL(C1.province_name      ,C2.province_name      ) AS province_name
            ,NVL(C1.citycode           ,C2.citycode           ) AS citycode
            ,NVL(C1.city_name          ,C2.city_name          ) AS city_name
            ,NVL(C1.districtcode       ,C2.districtcode       ) AS districtcode
            ,NVL(C1.district_name      ,C2.district_name      ) AS district_name
            ,NVL(C1.scene_type         ,C2.scene_type         ) AS scene_type
            ,NVL(C1.line_id            ,C2.line_id            ) AS line_id
            ,NVL(C1.line_name          ,C2.line_name          ) AS line_name
            ,NVL(C1.enbid              ,C2.enbid              ) AS enbid
            ,NVL(C1.enbname            ,C2.enbname            ) AS enbname
            ,NVL(C1.cellid             ,C2.cellid             ) AS cellid
            ,NVL(C1.cellkey            ,C2.cellkey            ) AS cellkey
            ,NVL(C1.master_operators   ,C2.master_operators   ) AS master_operators
            ,NVL(C1.cell_lon           ,C2.cell_lon           ) AS cell_lon
            ,NVL(C1.cell_lat           ,C2.cell_lat           ) AS cell_lat
            ,NVL(C1.freq               ,C2.freq               ) AS freq
            ,NVL(C1.pci                ,C2.pci                ) AS pci
            ,NVL(C1.height             ,C2.height             ) AS height
            ,NVL(C1.indoor_flag        ,C2.indoor_flag        ) AS indoor_flag
            ,NVL(C1.azimuth            ,C2.azimuth            ) AS azimuth
            ,NVL(C1.cellname           ,C2.cellname           ) AS cellname
            ,NVL(C1.vendor             ,C2.vendor             ) AS vendor
            ,NVL(C1.bandwidth          ,C2.bandwidth          ) AS bandwidth
            ,NVL(C1.cover_rate         ,C2.cover_rate         ) AS cover_rate
            ,NVL(C1.is_inside          ,C2.is_inside          ) AS is_inside
            ,NVL(C1.lock_flag          ,C2.lock_flag          ) AS lock_flag
            ,NVL(C1.first_date         ,C2.first_date         ) AS first_date
            ,CASE WHEN C1.cellkey IS NOT NULL THEN NVL(C2.sustain_days,0) + 1 ELSE NVL(C2.sustain_days,0) END AS sustain_days
            ,CASE WHEN C1.cellkey IS NOT NULL THEN 0 ELSE C2.missing_days END AS missing_days
            ,NVL(C1.is_inside,valid_flag)                       AS valid_flag
            ,CASE WHEN C1.cellkey IS NULL THEN is_shield ELSE 0 END AS is_shield
            ,CASE WHEN C1.cellkey IS NULL THEN insert_way ELSE operate_type END AS insert_way
        FROM
        (
            -- E
            -- 人工更新清单(导入，智能推荐)
            SELECT
                provincecode
                ,province_name
                ,citycode
                ,city_name
                ,districtcode
                ,district_name
                ,scene_type
                ,scene_subclass_id          AS line_id
                ,scene_subclass_name        AS line_name
                ,enbid
                ,enbname
                ,cellid
                ,cellkey
                ,master_operators
                ,cell_lon
                ,cell_lat
                ,freq
                ,pci
                ,height
                ,indoor_flag
                ,azimuth
                ,cellname
                ,vendor
                ,bandwidth
                ,cover_rate
                ,is_inside
                ,lock_flag
                ,first_date
                ,operate_type
                -- 去重
                ,ROW_NUMBER() OVER(PARTITION BY scene_subclass_id,cellkey ORDER BY cell_lon DESC) rn
            FROM
                cfg_artificial_update_scene_cell
            WHERE provincecode = $dm_highway_sector_lte_rel_use_d.p_provincecode$
                AND p_date = '$dm_highway_sector_lte_rel_use_d.p_date$'
                AND network_class = '4G'
                AND scene_type = 11
                AND operate_type IN ('手动录入','智能推荐')
                AND scene_subclass_type = 2
            HAVING rn = 1
        ) C1
        FULL JOIN
        (
            -- BA
            SELECT
                NVL(D1.provincecode        ,D2.provincecode       ) AS provincecode
                ,NVL(D1.province_name      ,D2.province_name      ) AS province_name
                ,NVL(D1.citycode           ,D2.citycode           ) AS citycode
                ,NVL(D1.city_name          ,D2.city_name          ) AS city_name
                ,NVL(D1.districtcode       ,D2.districtcode       ) AS districtcode
                ,NVL(D1.district_name      ,D2.district_name      ) AS district_name
                ,NVL(D1.scene_type         ,D2.scene_type         ) AS scene_type
                ,NVL(D1.line_id            ,D2.line_id            ) AS line_id
                ,NVL(D1.line_name          ,D2.line_name          ) AS line_name
                ,NVL(D1.enbid              ,D2.enbid              ) AS enbid
                ,NVL(D1.enbname            ,D2.enbname            ) AS enbname
                ,NVL(D1.cellid             ,D2.cellid             ) AS cellid
                ,NVL(D1.cellkey            ,D2.cellkey            ) AS cellkey
                ,NVL(D1.master_operators   ,D2.master_operators   ) AS master_operators
                ,NVL(D1.cell_lon           ,D2.cell_lon           ) AS cell_lon
                ,NVL(D1.cell_lat           ,D2.cell_lat           ) AS cell_lat
                ,NVL(D1.freq               ,D2.freq               ) AS freq
                ,NVL(D1.pci                ,D2.pci                ) AS pci
                ,NVL(D1.height             ,D2.height             ) AS height
                ,NVL(D1.indoor_flag        ,D2.indoor_flag        ) AS indoor_flag
                ,NVL(D1.azimuth            ,D2.azimuth            ) AS azimuth
                ,NVL(D1.cellname           ,D2.cellname           ) AS cellname
                ,NVL(D1.vendor             ,D2.vendor             ) AS vendor
                ,NVL(D1.bandwidth          ,D2.bandwidth          ) AS bandwidth
                ,NVL(D1.cover_rate         ,D2.cover_rate         ) AS cover_rate
                ,NVL(D1.lock_flag          ,1          )            AS lock_flag
                ,NVL(D1.first_date         ,D2.first_date         ) AS first_date
                ,NVL(D1.is_inside          ,D2.is_inside          ) AS is_inside
                ,CASE WHEN D2.cellkey IS NOT NULL THEN NVL(D1.sustain_days,0) + 1 ELSE 0 END AS sustain_days
                    -- WHEN D1.cellkey IS NOT NULL AND D2.cellkey IS NULL THEN 0
                    -- WHEN D2.cellkey IS NOT NULL AND D1.cellkey IS NOT NULL THEN D1.sustain_days + 1
                    -- WHEN D1.cellkey IS NULL AND D2.cellkey IS NOT NULL THEN 1
                    -- ELSE 0
                -- END                                                 AS sustain_days
                ,CASE WHEN D2.cellkey IS NULL THEN NVL(D1.missing_days,0) + 1 ELSE 0 END AS missing_days
                -- ,case when B.cellkey is not null and A.cellkey is null then B.missing_days+1 else 0 end
                -- B full join A 操作时该字段算法为：case when B.valid_flag is not null then B.valid_flag else 0 end
                ,NVL(valid_flag,0)                                  AS valid_flag
                -- ,case when A.cellkey is null then B.is_shield else 0 end
                ,CASE WHEN D2.cellkey IS NULL THEN is_shield ELSE 0 END AS is_shield
                -- ,B full join A 操作时该字段算法为：先计算出valid_flag，CASE WHEN valid_flag=1 THEN ‘智能推荐’else null end
                ,CASE WHEN NVL(valid_flag,0) = 1 THEN '智能推荐' ELSE NULL END AS insert_way
            FROM
            (
                -- 第一版数据
                -- SELECT
                    -- provincecode
                    -- ,province_name
                    -- ,citycode
                    -- ,city_name
                    -- ,districtcode
                    -- ,district_name
                    -- ,scene_type
                    -- ,line_id
                    -- ,line_name
                    -- ,enbid
                    -- ,enbname
                    -- ,cellid
                    -- ,cellkey
                    -- ,master_operators
                    -- ,cell_lon
                    -- ,cell_lat
                    -- ,freq
                    -- ,pci
                    -- ,height
                    -- ,indoor_flag
                    -- ,azimuth
                    -- ,cellname
                    -- ,vendor
                    -- ,bandwidth
                    -- ,cover_rate
                    -- ,1          AS is_inside
                    -- ,1          AS lock_flag
                    -- ,0          AS is_shield
                    -- ,day        AS first_date
                    -- ,1          AS sustain_days
                    -- ,0          AS missing_days
                    -- ,1          AS valid_flag
                    -- ,'智能推荐' AS insert_way
                    -- ,ROW_NUMBER() OVER(PARTITION BY line_id,cellkey ORDER BY cell_lon DESC) rn
                -- FROM
                    -- dm_highway_sector_lte_rel_d
                -- WHERE p_provincecode = $dm_highway_sector_lte_rel_use_d.p_provincecode$
                    -- AND p_date = DATE_SUB('$dm_highway_sector_lte_rel_use_d.p_date$',2)
                    -- HAVING rn = 1
                -- UNION ALL
                -- B
                -- 前一天计算
                SELECT
                    provincecode
                    ,province_name
                    ,citycode
                    ,city_name
                    ,districtcode
                    ,district_name
                    ,scene_type
                    ,line_id
                    ,line_name
                    ,enbid
                    ,enbname
                    ,cellid
                    ,cellkey
                    ,master_operators
                    ,cell_lon
                    ,cell_lat
                    ,freq
                    ,pci
                    ,height
                    ,indoor_flag
                    ,azimuth
                    ,cellname
                    ,vendor
                    ,bandwidth
                    ,cover_rate
                    ,is_inside
                    ,lock_flag
                    ,is_shield
                    ,first_date
                    ,sustain_days
                    ,missing_days
                    ,valid_flag
                    ,insert_way
                FROM
                    dm_highway_sector_lte_rel_use_d
                WHERE p_provincecode = $dm_highway_sector_lte_rel_use_d.p_provincecode$
                    AND p_date = DATE_SUB('$dm_highway_sector_lte_rel_use_d.p_date$',1)
            ) D1
            FULL JOIN
            (
                -- A
                -- 当天算法识别的
                SELECT
                    provincecode
                    ,province_name
                    ,citycode
                    ,city_name
                    ,districtcode
                    ,district_name
                    ,scene_type
                    ,line_id
                    ,line_name
                    ,enbid
                    ,enbname
                    ,cellid
                    ,cellkey
                    ,master_operators
                    ,cell_lon
                    ,cell_lat
                    ,freq
                    ,pci
                    ,height
                    ,indoor_flag
                    ,azimuth
                    ,cellname
                    ,vendor
                    ,bandwidth
                    ,1          AS cover_rate
                    ,1          AS is_inside
                    ,'$dm_highway_sector_lte_rel_use_d.p_date$'        AS first_date
                    -- 该表有千米段，但目标表没有千米段，所以需要去重
                    ,ROW_NUMBER() OVER(PARTITION BY line_id,cellkey ORDER BY cell_lon DESC) rn
                FROM
                    dm_highway_sector_lte_rel_d
                WHERE p_provincecode = $dm_highway_sector_lte_rel_use_d.p_provincecode$
                    AND p_date = '$dm_highway_sector_lte_rel_use_d.p_date$'
                HAVING rn = 1
            ) D2
            ON D1.cellkey = D2.cellkey
                AND D1.scene_type = D2.scene_type
                AND D1.line_id = D2.line_id
        ) C2
        ON C1.cellkey = C2.cellkey
            AND C1.scene_type = C2.scene_type
            AND C1.line_id = C2.line_id
    ) B1
    LEFT JOIN
    (
        -- 人工更新清单(删除，屏蔽，取消屏蔽)
        SELECT
            cellkey
            ,operate_type
            ,scene_type
            ,scene_subclass_id  AS line_id
        FROM
            cfg_artificial_update_scene_cell
        WHERE provincecode = $dm_highway_sector_lte_rel_use_d.p_provincecode$
            AND p_date = '$dm_highway_sector_lte_rel_use_d.p_date$'
            AND network_class = '4G'
            AND scene_type = 11
            AND operate_type IN ('删除','屏蔽','取消屏蔽')
            AND scene_subclass_type = 2
        GROUP BY
            cellkey
            ,operate_type
            ,scene_type
            ,scene_subclass_id
    ) B2
    ON B1.cellkey = B2.cellkey
        AND B1.scene_type = B2.scene_type
        AND B1.line_id = B2.line_id
    LEFT JOIN
    (
        -- 人工更新清单(锁定，取消锁定)
        SELECT
            cellkey
            ,CASE WHEN operate_type = '锁定' THEN 1 ELSE 0 END AS lock_flag
            ,scene_type
            ,scene_subclass_id  AS line_id
        FROM
            cfg_artificial_update_scene_cell
        WHERE provincecode = $dm_highway_sector_lte_rel_use_d.p_provincecode$
            AND p_date = '$dm_highway_sector_lte_rel_use_d.p_date$'
            AND network_class = '4G'
            AND scene_type = 11
            AND operate_type IN ('锁定','取消锁定')
            AND scene_subclass_type = 2
        GROUP BY
            cellkey
            ,operate_type
            ,scene_type
            ,scene_subclass_id
    ) B3
    ON B1.cellkey = B3.cellkey
        AND B1.scene_type = B3.scene_type
        AND B1.line_id = B3.line_id
) A1
LEFT JOIN
(
    -- 自动更新开关
    SELECT
        automatic_update_flag
        ,threshold_days
        ,scene_type
        ,scene_subclass_id  AS line_id
    FROM
        cfg_automatic_update_scene_cell
    WHERE provincecode = $dm_highway_sector_lte_rel_use_d.p_provincecode$
        AND p_date = '$dm_highway_sector_lte_rel_use_d.p_date$'
        AND scene_type = 11
        AND scene_subclass_type = 2
    GROUP BY
        automatic_update_flag
        ,threshold_days
        ,scene_type
        ,scene_subclass_id
) A2
ON A1.scene_type = A2.scene_type
    AND A1.line_id = A2.line_id
LEFT JOIN
(
    SELECT
        reportcellkey
    FROM
        lte_cm_projdata_refactor
    WHERE p_provincecode = $dm_highway_sector_lte_rel_use_d.p_provincecode$
    GROUP BY reportcellkey
) A3
ON A1.cellkey = A3.reportcellkey
;

