-- auth: goupengcheng
-- since: 2025-07-25
-- algorithm: 地铁站台路段对应5G小区真实计算清单天表

set spark.sql.adaptive.enabled = true;
set spark.sql.adaptive.minNumPostShufflePartitions = 10;
set spark.sql.adaptive.maxNumPostShufflePartitions = 300;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

INSERT OVERWRITE TABLE dm_subway_section_station_sector_nr_rel_use_d
PARTITION (
    p_provincecode = $dm_subway_section_station_sector_nr_rel_use_d.p_provincecode$
    ,p_date = '$dm_subway_section_station_sector_nr_rel_use_d.p_date$'
)
SELECT
    '$dm_subway_section_station_sector_nr_rel_use_d.p_date$'   AS day
    ,A1.provincecode                                            AS provincecode
    ,A1.province_name                                           AS province_name
    ,A1.citycode                                                AS citycode
    ,A1.city_name                                               AS city_name
    ,A1.scene_type                                              AS scene_type
    ,A1.subway_line_id                                          AS subway_line_id
    ,A1.subway_line                                             AS subway_line
    ,A1.type                                                    AS type
    ,A1.section_station_id                                      AS section_station_id
    ,A1.name                                                    AS name
    ,A1.section_type                                            AS section_type
    ,A1.is_indoor_section_station                               AS is_indoor_section_station
    ,A1.net_type                                                AS net_type
    ,A1.enbid                                                   AS enbid
    ,A1.enbname                                                 AS enbname
    ,A1.cellid                                                  AS cellid
    ,A1.cellname                                                AS cellname
    ,A1.cellkey                                                 AS cellkey
    ,A1.master_operators                                        AS master_operators
    ,A1.cell_lon                                                AS cell_lon
    ,A1.cell_lat                                                AS cell_lat
    ,CASE WHEN NVL(A1.freq,'') = '' THEN A4.freq ELSE A1.freq END AS freq
    ,NVL(A1.pci,A4.pci)                                         AS pci
    ,A1.indoor_flag                                             AS indoor_flag
    ,NVL(A1.azimuth,A4.azimuth)                                 AS azimuth
    ,CASE WHEN NVL(A1.vendor,'') = '' THEN A4.vendor ELSE A1.vendor END AS vendor
    ,NVL(A1.bandwidth,A4.bandwidth_dl)                          AS bandwidth
    ,NVL(A3.lock_flag,A1.lock_flag)                             AS lock_flag
    ,is_inside
    ,CASE WHEN A2.operate_type = '屏蔽' THEN 1 WHEN A2.operate_type = '取消屏蔽' THEN 0 ELSE A1.is_shield END AS is_shield
    ,CASE WHEN A2.operate_type = '取消屏蔽' THEN 1 WHEN A2.operate_type = '屏蔽' THEN 0 ELSE A1.valid_flag END AS valid_flag
    ,'手动录入'                     AS insert_way
    ,CASE WHEN A4.reportcellkey IS NOT NULL THEN 1 ELSE 2 END AS correlation_results
FROM
(
    SELECT
        NVL(B2.provincecode       ,B1.provincecode      ) AS provincecode
        ,NVL(B2.province_name     ,B1.province_name     ) AS province_name
        ,NVL(B2.citycode          ,B1.citycode          ) AS citycode
        ,NVL(B2.city_name         ,B1.city_name         ) AS city_name
        ,NVL(B2.scene_type        ,B1.scene_type        ) AS scene_type
        ,NVL(B2.subway_line_id    ,B1.subway_line_id    ) AS subway_line_id
        ,NVL(B2.subway_line       ,B1.subway_line       ) AS subway_line
        ,NVL(B2.type              ,B1.type              ) AS type
        ,NVL(B2.section_station_id,B1.section_station_id) AS section_station_id
        ,NVL(B2.name              ,B1.name              ) AS name
        ,NVL(B2.section_type      ,B1.section_type      ) AS section_type
        ,is_indoor_section_station
        ,NVL(B2.net_type          ,B1.net_type          ) AS net_type
        ,NVL(B2.enbid             ,B1.enbid             ) AS enbid
        ,NVL(B2.enbname           ,B1.enbname           ) AS enbname
        ,NVL(B2.cellid            ,B1.cellid            ) AS cellid
        ,NVL(B2.cellname          ,B1.cellname          ) AS cellname
        ,NVL(B2.cellkey           ,B1.cellkey           ) AS cellkey
        ,NVL(B2.master_operators  ,B1.master_operators  ) AS master_operators
        ,NVL(B2.cell_lon          ,B1.cell_lon          ) AS cell_lon
        ,NVL(B2.cell_lat          ,B1.cell_lat          ) AS cell_lat
        ,NVL(B2.freq              ,B1.freq              ) AS freq
        ,NVL(B2.pci               ,B1.pci               ) AS pci
        ,NVL(B2.indoor_flag       ,B1.indoor_flag       ) AS indoor_flag
        ,NVL(B2.azimuth           ,B1.azimuth           ) AS azimuth
        ,NVL(B2.vendor            ,B1.vendor            ) AS vendor
        ,NVL(B2.bandwidth         ,B1.bandwidth         ) AS bandwidth
        ,NVL(B2.lock_flag         ,B1.lock_flag         ) AS lock_flag
        ,NVL(B2.is_inside         ,B1.is_inside         ) AS is_inside
        ,CASE WHEN B2.cellkey IS NOT NULL THEN B1.is_shield ELSE 0 END AS is_shield
        -- ,CASE WHEN operate_type = '屏蔽' THEN 1 ELSE is_shield END AS is_shield
        ,NVL(B2.is_inside         ,B1.valid_flag        ) AS valid_flag
    FROM
    (
        -- 第一次跑使用
        -- T0数据
        -- SELECT
            -- provincecode
            -- ,province_name
            -- ,citycode
            -- ,city_name
            -- ,scene_type
            -- ,subway_line_id
            -- ,subway_line
            -- ,type
            -- ,section_station_id
            -- ,name
            -- ,section_type
            -- ,is_indoor_section_station
            -- ,net_type
            -- ,enbid
            -- ,enbname
            -- ,cellid
            -- ,cellname
            -- ,cellkey
            -- ,master_operators
            -- ,cell_lon
            -- ,cell_lat
            -- ,freq
            -- ,pci
            -- ,indoor_flag
            -- ,azimuth
            -- ,vendor
            -- ,bandwidth
            -- ,0  AS lock_flag
            -- ,1  AS is_inside
            -- ,0  AS is_shield
            -- ,1  AS valid_flag
        -- FROM
            -- cfg_subway_section_station_sector_nr_rel
        -- WHERE p_provincecode = $dm_subway_section_station_sector_nr_rel_use_d.p_provincecode$
            -- AND p_date = '$dm_subway_section_station_sector_nr_rel_use_d.p_date$'
        -- UNION ALL
        -- 前一天数据
        SELECT
            provincecode
            ,province_name
            ,citycode
            ,city_name
            ,scene_type
            ,subway_line_id
            ,subway_line
            ,type
            ,section_station_id
            ,name
            ,section_type
            ,is_indoor_section_station
            ,net_type
            ,enbid
            ,enbname
            ,cellid
            ,cellname
            ,cellkey
            ,master_operators
            ,cell_lon
            ,cell_lat
            ,freq
            ,pci
            ,indoor_flag
            ,azimuth
            ,vendor
            ,bandwidth
            ,lock_flag
            ,is_inside
            ,is_shield
            ,valid_flag
        FROM
            dm_subway_section_station_sector_nr_rel_use_d
        WHERE p_provincecode = $dm_subway_section_station_sector_nr_rel_use_d.p_provincecode$
            AND p_date = DATE_SUB('$dm_subway_section_station_sector_nr_rel_use_d.p_date$',1)
    ) B1
    FULL JOIN
    (
        -- E
        -- 人工更新清单(手动录入,智能推荐)
        SELECT
            provincecode
            ,province_name
            ,citycode
            ,city_name
            ,districtcode
            ,district_name
            ,scene_type
            ,scene_subclass_id          AS subway_line_id
            ,scene_subclass_name        AS subway_line
            ,scene_subclass_type        AS type
            ,scene_sub_subclass_id      AS section_station_id
            ,scene_sub_subclass_name    AS name
            ,section_type
            ,network_class              AS net_type
            ,enbid
            ,enbname
            ,cellid
            ,cellkey
            ,master_operators
            ,cell_lon
            ,cell_lat
            ,freq
            ,pci
            ,height
            ,indoor_flag
            ,azimuth
            ,cellname
            ,vendor
            ,bandwidth
            ,cover_rate
            ,is_inside
            ,lock_flag
            ,operate_type
            -- 去重
        FROM
            cfg_artificial_update_scene_cell
        WHERE provincecode = $dm_subway_section_station_sector_nr_rel_use_d.p_provincecode$
            AND p_date = '$dm_subway_section_station_sector_nr_rel_use_d.p_date$'
            AND network_class = '5G'
            AND scene_type = 9
            AND scene_subclass_type IN (0,1)
            AND operate_type IN ('手动录入','智能推荐')
    ) B2
    ON B1.subway_line_id = B2.subway_line_id
        AND B1.type = B2.type
        AND B1.section_station_id = B2.section_station_id
        AND B1.section_type = B2.section_type
        AND B1.net_type = B2.net_type
        AND B1.cellkey = B2.cellkey
) A1
LEFT JOIN
(
    -- 人工更新清单(删除,屏蔽,取消屏蔽)
    SELECT
        scene_subclass_id       AS subway_line_id
        ,scene_subclass_type    AS type
        ,scene_sub_subclass_id  AS section_station_id
        ,section_type
        ,network_class          AS net_type
        ,cellkey
        ,operate_type
    FROM
        cfg_artificial_update_scene_cell
    WHERE provincecode = $dm_subway_section_station_sector_nr_rel_use_d.p_provincecode$
        AND p_date = '$dm_subway_section_station_sector_nr_rel_use_d.p_date$'
        AND network_class = '5G'
        AND scene_type = 9
        AND scene_subclass_type IN (0,1)
        AND operate_type IN ('删除','屏蔽','取消屏蔽')
) A2
ON A1.subway_line_id = A2.subway_line_id
    AND A1.type = A2.type
    AND A1.section_station_id = A2.section_station_id
    AND A1.section_type = A2.section_type
    AND A1.net_type = A2.net_type
    AND A1.cellkey = A2.cellkey
LEFT JOIN
(
    -- 人工更新清单(锁定,取消锁定)
    SELECT
        scene_subclass_id       AS subway_line_id
        ,scene_subclass_type    AS type
        ,scene_sub_subclass_id  AS section_station_id
        ,section_type
        ,network_class          AS net_type
        ,cellkey
        ,CASE WHEN operate_type = '锁定' THEN 1 ELSE 0 END AS lock_flag
    FROM
        cfg_artificial_update_scene_cell
    WHERE provincecode = $dm_subway_section_station_sector_nr_rel_use_d.p_provincecode$
        AND p_date = '$dm_subway_section_station_sector_nr_rel_use_d.p_date$'
        AND network_class = '5G'
        AND scene_type = 9
        AND scene_subclass_type IN (0,1)
        AND operate_type IN ('锁定','取消锁定')
) A3
ON A1.subway_line_id = A3.subway_line_id
    AND A1.type = A3.type
    AND A1.section_station_id = A3.section_station_id
    AND A1.section_type = A3.section_type
    AND A1.net_type = A3.net_type
    AND A1.cellkey = A3.cellkey
LEFT JOIN
(
    SELECT
        cellkey AS reportcellkey
        ,freq
        ,pci
        ,bandwidth_dl
        ,vendor
        ,cell_azimuth AS azimuth
        ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDER BY freq DESC) rn
    FROM
        fact_nr_cm_projdata_refactor
    WHERE p_provincecode = $dm_subway_section_station_sector_nr_rel_use_d.p_provincecode$
    HAVING rn = 1
) A4
ON A1.cellkey = A4.reportcellkey
;

