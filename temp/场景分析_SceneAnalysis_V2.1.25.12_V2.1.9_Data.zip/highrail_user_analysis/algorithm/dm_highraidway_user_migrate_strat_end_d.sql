
CACHE TABLE tmp_group AS
SELECT
    provincecode
    ,province_name
    ,citycode
    ,city_name
    ,groupid
    ,line_id
FROM
    cfg_highrail_station_detail
;

CACHE TABLE tmp_trival_list AS
SELECT
    A2.provincecode     AS start_provincecode
    ,A2.province_name   AS start_provincename
    ,A2.citycode        AS start_citycode
    ,A2.city_name       AS start_cityname
    ,A3.provincecode    AS end_provincecode
    ,A3.province_name   AS end_provincename
    ,A3.citycode        AS end_citycode
    ,A3.city_name       AS end_cityname
    ,imsi
FROM
(
    SELECT
        line_id
        ,imsi
        ,first_groupid
        ,end_groupid
    FROM
        aggr_highspeedrail_usrlist_d
    WHERE p_date = '$dm_highraidway_user_migrate_strat_end_d.p_date$'
) A1
LEFT JOIN
    tmp_group A2
ON A1.line_id = A2.line_id
    AND A1.first_groupid = A2.groupid
LEFT JOIN
    tmp_group A3
ON A1.line_id = A3.line_id
    AND A1.end_groupid = A3.groupid
;

CACHE TABLE tmp_user_count AS
SELECT
    data_level AS data_lv
    ,provincecode
    ,citycode
    ,dir_flag
    ,usr_cnt
FROM
    dm_highraidway_user_migrate_d
WHERE p_date = '$dm_highraidway_user_migrate_strat_end_d.p_date$'
;

INSERT OVERWRITE TABLE dm_highraidway_user_migrate_strat_end_d
PARTITION (
    p_date = '$dm_highraidway_user_migrate_strat_end_d.p_date$'
)
SELECT
    '$dm_highraidway_user_migrate_strat_end_d.p_date$' AS day
    ,data_level
    ,start_provincecode
    ,end_provincecode
    ,start_provincename
    ,end_provincename
    ,start_citycode
    ,end_citycode
    ,start_cityname
    ,end_cityname
    ,usr_cnt
    ,start_out_usr_cnt
    ,end_in_usr_cnt
    ,usr_cnt / start_out_usr_cnt AS start_out_usr_rate
    ,usr_cnt / end_in_usr_cnt    AS end_in_usr_rate
FROM
(
    SELECT
        1   AS data_level
        ,start_provincecode
        ,end_provincecode
        ,start_provincename
        ,end_provincename
        ,start_citycode
        ,end_citycode
        ,start_cityname
        ,end_cityname
        ,COUNT(DISTINCT imsi) AS usr_cnt
        ,2  AS start_lv
        ,2  AS end_lv
    FROM
        tmp_trival_list
    GROUP BY
        start_provincecode
        ,end_provincecode
        ,start_provincename
        ,end_provincename
        ,start_citycode
        ,end_citycode
        ,start_cityname
        ,end_cityname
    UNION ALL
    SELECT
        2   AS data_level
        ,start_provincecode
        ,end_provincecode
        ,start_provincename
        ,end_provincename
        ,NULL   AS start_citycode
        ,end_citycode
        ,NULL   AS start_cityname
        ,end_cityname
        ,COUNT(DISTINCT imsi) AS usr_cnt
        ,1  AS start_lv
        ,2  AS end_lv
    FROM
        tmp_trival_list
    GROUP BY
        start_provincecode
        ,end_provincecode
        ,start_provincename
        ,end_provincename
        ,end_citycode
        ,end_cityname
    UNION ALL
    SELECT
        3   AS data_level
        ,start_provincecode
        ,end_provincecode
        ,start_provincename
        ,end_provincename
        ,start_citycode
        ,NULL   AS end_citycode
        ,start_cityname
        ,NULL   AS end_cityname
        ,COUNT(DISTINCT imsi) AS usr_cnt
        ,2  AS start_lv
        ,1  AS end_lv
    FROM
        tmp_trival_list
    GROUP BY
        start_provincecode
        ,end_provincecode
        ,start_provincename
        ,end_provincename
        ,start_citycode
        ,start_cityname
    UNION ALL
    SELECT
        4   AS data_level
        ,start_provincecode
        ,end_provincecode
        ,start_provincename
        ,end_provincename
        ,NULL   AS start_citycode
        ,NULL   AS end_citycode
        ,NULL   AS start_cityname
        ,NULL   AS end_cityname
        ,COUNT(DISTINCT imsi) AS usr_cnt
        ,1  AS start_lv
        ,1  AS end_lv
    FROM
        tmp_trival_list
    GROUP BY
        start_provincecode
        ,end_provincecode
        ,start_provincename
        ,end_provincename
) A1
LEFT JOIN
(
    SELECT
        data_lv
        ,provincecode
        ,citycode
        ,usr_cnt AS end_in_usr_cnt
    FROM
        tmp_user_count
    WHERE dir_flag = '迁入'
) A2
ON A1.end_lv = A2.data_lv
    AND A1.end_provincecode = A2.provincecode
    AND NVL(A1.end_citycode,0) = NVL(A2.citycode,0)
LEFT JOIN
(
    SELECT
        data_lv
        ,provincecode
        ,citycode
        ,usr_cnt AS start_out_usr_cnt
    FROM
        tmp_user_count
    WHERE dir_flag = '迁出'
) A3
ON A1.start_lv = A3.data_lv
    AND A1.start_provincecode = A3.provincecode
    AND NVL(A1.start_citycode,0) = NVL(A3.citycode,0)
DISTRIBUTE BY 1
;

