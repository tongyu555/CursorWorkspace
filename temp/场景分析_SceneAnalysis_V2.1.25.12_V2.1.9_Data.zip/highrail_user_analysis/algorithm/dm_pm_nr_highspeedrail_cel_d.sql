-- 20250718 updateby : goupengcheng 10207
-- algorithm : 修改小区表
set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

INSERT OVERWRITE TABLE dm_pm_nr_highspeedrail_cel_d
PARTITION (
    p_provincecode = $dm_pm_nr_highspeedrail_cel_d.p_provincecode$
    ,p_date = '$dm_pm_nr_highspeedrail_cel_d.p_date$'
)
SELECT
    '$dm_pm_nr_highspeedrail_cel_d.p_date$'         AS day
    ,lineid
    ,line_name
    ,$dm_pm_nr_highspeedrail_cel_d.p_provincecode$   AS provincecode
    ,t1.cellkey                                      AS cellkey
    ,qos_initialestabsucc_busy
    ,qos_initialestabreq_busy
    ,ng_connsucc_busy
    ,ng_connatt_busy
    ,ue_normalcontextrelease_busy
    ,ue_contextrelease_busy
    ,rlc_txbytesdl_busy
    ,rlc_lasttxbytesdl_busy
    ,rlc_txtimedl_exceptlastslot_busy
    ,rrc_connsucc_busy
    ,rrc_connreq_busy
    ,cqi_numintable_cqi0_busy
    ,cqi_numintable_cqi1_busy
    ,cqi_numintable_cqi2_busy
    ,cqi_numintable_cqi3_busy
    ,cqi_numintable_cqi4_busy
    ,cqi_numintable_cqi5_busy
    ,cqi_numintable_cqi6_busy
    ,cqi_numintable_cqi7_busy
    ,cqi_numintable_cqi8_busy
    ,cqi_numintable_cqi9_busy
    ,cqi_numintable_cqi10_busy
    ,cqi_numintable_cqi11_busy
    ,cqi_numintable_cqi12_busy
    ,cqi_numintable_cqi13_busy
    ,cqi_numintable_cqi14_busy
    ,cqi_numintable_cqi15_busy
    ,cqi_numintable2_cqi0_busy
    ,cqi_numintable2_cqi1_busy
    ,cqi_numintable2_cqi2_busy
    ,cqi_numintable2_cqi3_busy
    ,cqi_numintable2_cqi4_busy
    ,cqi_numintable2_cqi5_busy
    ,cqi_numintable2_cqi6_busy
    ,cqi_numintable2_cqi7_busy
    ,cqi_numintable2_cqi8_busy
    ,cqi_numintable2_cqi9_busy
    ,cqi_numintable2_cqi10_busy
    ,cqi_numintable2_cqi11_busy
    ,cqi_numintable2_cqi12_busy
    ,cqi_numintable2_cqi13_busy
    ,cqi_numintable2_cqi14_busy
    ,cqi_numintable2_cqi15_busy
    ,prb_useddl_busy
    ,prb_availdl_busy
    ,citycode
    ,rlc_rxbytesul_busy
    ,rlc_lastrxbytesul_busy
    ,rlc_rxtimeul_exceptlastslot_busy
    ,vonr_ho_atttovolte_busy
    ,vonr_ho_succtovolte_busy
    ,vonr_rtp_rxpktul_busy
    ,vonr_rtp_losspktul_busy
    ,vonr_rtp_rxpktdl_busy
    ,vonr_rtp_losspktdl_busy
    ,vonr_connreq_busy
    ,vonr_connsucc_busy
    ,vonr_releasesum_busy
    ,vonr_normalrelease_busy
    ,ho_succintragnb_busy
    ,ho_succbyxn_busy
    ,ho_succbyng_busy
    ,ho_attintragnb_busy
    ,ho_attbyxn_busy
    ,ho_attbyng_busy
    ,rrc_connreestabreq_busy
    ,rrc_connreestabsucc_busy
    ,phy_meannlperprbul_busy
FROM
(
    SELECT
        lineid
        ,line_name as line_name
        ,provincecode as provincecode
        ,cellkey as cellkey
        ,p_date
        ,citycode
    FROM
        -- 切换数据源
        dm_highrail_user_line_nr_all_cell_use_d
    -- 添加省分区及过滤条件
    WHERE p_provincecode = $dm_pm_nr_highspeedrail_cel_d.p_provincecode$
        AND p_date = '$dm_pm_nr_highspeedrail_cel_d.p_date$'
        AND valid_flag = 1
        -- dm_highrail_user_line_nr_all_cell_d
    -- WHERE p_date = '$dm_pm_nr_highspeedrail_cel_d.p_date$'
) t1
LEFT JOIN
(
    -- 忙时pm数据
    SELECT
        cellkey
        ,p_hour
        ,rlc_txbytesdl_busy
        ,rlc_lasttxbytesdl_busy
        ,rlc_txtimedl_exceptlastslot_busy
        ,rlc_rxbytesul_busy
        ,rlc_lastrxbytesul_busy
        ,rlc_rxtimeul_exceptlastslot_busy
       ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDER BY flux DESC) rn
    FROM
    (
        -- ldu pm小时数据
        SELECT
            CONCAT_WS('_',split(cel_id,'-')[1],split(cel_id,'-')[2])    AS cellkey
            ,p_hour
            ,SUM(NVL(rlc_rxbytesul,0) + NVL(rlc_txbytesdl,0))            AS flux
            ,SUM(rlc_txbytesdl)                                          AS rlc_txbytesdl_busy
            ,SUM(rlc_lasttxbytesdl)                                      AS rlc_lasttxbytesdl_busy
            ,SUM(rlc_txtimedl_exceptlastslot)                            AS rlc_txtimedl_exceptlastslot_busy
            ,sum(rlc_rxbytesul) rlc_rxbytesul_busy
            ,sum(rlc_lastrxbytesul) rlc_lastrxbytesul_busy
            ,sum(rlc_rxtimeul_exceptlastslot) rlc_rxtimeul_exceptlastslot_busy
        FROM
            fact_pm_nr_lceldu_h
        WHERE p_provincecode = $dm_pm_nr_highspeedrail_cel_d.p_provincecode$
            AND p_date = '$dm_pm_nr_highspeedrail_cel_d.p_date$'
            AND SPLIT(cel_id,'-')[0] = '46011'
        GROUP BY
            CONCAT_WS('_',split(cel_id,'-')[1],split(cel_id,'-')[2])
            ,p_hour
    ) t
    HAVING rn = 1
) t2
ON t1.cellkey = t2.cellkey
LEFT JOIN
(
    -- lcu pm小时数据
    SELECT
        p_hour
        ,CONCAT_WS('_',split(cel_id,'-')[1],split(cel_id,'-')[2]) AS cellkey
        ,SUM(qos_initialestabsucc)       AS qos_initialestabsucc_busy
        ,SUM(case when  qos_initialestabreq<qos_initialestabsucc then qos_initialestabsucc else qos_initialestabreq end)        AS qos_initialestabreq_busy
        ,SUM(ng_connsucc)                AS ng_connsucc_busy
        ,SUM(case when  ng_connatt<ng_connsucc then ng_connsucc else ng_connatt end)                 AS ng_connatt_busy
        ,SUM(ue_normalcontextrelease)    AS ue_normalcontextrelease_busy
        ,SUM(case when  ue_contextrelease<ue_normalcontextrelease then ue_normalcontextrelease else ue_contextrelease end)          AS ue_contextrelease_busy
        ,sum(case when  vonr_ho_atttovolte<vonr_ho_succtovolte then vonr_ho_succtovolte else vonr_ho_atttovolte end) as vonr_ho_atttovolte_busy
        ,sum(vonr_ho_succtovolte) as vonr_ho_succtovolte_busy
        ,sum(case when  vonr_rtp_rxpktul<vonr_rtp_losspktul then vonr_rtp_losspktul else vonr_rtp_rxpktul end) as vonr_rtp_rxpktul_busy
        ,sum(vonr_rtp_losspktul) as vonr_rtp_losspktul_busy
        ,sum(case when  vonr_rtp_rxpktdl<vonr_rtp_losspktdl then vonr_rtp_losspktdl else vonr_rtp_rxpktdl end) as vonr_rtp_rxpktdl_busy
        ,sum(vonr_rtp_losspktdl) as vonr_rtp_losspktdl_busy
        ,sum(case when  vonr_connreq<vonr_connsucc then vonr_connsucc else vonr_connreq end) as vonr_connreq_busy
        ,sum(vonr_connsucc) as vonr_connsucc_busy
        ,sum(case when  vonr_releasesum<vonr_normalrelease then vonr_normalrelease else vonr_releasesum end) as vonr_releasesum_busy
        ,sum(vonr_normalrelease) as vonr_normalrelease_busy
        ,sum(ho_succintragnb) as ho_succintragnb_busy
        ,sum(ho_succbyxn) as ho_succbyxn_busy
        ,sum(ho_succbyng) as ho_succbyng_busy
        ,sum(case when ho_attintragnb<ho_succintragnb then ho_succintragnb else ho_attintragnb end) as ho_attintragnb_busy
        ,sum(case when ho_attbyxn<ho_succbyxn then ho_succbyxn else ho_attbyxn end) as ho_attbyxn_busy
        ,sum(case when ho_attbyng<ho_succbyng then ho_succbyng else ho_attbyng end) as ho_attbyng_busy
    FROM
        fact_pm_nr_lcelcu_h
    WHERE p_provincecode = $dm_pm_nr_highspeedrail_cel_d.p_provincecode$
        AND p_date = '$dm_pm_nr_highspeedrail_cel_d.p_date$'
        AND SPLIT(cel_id,'-')[0] = '46011'
        AND qos_initialestabsucc <= qos_initialestabreq
        AND ng_connsucc <= ng_connatt
    GROUP BY
        p_hour
        ,CONCAT_WS('_',split(cel_id,'-')[1],split(cel_id,'-')[2])
) t3
ON t1.cellkey = t3.cellkey
    AND t2.p_hour = t3.p_hour
LEFT JOIN
(
    -- celcu pm小时数据
    SELECT
        p_hour
        ,CONCAT_WS('_',split(cel_id,'-')[1],split(cel_id,'-')[2]) AS cellkey
        ,SUM(rrc_connsucc)   AS rrc_connsucc_busy
        ,SUM(case when  rrc_connreq<rrc_connsucc then rrc_connsucc else rrc_connreq end)    AS rrc_connreq_busy
        ,sum(case when rrc_connreestabreq<rrc_connreestabsucc then rrc_connreestabsucc else rrc_connreestabreq end) as rrc_connreestabreq_busy
        ,sum(rrc_connreestabsucc) as rrc_connreestabsucc_busy
    FROM
        fact_pm_nr_cellcu_h
    WHERE p_provincecode = $dm_pm_nr_highspeedrail_cel_d.p_provincecode$
        AND p_date = '$dm_pm_nr_highspeedrail_cel_d.p_date$'
        AND SPLIT(cel_id,'-')[0] = '46011'
        AND rrc_connsucc <= rrc_connreq
    GROUP BY
        p_hour
        ,CONCAT_WS('_',split(cel_id,'-')[1],split(cel_id,'-')[2])
) t4
ON t1.cellkey = t4.cellkey
    AND t2.p_hour = t4.p_hour
LEFT JOIN
(
    -- celdu pm小时数据
    SELECT
        p_hour
        ,CONCAT_WS('_',split(cel_id,'-')[1],split(cel_id,'-')[2]) AS cellkey
        ,SUM(cqi_numintable_cqi0)                                 AS cqi_numintable_cqi0_busy
        ,SUM(cqi_numintable_cqi1)                                 AS cqi_numintable_cqi1_busy
        ,SUM(cqi_numintable_cqi2)                                 AS cqi_numintable_cqi2_busy
        ,SUM(cqi_numintable_cqi3)                                 AS cqi_numintable_cqi3_busy
        ,SUM(cqi_numintable_cqi4)                                 AS cqi_numintable_cqi4_busy
        ,SUM(cqi_numintable_cqi5)                                 AS cqi_numintable_cqi5_busy
        ,SUM(cqi_numintable_cqi6)                                 AS cqi_numintable_cqi6_busy
        ,SUM(cqi_numintable_cqi7)                                 AS cqi_numintable_cqi7_busy
        ,SUM(cqi_numintable_cqi8)                                 AS cqi_numintable_cqi8_busy
        ,SUM(cqi_numintable_cqi9)                                 AS cqi_numintable_cqi9_busy
        ,SUM(cqi_numintable_cqi10)                                AS cqi_numintable_cqi10_busy
        ,SUM(cqi_numintable_cqi11)                                AS cqi_numintable_cqi11_busy
        ,SUM(cqi_numintable_cqi12)                                AS cqi_numintable_cqi12_busy
        ,SUM(cqi_numintable_cqi13)                                AS cqi_numintable_cqi13_busy
        ,SUM(cqi_numintable_cqi14)                                AS cqi_numintable_cqi14_busy
        ,SUM(cqi_numintable_cqi15)                                AS cqi_numintable_cqi15_busy
        ,SUM(cqi_numintable2_cqi0)                                AS cqi_numintable2_cqi0_busy
        ,SUM(cqi_numintable2_cqi1)                                AS cqi_numintable2_cqi1_busy
        ,SUM(cqi_numintable2_cqi2)                                AS cqi_numintable2_cqi2_busy
        ,SUM(cqi_numintable2_cqi3)                                AS cqi_numintable2_cqi3_busy
        ,SUM(cqi_numintable2_cqi4)                                AS cqi_numintable2_cqi4_busy
        ,SUM(cqi_numintable2_cqi5)                                AS cqi_numintable2_cqi5_busy
        ,SUM(cqi_numintable2_cqi6)                                AS cqi_numintable2_cqi6_busy
        ,SUM(cqi_numintable2_cqi7)                                AS cqi_numintable2_cqi7_busy
        ,SUM(cqi_numintable2_cqi8)                                AS cqi_numintable2_cqi8_busy
        ,SUM(cqi_numintable2_cqi9)                                AS cqi_numintable2_cqi9_busy
        ,SUM(cqi_numintable2_cqi10)                               AS cqi_numintable2_cqi10_busy
        ,SUM(cqi_numintable2_cqi11)                               AS cqi_numintable2_cqi11_busy
        ,SUM(cqi_numintable2_cqi12)                               AS cqi_numintable2_cqi12_busy
        ,SUM(cqi_numintable2_cqi13)                               AS cqi_numintable2_cqi13_busy
        ,SUM(cqi_numintable2_cqi14)                               AS cqi_numintable2_cqi14_busy
        ,SUM(cqi_numintable2_cqi15)                               AS cqi_numintable2_cqi15_busy
        ,SUM(prb_useddl)                                          AS prb_useddl_busy
        ,SUM(prb_availdl)                                         AS prb_availdl_busy
        ,SUM(if(phy_meannlperprbul not in ('Nan','NaN','NAN'),phy_meannlperprbul,0)) as phy_meannlperprbul_busy
    FROM
        fact_pm_nr_celldu_h
    WHERE p_provincecode = $dm_pm_nr_highspeedrail_cel_d.p_provincecode$
        AND p_date = '$dm_pm_nr_highspeedrail_cel_d.p_date$'
        AND SPLIT(cel_id,'-')[0] = '46011'
    GROUP BY
        p_hour
        ,CONCAT_WS('_',split(cel_id,'-')[1],split(cel_id,'-')[2])
) t5
ON t1.cellkey = t5.cellkey
    AND t2.p_hour = t5.p_hour
;

