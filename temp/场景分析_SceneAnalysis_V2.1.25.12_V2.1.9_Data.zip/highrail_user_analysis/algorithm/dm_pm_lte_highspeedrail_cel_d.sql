-- 20250716 updateby : goupengcheng 10207
-- algorithm : 修改小区表
set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

INSERT OVERWRITE TABLE dm_pm_lte_highspeedrail_cel_d
PARTITION (
    p_provincecode = $dm_pm_lte_highspeedrail_cel_d.p_provincecode$
    ,p_date = '$dm_pm_lte_highspeedrail_cel_d.p_date$'
)
SELECT
    t1.p_date        AS day
    ,lineid
    ,line_name
    ,t1.provincecode  AS provincecode
    ,t1.cellkey                                      AS cellkey
    ,cell_servtime_rate_4g
    ,pdcp_sdulosspktul_qci1_busy
    ,pdcp_sdupktul_qci1_busy
    ,pdcp_sdulosspktdl_qci1_busy
    ,pdcp_sdupktdl_qci1_busy
    ,pdcp_sduoctul_busy
    ,pdcp_sdutailflowul_busy
    ,pdcp_thrptimeul_busy
    ,pdcp_tailtimeul_busy
    ,pdcp_sduoctdl_busy
    ,pdcp_sdutailflowdl_busy
    ,pdcp_thrptimedl_busy
    ,pdcp_tailtimedl_busy
    ,erab_abnormrel_qci1_busy
    ,erab_normrel_qci1_busy
    ,rrc_attconnestab_ue_busy
    ,rrc_succconnestab_ue_busy
    ,rrc_attconnestab_net_busy
    ,rrc_succconnestab_net_busy
    ,s1sig_attconnestab_busy
    ,s1sig_succconnestab_busy
    ,erab_initattestab_qci1_busy
    ,erab_initsuccestab_qci1_busy
    ,erab_addattestab_qci1_busy
    ,erab_addsuccestab_qci1_busy
    ,puschprbtotmeandl_busy
    ,prb_dl_avail_busy
    ,cqi7_busy
    ,cqi8_busy
    ,cqi9_busy
    ,cqi10_busy
    ,cqi11_busy
    ,cqi12_busy
    ,cqi13_busy
    ,cqi14_busy
    ,cqi15_busy
    ,cqi_busy
    ,uecntx_abnormrel_busy
    ,uecntx_normrel_busy
    ,citycode
    ,erab_initattestab_busy
    ,erab_initsuccestab_busy
    ,erab_addattestab_busy
    ,erab_addsuccestab_busy
    ,erab_abnormrel_busy
    ,erab_normrel_busy
    ,ho_succoutintraenb_busy
    ,ho_succoutx2_busy
    ,ho_succouts1_busy
    ,ho_attoutintraenb_busy
    ,ho_attoutx2_busy
    ,ho_attouts1_busy
    ,rssimean_busy
    ,rrc_succconnreestab_busy
    ,rrc_attconnreestab_busy
FROM
(
    -- 高铁小区
    select
        lineid
        ,line_name as line_name
        ,provincecode as provincecode
        ,cellkey as cellkey
        ,p_date
        ,citycode
    from
        -- 变更输入表
        dm_highrail_user_line_lte_all_cell_use_d
    where p_date = '$dm_pm_lte_highspeedrail_cel_d.p_date$'
        -- 输入表修改为有省分区，添加过滤条件
        AND p_provincecode = $dm_pm_lte_highspeedrail_cel_d.p_provincecode$
        -- 场景小区过滤条件
        AND valid_flag = 1
) t1
LEFT JOIN
(
    -- 忙时pm数据
    SELECT
        cellkey
        ,pdcp_sdulosspktul_qci1_busy
        ,pdcp_sdupktul_qci1_busy
        ,pdcp_sdulosspktdl_qci1_busy
        ,pdcp_sdupktdl_qci1_busy
        ,pdcp_sduoctul_busy
        ,pdcp_sdutailflowul_busy
        ,pdcp_thrptimeul_busy
        ,pdcp_tailtimeul_busy
        ,pdcp_sduoctdl_busy
        ,pdcp_sdutailflowdl_busy
        ,pdcp_thrptimedl_busy
        ,pdcp_tailtimedl_busy
        ,erab_abnormrel_qci1_busy
        ,erab_normrel_qci1_busy
        ,rrc_attconnestab_ue_busy
        ,rrc_succconnestab_ue_busy
        ,rrc_attconnestab_net_busy
        ,rrc_succconnestab_net_busy
        ,s1sig_attconnestab_busy
        ,s1sig_succconnestab_busy
        ,erab_initattestab_qci1_busy
        ,erab_initsuccestab_qci1_busy
        ,erab_addattestab_qci1_busy
        ,erab_addsuccestab_qci1_busy
        ,puschprbtotmeandl_busy
        ,prb_dl_avail_busy
        ,cqi7_busy
        ,cqi8_busy
        ,cqi9_busy
        ,cqi10_busy
        ,cqi11_busy
        ,cqi12_busy
        ,cqi13_busy
        ,cqi14_busy
        ,cqi15_busy
        ,cqi_busy
        ,uecntx_abnormrel_busy
        ,uecntx_normrel_busy
        ,erab_initattestab_busy
        ,erab_initsuccestab_busy
        ,erab_addattestab_busy
        ,erab_addsuccestab_busy
        ,erab_abnormrel_busy
        ,erab_normrel_busy
        ,ho_succoutintraenb_busy
        ,ho_succoutx2_busy
        ,ho_succouts1_busy
        ,ho_attoutintraenb_busy
        ,ho_attoutx2_busy
        ,ho_attouts1_busy
        ,rssimean_busy
        ,rrc_succconnreestab_busy
        ,rrc_attconnreestab_busy
        ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDER BY flux DESC) rn
    FROM
    (
        -- 小区小时指标汇总
        SELECT
            CONCAT(related_enb_id,'_',cel_id)                   AS cellkey
            ,p_hour
            ,SUM(NVL(pdcp_sduoctul,0) + NVL(pdcp_sduoctdl,0))    AS flux
            ,SUM(pdcp_sdulosspktul_qci1)                         AS pdcp_sdulosspktul_qci1_busy
            ,SUM(case when pdcp_sdupktul_qci1<pdcp_sdulosspktul_qci1 then pdcp_sdulosspktul_qci1 else pdcp_sdupktul_qci1 end)                             AS pdcp_sdupktul_qci1_busy
            ,SUM(pdcp_sdulosspktdl_qci1)                         AS pdcp_sdulosspktdl_qci1_busy
            ,SUM(case when pdcp_sdupktdl_qci1<pdcp_sdulosspktdl_qci1 then pdcp_sdulosspktdl_qci1 else pdcp_sdupktdl_qci1 end)                             AS pdcp_sdupktdl_qci1_busy
            ,SUM(pdcp_sduoctul)                                  AS pdcp_sduoctul_busy
            ,SUM(pdcp_sdutailflowul)                             AS pdcp_sdutailflowul_busy
            ,SUM(pdcp_thrptimeul)                                AS pdcp_thrptimeul_busy
            ,SUM(pdcp_tailtimeul)                                AS pdcp_tailtimeul_busy
            ,SUM(pdcp_sduoctdl)                                  AS pdcp_sduoctdl_busy
            ,SUM(pdcp_sdutailflowdl)                             AS pdcp_sdutailflowdl_busy
            ,SUM(pdcp_thrptimedl)                                AS pdcp_thrptimedl_busy
            ,SUM(pdcp_tailtimedl)                                AS pdcp_tailtimedl_busy
            ,SUM(erab_abnormrel_qci1)                            AS erab_abnormrel_qci1_busy
            ,SUM(erab_normrel_qci1)                              AS erab_normrel_qci1_busy
            ,SUM(case when rrc_attconnestab_ue<rrc_succconnestab_ue then rrc_succconnestab_ue else rrc_attconnestab_ue end)                            AS rrc_attconnestab_ue_busy
            ,SUM(rrc_succconnestab_ue)                           AS rrc_succconnestab_ue_busy
            ,SUM(case when rrc_attconnestab_net<rrc_succconnestab_net then rrc_succconnestab_net else rrc_attconnestab_net end)                           AS rrc_attconnestab_net_busy
            ,SUM(rrc_succconnestab_net)                          AS rrc_succconnestab_net_busy
            ,SUM(case when s1sig_attconnestab<s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end)                             AS s1sig_attconnestab_busy
            ,SUM(s1sig_succconnestab)                            AS s1sig_succconnestab_busy
            ,SUM(case when erab_initattestab_qci1<erab_initsuccestab_qci1 then erab_initsuccestab_qci1 else erab_initattestab_qci1 end)                         AS erab_initattestab_qci1_busy
            ,SUM(erab_initsuccestab_qci1)                        AS erab_initsuccestab_qci1_busy
            ,SUM(case when erab_addattestab_qci1<erab_addsuccestab_qci1 then erab_addsuccestab_qci1 else erab_addattestab_qci1 end)                          AS erab_addattestab_qci1_busy
            ,SUM(erab_addsuccestab_qci1)                         AS erab_addsuccestab_qci1_busy
            ,SUM(puschprbtotmeandl)                              AS puschprbtotmeandl_busy
            ,SUM(prb_dl_avail)                                   AS prb_dl_avail_busy
            ,SUM(cqi7)                                           AS cqi7_busy
            ,SUM(cqi8)                                           AS cqi8_busy
            ,SUM(cqi9)                                           AS cqi9_busy
            ,SUM(cqi10)                                          AS cqi10_busy
            ,SUM(cqi11)                                          AS cqi11_busy
            ,SUM(cqi12)                                          AS cqi12_busy
            ,SUM(cqi13)                                          AS cqi13_busy
            ,SUM(cqi14)                                          AS cqi14_busy
            ,SUM(cqi15)                                          AS cqi15_busy
            ,SUM(cqi)                                            AS cqi_busy
            ,SUM(uecntx_abnormrel)                               AS uecntx_abnormrel_busy
            ,SUM(uecntx_normrel)                                 AS uecntx_normrel_busy
            ,sum(case when erab_initattestab<erab_initsuccestab then erab_initsuccestab else erab_initattestab end) as erab_initattestab_busy
            ,sum(erab_initsuccestab) as erab_initsuccestab_busy
            ,sum(case when erab_addattestab<erab_addsuccestab then erab_addsuccestab else erab_addattestab end) as erab_addattestab_busy
            ,sum(erab_addsuccestab) as erab_addsuccestab_busy
            ,sum(erab_abnormrel) as erab_abnormrel_busy
            ,sum(erab_normrel) as erab_normrel_busy
            ,sum(ho_succoutintraenb) as ho_succoutintraenb_busy
            ,sum(ho_succoutx2) as ho_succoutx2_busy
            ,sum(ho_succouts1) as ho_succouts1_busy
            ,sum(case when ho_attoutintraenb<ho_succoutintraenb then ho_succoutintraenb else ho_attoutintraenb end) as ho_attoutintraenb_busy
            ,sum(case when ho_attoutx2<ho_succoutx2 then ho_succoutx2 else ho_attoutx2 end) as ho_attoutx2_busy
            ,sum(case when ho_attouts1<ho_succouts1 then ho_succouts1 else ho_attouts1 end) as ho_attouts1_busy
            ,null as rssimean_busy
            ,sum(rrc_succconnreestab) as rrc_succconnreestab_busy
            ,sum(case when rrc_attconnreestab<rrc_succconnreestab then rrc_succconnreestab else rrc_attconnreestab end) as rrc_attconnreestab_busy
        FROM
            itg_pm_lte_cel_h_cel_d
        WHERE p_provincecode = $dm_pm_lte_highspeedrail_cel_d.p_provincecode$
            AND p_date = '$dm_pm_lte_highspeedrail_cel_d.p_date$'
        GROUP BY
            CONCAT(related_enb_id,'_',cel_id)
           ,p_hour
    ) t
    HAVING rn = 1
) t2
ON t1.cellkey = t2.cellkey
LEFT JOIN
(
    -- 天pm数据汇总
    SELECT
        CONCAT(related_enb_id,'_',cel_id)   AS cellkey
       ,AVG(cell_servtime_rate) AS cell_servtime_rate_4g
    FROM
        itg_pm_lte_cel_h_cel_d
    WHERE p_provincecode = $dm_pm_lte_highspeedrail_cel_d.p_provincecode$
        AND p_date = '$dm_pm_lte_highspeedrail_cel_d.p_date$'
        AND p_hour >= 6
        AND p_hour <= 22
    GROUP BY CONCAT(related_enb_id,'_',cel_id)
) t3
ON t1.cellkey = t3.cellkey
;

