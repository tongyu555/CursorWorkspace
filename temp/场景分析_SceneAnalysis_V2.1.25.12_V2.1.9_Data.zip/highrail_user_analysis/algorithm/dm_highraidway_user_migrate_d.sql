CACHE TABLE tmp_group AS
SELECT
    provincecode
    ,province_name
    ,citycode
    ,city_name
    ,groupid
    ,line_id
FROM
    cfg_highrail_station_detail
;

CACHE TABLE tmp_trival_list AS
SELECT
    A2.provincecode     AS first_provincecode
    ,A2.province_name   AS first_province_name
    ,A2.citycode        AS first_citycode
    ,A2.city_name       AS first_city_name
    ,A3.provincecode    AS end_provincecode
    ,A3.province_name   AS end_province_name
    ,A3.citycode        AS end_citycode
    ,A3.city_name       AS end_city_name
    ,imsi
FROM
(
    SELECT
        line_id
        ,imsi
        ,first_groupid
        ,end_groupid
    FROM
        aggr_highspeedrail_usrlist_d
    WHERE p_date = '$dm_highraidway_user_migrate_d.p_date$'
) A1
LEFT JOIN
    tmp_group A2
ON A1.line_id = A2.line_id
    AND A1.first_groupid = A2.groupid
LEFT JOIN
    tmp_group A3
ON A1.line_id = A3.line_id
    AND A1.end_groupid = A3.groupid
;

INSERT OVERWRITE TABLE dm_highraidway_user_migrate_d
PARTITION (
    p_date = '$dm_highraidway_user_migrate_d.p_date$'
)
SELECT
    '$dm_highraidway_user_migrate_d.p_date$'    AS day
    ,data_level
    ,provincecode
    ,provincename
    ,citycode
    ,cityname
    ,dir_flag
    ,usr_cnt
    ,country_migrate_usr_cnt
    ,usr_cnt / country_migrate_usr_cnt AS migrate_rate
FROM
(
    SELECT
        first_provincecode      AS provincecode
        ,first_province_name    AS provincename
        ,first_citycode         AS citycode
        ,first_city_name        AS cityname
        ,'迁出'                 AS dir_flag
        ,COUNT(DISTINCT imsi)   AS usr_cnt
        ,CASE WHEN first_citycode IS NOT NULL THEN 2 ELSE 1 END AS data_level
    FROM
        tmp_trival_list
    WHERE first_provincecode IS NOT NULL
        AND first_citycode IS NOT NULL
    GROUP BY
        first_provincecode
        ,first_province_name
        ,first_citycode
        ,first_city_name
    GROUPING SETS(
        (first_provincecode,first_province_name,first_citycode,first_city_name)
        ,(first_provincecode,first_province_name)
    )
    UNION ALL
    SELECT
        end_provincecode        AS provincecode
        ,end_province_name      AS provincename
        ,end_citycode           AS citycode
        ,end_city_name          AS cityname
        ,'迁入'                 AS dir_flag
        ,COUNT(DISTINCT imsi)   AS usr_cnt
        ,CASE WHEN end_citycode IS NOT NULL THEN 2 ELSE 1 END AS data_level
    FROM
        tmp_trival_list
    WHERE end_provincecode IS NOT NULL
        AND end_citycode IS NOT NULL
    GROUP BY
        end_provincecode
        ,end_province_name
        ,end_citycode
        ,end_city_name
    GROUPING SETS(
        (end_provincecode,end_province_name,end_citycode,end_city_name)
        ,(end_provincecode,end_province_name)
    )
) A1
CROSS JOIN
(
    SELECT
        COUNT(DISTINCT imsi)    AS country_migrate_usr_cnt
    FROM
        tmp_trival_list
) A2
DISTRIBUTE BY 1
;

