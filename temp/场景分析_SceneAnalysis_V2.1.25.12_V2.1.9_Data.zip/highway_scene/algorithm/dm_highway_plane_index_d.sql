set spark.sql.adaptive.enabled=true;
set spark.sql.autoBroadcastJoinThreshold = 200000000;


INSERT OVERWRITE TABLE dm_highway_plane_index_d
PARTITION (p_provincecode = $dm_highway_plane_index_d.p_provincecode$,p_date = '$dm_highway_plane_index_d.p_date$')
select
*
,case when is_coverage_bad=1 or is_quality_bad=1 or is_perception_bad=1 then 1 else 0 end as is_bad_section
,geom
from
(select
 *
,case when rsrpgoodcount_rate_105_45g<0.95 then 1 else 0 end    is_coverage_bad
,case when cqi_good_rate_45g<0.98 or highload_cnt_rate_45g>0.05 then 1 else 0 end   is_quality_bad
,case when (cell_cnt_rate_35_5g>0.6 and uexp_meanspeeddl_35<150) or vonr_ho_succtovolte_rate_5g<0.995 or pdcp_sdulosspktul_qci1_rate_4g>0.001 or pdcp_sdulosspktdl_qci1_rate_4g>0.001 or vonr_rtp_losspktul_rate_5g>0.001 or vonr_rtp_losspktdl_rate_5g>0.001 then 1 when (cell_cnt_rate_35_5g<=0.6 and uexp_meanspeeddl_21<30) or vonr_ho_succtovolte_rate_5g<0.995 or pdcp_sdulosspktul_qci1_rate_4g>0.001 or pdcp_sdulosspktdl_qci1_rate_4g>0.001 or vonr_rtp_losspktul_rate_5g>0.001 or vonr_rtp_losspktdl_rate_5g>0.001 then 1 else 0 end  is_perception_bad

from
(SELECT
    '$dm_highway_plane_index_d.p_date$'        AS day
    ,$dm_highway_plane_index_d.p_provincecode$   AS provincecode
   ,a.province_name
   ,a.citycode
   ,a.city_name
   ,a.scene_type
   ,a.line_id
   ,a.line_name
   ,a.scene_subclass_type
   ,a.scene_subclass_id
   ,a.scene_subclass_name
   ,totalrsrp_4g
   ,rsrpcount_4g
   ,rsrpgoodcount_110_4g
   ,rsrpgoodcount_105_4g
   ,rsrpgoodcount_rate_110_4g
   ,rsrpgoodcount_rate_105_4g
   ,avgrsrp_4g
   ,good_grd_cnt_110_4g
   ,good_grd_cnt_105_4g
   ,grd_cnt_4g
   ,null good_grd_rate_4g
   ,totalrsrp_5g
   ,rsrpcount_5g
   ,rsrpgoodcount_110_5g
   ,rsrpgoodcount_105_5g
   ,rsrpgoodcount_rate_110_5g
   ,rsrpgoodcount_rate_105_5g
   ,rsrpgoodcount_rate_110_4g*0.5+rsrpgoodcount_rate_110_5g*0.5 as rsrpgoodcount_rate_110_45g
   ,rsrpgoodcount_rate_105_4g*0.5+rsrpgoodcount_rate_105_5g*0.5 as rsrpgoodcount_rate_105_45g
   ,avgrsrp_5g
   ,good_grd_cnt_110_5g
   ,good_grd_cnt_105_5g
   ,grd_cnt_5g
   ,good_grd_rate_5g
   ,rsrp110_sinrf3_total_5g
   ,validrsrp_sinr_mrcount_total_5g
   ,rsrp110_sinrf3_rate_total_5g
   ,rsrp110_sinrf3_ctcc_5g
   ,validrsrp_sinr_mrcount_ctcc_5g
   ,rsrp110_sinrf3_rate_ctcc_5g
   ,prb_usedul_4g
   ,prb_availul_4g
   ,prb_usedul_rate_4g
   ,prb_useddl_4g
   ,prb_availdl_4g
   ,prb_useddl_rate_4g
   ,prb_usedul_5g
   ,prb_availul_5g
   ,prb_usedul_rate_5g
   ,prb_useddl_5g
   ,prb_availdl_5g
   ,prb_useddl_rate_5g
   ,cel_cnt_4g
   ,cel_cnt_5g
   ,cel_cnt_4g + cel_cnt_5g as cel_cnt_45g
   ,cell_cnt_35_5g
   ,cell_cnt_rate_35_5g
   ,highload_cnt_4g
   ,highload_cnt_5g
   ,highload_cnt_4g+highload_cnt_5g as  highload_cnt_45g
   ,null  highload_cnt_rate_4g
   ,null  highload_cnt_rate_5g
   ,null as highload_cnt_rate_45g-- (highload_cnt_4g+highload_cnt_5g)/(cel_cnt_4g + cel_cnt_5g)  as highload_cnt_rate_45g
   ,flux_ul_4g
   ,flux_dl_4g
   ,flux_4g
   ,flux_ul_5g
   ,flux_dl_5g
   ,flux_5g
   ,cqi_good_count_4g
   ,cqi_total_count_4g
   ,cqi_good_rate_4g
   ,cqi_good_count_5g
   ,cqi_total_count_5g
   ,cqi_good_rate_5g
   ,cqi_good_rate_4g*0.5+cqi_good_rate_5g*0.5 as cqi_good_rate_45g
   ,rrc_connreq_4g
   ,rrc_connsucc_4g
   ,rrc_connsucc_rate_4g
   ,s1sig_attconnestab_4g
   ,s1sig_succconnestab_4g
   ,s1sig_succconnestab_rate_4g
   ,erab_attestab_4g
   ,erab_succestab_4g
   ,erab_succestab_rate_4g
   ,null as access_success_rate_4g
   ,bad_access_cnt_4g
   ,rrc_connreq_5g
   ,rrc_connsucc_5g
   ,rrc_connsucc_rate_5g
   ,ng_connatt_5g
   ,ng_connsucc_5g
   ,ng_connsucc_rate_5g
   ,qos_initialestabreq_5g
   ,qos_initialestabsucc_5g
   ,qos_initialestabsucc_rate_5g
   ,null as access_success_rate_5g
   ,bad_access_cnt_5g
   ,erab_attestab_qci1_4g
   ,erab_succestab_qci1_4g
   ,erab_succestab_rate_qci1_4g
   ,null as access_success_rate_qci1_4g
   ,vonr_connreq_5g
   ,vonr_connsucc_5g
   ,vonr_connsucc_rate_5g
   ,erab_abnormrel_4g
   ,erab_normrel_4g
   ,erab_drop_rate_4g
   ,bad_drop_cnt_4g
   ,ue_contextrelease_5g
   ,ue_normalcontextrelease_5g
   ,uecntx_drop_rate_5g
   ,bad_drop_cnt_5g
   ,erab_abnormrel_qci1_4g
   ,erab_normrel_qci1_4g
   ,erab_drop_qci1_rate_4g
   ,vonr_releasesum_5g
   ,vonr_normalrelease_5g
   ,vonr_drop_rate_5g
   ,pdcp_sduoctdl_4g
   ,pdcp_sdutailflowdl_4g
   ,pdcp_thrptimedl_4g
   ,pdcp_tailtimedl_4g
   ,uexp_meanspeeddl_4g
   ,bad_uexp_meanspeeddl_cnt_4g
   ,rlc_txbytesdl_5g
   ,rlc_lasttxbytesdl_5g
   ,rlc_txtimedl_exceptlastslot_5g
   ,uexp_meanspeeddl_5g
   ,bad_uexp_meanspeeddl_cnt_5g
   ,pdcp_sdulosspktul_qci1_4g
   ,pdcp_sdupktul_qci1_4g
   ,pdcp_sdulosspktul_qci1_rate_4g
   ,pdcp_sdulosspktdl_qci1_4g
   ,pdcp_sdupktdl_qci1_4g
   ,pdcp_sdulosspktdl_qci1_rate_4g
   ,bad_losspkt_cnt_4g
   ,vonr_rtp_rxpktul_5g
   ,vonr_rtp_losspktul_5g
   ,vonr_rtp_losspktul_rate_5g
   ,vonr_rtp_rxpktdl_5g
   ,vonr_rtp_losspktdl_5g
   ,vonr_rtp_losspktdl_rate_5g
   ,bad_losspkt_cnt_5g
   ,videoplay_suc_cnt_4g
   ,videoplay_req_cnt_4g
   ,videoplay_suc_rate_4g
   ,videoplay_suc_cnt_5g
   ,videoplay_req_cnt_5g
   ,videoplay_suc_rate_5g
   ,vonr_ho_atttovolte
   ,vonr_ho_succtovolte
   ,vonr_ho_succtovolte_rate_5g
   ,uexp_meanspeeddl_35_flow
   ,uexp_meanspeeddl_35_duration
   ,null as uexp_meanspeeddl_35
   ,uexp_meanspeeddl_21_flow_4g+uexp_meanspeeddl_21_flow_5g  as uexp_meanspeeddl_21_flow
   ,uexp_meanspeeddl_21_duration_4g+uexp_meanspeeddl_21_duration_5g as uexp_meanspeeddl_21_duration
   ,(uexp_meanspeeddl_21_flow_4g+uexp_meanspeeddl_21_flow_5g)/(uexp_meanspeeddl_21_duration_4g+uexp_meanspeeddl_21_duration_5g)   as  uexp_meanspeeddl_21
   ,bad_cel_cnt_4g
   ,bad_cel_cnt_5g
   ,cell_cnt_lte_ctcc
   ,cell_cnt_lte_cucc
   ,cell_cnt_nr_ctcc
   ,cell_cnt_nr_cucc


FROM
( select
     provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,sum(prb_usedul) prb_usedul_4g
    ,sum(prb_availul)   prb_availul_4g
    ,sum(prb_usedul)/sum(prb_availul)   prb_usedul_rate_4g
    ,sum(prb_useddl)    prb_useddl_4g
    ,sum(prb_availdl)   prb_availdl_4g
    ,sum(prb_useddl)/sum(prb_availdl)   prb_useddl_rate_4g
    ,count(distinct cellkey)    cel_cnt_4g
    --,4G小区数量+5G小区数量    cel_cnt_45g
    ,count(distinct case when is_highload=1 then cellkey else null end) highload_cnt_4g
    --,4G高负荷小区+5G高负荷小区  highload_cnt_45g
    --,4G高负荷小区数量/4G总小区数量    highload_cnt_rate_4g
    --,(4G高负荷小区+5G高负荷小区)/(4G小区数量+5G小区数量)    highload_cnt_rate_45g
    ,sum(flux_ul)   flux_ul_4g
    ,sum(flux_dl)   flux_dl_4g
    ,sum(flux)  flux_4g
    ,sum(cqi_good_count)    cqi_good_count_4g
    ,sum(cqi_total_count)   cqi_total_count_4g
    ,sum(cqi_good_count)/sum(cqi_total_count)   cqi_good_rate_4g
    --,cqi_good_rate_4g*0.5+cqi_good_rate_5g*0.5    cqi_good_rate_45g
    ,sum(rrc_connreq)   rrc_connreq_4g
    ,sum(rrc_connsucc)  rrc_connsucc_4g
    ,nvl(sum(rrc_connsucc)/sum(rrc_connreq),1)  rrc_connsucc_rate_4g
    ,sum(s1sig_attconnestab)    s1sig_attconnestab_4g
    ,sum(s1sig_succconnestab)   s1sig_succconnestab_4g
    ,nvl(sum(s1sig_succconnestab)/sum(s1sig_attconnestab),1)    s1sig_succconnestab_rate_4g
    ,sum(erab_attestab) erab_attestab_4g
    ,sum(erab_succestab)    erab_succestab_4g
    ,nvl(sum(erab_succestab)/sum(erab_attestab),1)  erab_succestab_rate_4g
    --,rrc_connsucc_rate_4g*s1sig_succconnestab_rate_4g*erab_succestab_rate_4g  access_success_rate_4g
    ,sum(is_bad_access) bad_access_cnt_4g
    ,sum(erab_attestab_qci1)    erab_attestab_qci1_4g
    ,sum(erab_succestab_qci1)   erab_succestab_qci1_4g
    ,nvl(sum(erab_succestab_qci1)/sum(erab_attestab_qci1),1)    erab_succestab_rate_qci1_4g
    --,rrc_connsucc_rate_4g*s1sig_succconnestab_rate_4g*erab_succestab_rate_qci1_4g  access_success_rate_qci1_4g
    ,sum(erab_abnormrel)    erab_abnormrel_4g
    ,sum(erab_normrel)  erab_normrel_4g
    ,nvl(sum(erab_abnormrel)/sum(erab_abnormrel+erab_normrel),0)    erab_drop_rate_4g
    ,sum(is_bad_drop)   bad_drop_cnt_4g
    ,sum(erab_abnormrel_qci1)   erab_abnormrel_qci1_4g
    ,sum(erab_normrel_qci1) erab_normrel_qci1_4g
    ,nvl(sum(erab_abnormrel_qci1)/sum(erab_abnormrel_qci1+erab_normrel_qci1),0) erab_drop_qci1_rate_4g
    ,sum(pdcp_sduoctdl) pdcp_sduoctdl_4g
    ,sum(pdcp_sdutailflowdl)    pdcp_sdutailflowdl_4g
    ,sum(pdcp_thrptimedl)   pdcp_thrptimedl_4g
    ,sum(pdcp_tailtimedl)   pdcp_tailtimedl_4g
    ,sum((pdcp_sduoctdl-pdcp_sdutailflowdl)*8)/sum(( pdcp_thrptimedl-pdcp_tailtimedl)/1000) uexp_meanspeeddl_4g
    ,sum(is_bad_uexp_meanspeeddl)   bad_uexp_meanspeeddl_cnt_4g
    ,sum(pdcp_sdulosspktul_qci1)    pdcp_sdulosspktul_qci1_4g
    ,sum(pdcp_sdupktul_qci1)    pdcp_sdupktul_qci1_4g
    ,nvl(sum(pdcp_sdulosspktul_qci1)/sum(pdcp_sdupktul_qci1),0) pdcp_sdulosspktul_qci1_rate_4g
    ,sum(pdcp_sdulosspktdl_qci1)    pdcp_sdulosspktdl_qci1_4g
    ,sum(pdcp_sdupktdl_qci1)    pdcp_sdupktdl_qci1_4g
    ,nvl(sum(pdcp_sdulosspktdl_qci1)/sum(pdcp_sdupktdl_qci1),0) pdcp_sdulosspktdl_qci1_rate_4g
    ,sum(is_bad_losspkt)    bad_losspkt_cnt_4g
    ,sum(videoplay_suc_cnt) videoplay_suc_cnt_4g
    ,sum(videoplay_req_cnt) videoplay_req_cnt_4g
    ,nvl(sum(videoplay_suc_cnt)/sum(videoplay_req_cnt),1)   videoplay_suc_rate_4g
    ,sum(case when freq='2.1G' then (pdcp_sduoctdl-pdcp_sdutailflowdl)*8 else 0 end)   uexp_meanspeeddl_21_flow_4g
    ,sum(case when freq='2.1G' then (pdcp_thrptimedl-pdcp_tailtimedl)/1000 else 0 end) uexp_meanspeeddl_21_duration_4g
    --,uexp_meanspeeddl_21_flow/uexp_meanspeeddl_21_duration"   uexp_meanspeeddl_21
    ,sum(is_bad)    bad_cel_cnt_4g
    ,count(distinct case when master_operators='电信承建' then cellkey else null end)   cell_cnt_lte_ctcc
    ,count(distinct case when master_operators='联通承建' then cellkey else null end)   cell_cnt_lte_cucc

  from
    dm_highway_plane_cel_lte_d
  WHERE p_provincecode = $dm_highway_plane_index_d.p_provincecode$
    AND p_date = '$dm_highway_plane_index_d.p_date$'
  group by
     provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name
) a
left join
(
  select
     provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,sum(prb_usedul) prb_usedul_5g
    ,sum(prb_availul)   prb_availul_5g
    ,sum(prb_usedul)/sum(prb_availul)   prb_usedul_rate_5g
    ,sum(prb_useddl)    prb_useddl_5g
    ,sum(prb_availdl)   prb_availdl_5g
    ,sum(prb_useddl)/sum(prb_availdl)   prb_useddl_rate_5g
    ,count(distinct cellkey)    cel_cnt_5g
    --,4G小区数量+5G小区数量    cel_cnt_45g
    ,count(distinct case when freq='3.5G' then cellkey else null end)   cell_cnt_35_5g
    ,count(distinct case when freq='3.5G' then cellkey else null end)/count(distinct cellkey)   cell_cnt_rate_35_5g
    ,count(distinct case when is_highload=1 then cellkey else null end) highload_cnt_5g
    --,4G高负荷小区+5G高负荷小区  highload_cnt_45g
    --,5G高负荷小区数量/5G总小区数量    highload_cnt_rate_5g
    --,(4G高负荷小区+5G高负荷小区)/(4G小区数量+5G小区数量)    highload_cnt_rate_45g
    ,sum(flux_ul)   flux_ul_5g
    ,sum(flux_dl)   flux_dl_5g
    ,sum(flux)  flux_5g
    ,sum(cqi_good_count)    cqi_good_count_5g
    ,sum(cqi_total_count)   cqi_total_count_5g
    ,sum(cqi_good_count)/sum(cqi_total_count)   cqi_good_rate_5g
    --,2、cqi_good_rate_4g*0.5+cqi_good_rate_5g*0.5" cqi_good_rate_45g
    ,sum(rrc_connreq)   rrc_connreq_5g
    ,sum(rrc_connsucc)  rrc_connsucc_5g
    ,nvl(sum(rrc_connsucc)/sum(rrc_connreq),1)  rrc_connsucc_rate_5g
    ,sum(ng_connatt)    ng_connatt_5g
    ,sum(ng_connsucc)   ng_connsucc_5g
    ,nvl(sum(ng_connsucc)/sum(ng_connatt),1)    ng_connsucc_rate_5g
    ,sum(qos_initialestabreq)   qos_initialestabreq_5g
    ,sum(qos_initialestabsucc)  qos_initialestabsucc_5g
    ,nvl(sum(qos_initialestabsucc)/sum(qos_initialestabreq),1)  qos_initialestabsucc_rate_5g
    --,2、rrc_connsucc_rate_5g*ng_connsucc_rate_5g*qos_initialestabsucc_rate_5g" access_success_rate_5g
    ,sum(is_bad_access) bad_access_cnt_5g
    ,sum(vonr_connreq)  vonr_connreq_5g
    ,sum(vonr_connsucc) vonr_connsucc_5g
    ,nvl(sum(vonr_connsucc)/sum(vonr_connreq),1)    vonr_connsucc_rate_5g
    ,sum(ue_contextrelease) ue_contextrelease_5g
    ,sum(ue_normalcontextrelease)   ue_normalcontextrelease_5g
    ,nvl(sum(ue_contextrelease-ue_normalcontextrelease)/sum(ue_contextrelease),0)   uecntx_drop_rate_5g
    ,sum(is_bad_drop)   bad_drop_cnt_5g
    ,sum(vonr_releasesum)   vonr_releasesum_5g
    ,sum(vonr_normalrelease)    vonr_normalrelease_5g
    ,nvl(sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum),0)    vonr_drop_rate_5g
    ,sum(rlc_txbytesdl) rlc_txbytesdl_5g
    ,sum(rlc_lasttxbytesdl) rlc_lasttxbytesdl_5g
    ,sum(rlc_txtimedl_exceptlastslot)   rlc_txtimedl_exceptlastslot_5g
    ,(sum(rlc_txbytesdl-rlc_lasttxbytesdl)*8)/(sum(rlc_txtimedl_exceptlastslot)/1000)   uexp_meanspeeddl_5g
    ,sum(is_bad_uexp_meanspeeddl)   bad_uexp_meanspeeddl_cnt_5g
    ,sum(vonr_rtp_rxpktul)  vonr_rtp_rxpktul_5g
    ,sum(vonr_rtp_losspktul)    vonr_rtp_losspktul_5g
    ,nvl(sum(vonr_rtp_losspktul)/sum(vonr_rtp_rxpktul),0)   vonr_rtp_losspktul_rate_5g
    ,sum(vonr_rtp_rxpktdl)  vonr_rtp_rxpktdl_5g
    ,sum(vonr_rtp_losspktdl)    vonr_rtp_losspktdl_5g
    ,nvl(sum(vonr_rtp_losspktdl)/sum(vonr_rtp_rxpktdl),0)   vonr_rtp_losspktdl_rate_5g
    ,sum(is_bad_losspkt)    bad_losspkt_cnt_5g
    ,sum(videoplay_suc_cnt) videoplay_suc_cnt_5g
    ,sum(videoplay_req_cnt) videoplay_req_cnt_5g
    ,nvl(sum(videoplay_suc_cnt)/sum(videoplay_req_cnt),1)   videoplay_suc_rate_5g
    ,nvl(sum(vonr_ho_succtovolte)/sum(vonr_ho_atttovolte),1)    vonr_ho_succtovolte_rate_5g
    ,sum(case when freq='3.5G' then (rlc_txbytesdl-rlc_lasttxbytesdl)*8 else 0 end) uexp_meanspeeddl_35_flow
    ,sum(case when freq='3.5G' then rlc_txtimedl_exceptlastslot/1000 else 0 end)    uexp_meanspeeddl_35_duration
    --,uexp_meanspeeddl_35_flow/uexp_meanspeeddl_35_duration    uexp_meanspeeddl_35
    ,sum(case when freq='2.1G' then (rlc_txbytesdl-rlc_lasttxbytesdl)*8 else 0 end) as uexp_meanspeeddl_21_flow_5g
    ,sum(case when freq='2.1G' then rlc_txtimedl_exceptlastslot/1000 else 0 end)    as uexp_meanspeeddl_21_duration_5g
    --,uexp_meanspeeddl_21_flow/uexp_meanspeeddl_21_duration    uexp_meanspeeddl_21
    ,sum(is_bad)    bad_cel_cnt_5g
    ,count(distinct case when master_operators='电信承建' then cellkey else null end)   cell_cnt_nr_ctcc
    ,count(distinct case when master_operators='联通承建' then cellkey else null end)   cell_cnt_nr_cucc

  from
    dm_highway_plane_cel_nr_d
  WHERE p_provincecode = $dm_highway_plane_index_d.p_provincecode$
    AND p_date = '$dm_highway_plane_index_d.p_date$'
  group by
      provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name
) b

ON a.scene_type = b.scene_type AND a.line_id = b.line_id AND a.scene_subclass_id = b.scene_subclass_id

left join
(SELECT
    provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,sum(totalrsrp) totalrsrp_4g
    ,sum(rsrpcount) rsrpcount_4g
    ,sum(rsrpgoodcount_110) rsrpgoodcount_110_4g
    ,sum(rsrpgoodcount_105) rsrpgoodcount_105_4g
    ,sum(rsrpgoodcount_110)/sum(rsrpcount)  rsrpgoodcount_rate_110_4g
    ,sum(rsrpgoodcount_105)/sum(rsrpcount)  rsrpgoodcount_rate_105_4g
    ,sum(totalrsrp)/sum(rsrpcount)  avgrsrp_4g
    ,sum(good_grd_cnt_110) as  good_grd_cnt_110_4g
    ,sum(good_grd_cnt_105) as  good_grd_cnt_105_4g
    ,count(distinct regionid,x_offset_20,y_offset_20)   as grd_cnt_4g
    from
        (select
             provincecode
            ,province_name
            ,citycode
            ,city_name
            ,scene_type
            ,line_id
            ,line_name
            ,regionid
            ,x_offset_20
            ,y_offset_20
            ,scene_subclass_type
            ,scene_subclass_id
            ,scene_subclass_name
            ,sum(totalrsrp) totalrsrp
            ,sum(rsrpcount) rsrpcount
            ,sum(rsrpgoodcount_110) rsrpgoodcount_110
            ,sum(rsrpgoodcount_105) rsrpgoodcount_105
            ,count(case when avgrsrp>-110 then 1 else null end) as good_grd_cnt_110
            ,count(case when avgrsrp>-105 then 1 else null end) as good_grd_cnt_105
        FROM
          dm_highway_plane_celgrd_lte_d
        WHERE p_provincecode = $dm_highway_plane_index_d.p_provincecode$
          AND p_date = '$dm_highway_plane_index_d.p_date$'
        group by
              provincecode
            ,province_name
            ,citycode
            ,city_name
            ,scene_type
            ,line_id
            ,line_name
            ,scene_subclass_type
            ,scene_subclass_id
            ,scene_subclass_name
            ,regionid
            ,x_offset_20
            ,y_offset_20
        ) t
  group by
      provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name
) c

ON a.scene_type = c.scene_type AND a.line_id = c.line_id AND a.scene_subclass_id = c.scene_subclass_id

left join
(SELECT
    provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,sum(totalrsrp) totalrsrp_5g
    ,sum(rsrpcount) rsrpcount_5g
    ,sum(rsrpgoodcount_110) rsrpgoodcount_110_5g
    ,sum(rsrpgoodcount_105) rsrpgoodcount_105_5g
    ,sum(rsrpgoodcount_110)/sum(rsrpcount)  rsrpgoodcount_rate_110_5g
    ,sum(rsrpgoodcount_105)/sum(rsrpcount)  rsrpgoodcount_rate_105_5g
    ,sum(totalrsrp)/sum(rsrpcount)  avgrsrp_5g
    ,sum(good_grd_cnt_110) as  good_grd_cnt_110_5g
    ,sum(good_grd_cnt_105) as  good_grd_cnt_105_5g
    ,count(distinct regionid,x_offset_20,y_offset_20)   as grd_cnt_5g
    ,sum(good_grd_cnt_110)/count(distinct regionid,x_offset_20,y_offset_20)   as good_grd_rate_5g
    ,sum(rsrp110_sinrf3_total)  rsrp110_sinrf3_total_5g
    ,sum(validrsrp_sinr_mrcount_total)  validrsrp_sinr_mrcount_total_5g
    ,sum(rsrp110_sinrf3_total)/sum(validrsrp_sinr_mrcount_total)    rsrp110_sinrf3_rate_total_5g
    ,sum(rsrp110_sinrf3_ctcc)   rsrp110_sinrf3_ctcc_5g
    ,sum(validrsrp_sinr_mrcount_ctcc)   validrsrp_sinr_mrcount_ctcc_5g
    ,sum(rsrp110_sinrf3_ctcc)/sum(validrsrp_sinr_mrcount_ctcc)  rsrp110_sinrf3_rate_ctcc_5g
    ,sum(vonr_ho_atttovolte)    vonr_ho_atttovolte
    ,sum(vonr_ho_succtovolte)   vonr_ho_succtovolte
FROM
    (select
             provincecode
            ,province_name
            ,citycode
            ,city_name
            ,scene_type
            ,line_id
            ,line_name
            ,scene_subclass_type
            ,scene_subclass_id
            ,scene_subclass_name
            ,regionid
            ,x_offset_20
            ,y_offset_20
            ,sum(totalrsrp) totalrsrp
            ,sum(rsrpcount) rsrpcount
            ,sum(rsrpgoodcount_110) rsrpgoodcount_110
            ,sum(rsrpgoodcount_105) rsrpgoodcount_105
            ,case when avg(avgrsrp)>-110 then 1 else 0 end as good_grd_cnt_110
            ,case when avg(avgrsrp)>-105 then 1 else 0 end as good_grd_cnt_105
            ,sum(rsrp110_sinrf3_total)  rsrp110_sinrf3_total
            ,sum(validrsrp_sinr_mrcount_total)  validrsrp_sinr_mrcount_total
            ,sum(rsrp110_sinrf3_ctcc)   rsrp110_sinrf3_ctcc
            ,sum(validrsrp_sinr_mrcount_ctcc)   validrsrp_sinr_mrcount_ctcc
            ,null     vonr_ho_atttovolte
            ,null    vonr_ho_succtovolte
        FROM
          dm_highway_plane_celgrd_nr_d
        WHERE p_provincecode = $dm_highway_plane_index_d.p_provincecode$ AND p_date = '$dm_highway_plane_index_d.p_date$'
        group by
              provincecode
            ,province_name
            ,citycode
            ,city_name
            ,scene_type
            ,line_id
            ,line_name
            ,scene_subclass_type
            ,scene_subclass_id
            ,scene_subclass_name
            ,regionid
            ,x_offset_20
            ,y_offset_20
    ) t

  group by
      provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name

   ) d
ON a.scene_type = d.scene_type AND a.line_id = d.line_id AND a.scene_subclass_id = d.scene_subclass_id
  ) t
) tt
LEFT JOIN
(
    SELECT
        line_id AS lineid
        ,scene_subclass_id AS scene_id
        ,scene_subclass_type AS subclass_type
        ,geom
    from
        cfg_highway_vector_d
    where p_date = '$dm_highway_plane_index_d.p_date$'
) tt2
ON tt.line_id = tt2.lineid
    AND tt.scene_subclass_id = tt2.scene_id
    AND tt.scene_subclass_type = tt2.subclass_type
;

