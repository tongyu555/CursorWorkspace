-- 20250709updateby : goupengcheng 10207
-- algorithm : 更换mr输入表  并添加维度

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

create temporary function MultiGridToLonLat as 'com.gstools.impala.MultiGridToLonLat';

CACHE TABLE tmp_dm_highway_section_grd_lte_d_mrgrid AS
SELECT
    id                      AS line_id
   ,name                    AS line_name
   ,section_id
   ,CONCAT(name,section_id) AS section_name
   ,region_id
   ,x_offset
   ,y_offset
   ,section_id_1km
   ,split(MultiGridToLonLat(region_id,CAST(x_offset AS int),CAST(y_offset AS int),20),',') AS arr_lonlat
FROM
    cfg_highway_100m_section_20m_grid_rel
WHERE p_provincecode = $dm_highway_section_grd_lte_d.p_provincecode$
    AND region_id IS NOT NULL
    AND x_offset IS NOT NULL
    AND y_offset IS NOT NULL
    AND id IS NOT NULL
    AND section_id IS NOT NULL
    AND section_id_1km IS NOT NULL
;

INSERT OVERWRITE TABLE dm_highway_section_grd_lte_d
PARTITION (
    p_provincecode = $dm_highway_section_grd_lte_d.p_provincecode$
    ,p_date = '$dm_highway_section_grd_lte_d.p_date$'
)
SELECT
    '$dm_highway_section_grd_lte_d.p_date$'                             AS day
    ,$dm_highway_section_grd_lte_d.p_provincecode$                       AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,districtcode
    ,district_name
    ,11                                                                  AS scene_type
    ,line_id
    ,line_name
    ,section_id
    ,section_name
    ,t1.regionid                                                         AS regionid
    ,t1.x_offset                                                         AS x_offset_20
    ,t1.y_offset                                                         AS y_offset_20
    ,(CAST(arr_lonlat[0] AS double) + CAST(arr_lonlat[2] AS double)) / 2 AS grd_lon
    ,(CAST(arr_lonlat[1] AS double) + CAST(arr_lonlat[3] AS double)) / 2 AS grd_lat
    ,totalrsrp
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,avgrsrp
    ,totalulsinr
    ,ulsinrcount
    ,avgulsinr
    ,ulsinrgood_cnt
    ,ulsinrgood_rate
    ,mod3interfer_mrcount
    ,overlap_mrcount
    ,overshoot_mrcount
    ,mod3interfer_mrratio
    ,overlap_mrratio
    ,overshoot_mrratio
    ,section_id_1km
    -- 添加维度
    ,freq
FROM
(
    -- 更换表
    -- 添加freq维度
    SELECT
        freq
       ,regionid
       ,x_offset
       ,y_offset
       ,SUM(totalrsrp)          AS totalrsrp
       ,SUM(rsrpcount)          AS rsrpcount
       ,SUM(totalrsrp) / SUM(rsrpcount) AS avgrsrp
       ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0) + NVL(rsrp_5div_level8mrcount,0))  AS rsrpgoodcount_110
       ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0))   AS rsrpgoodcount_105
       ,NVL(SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0) + NVL(rsrp_5div_level8mrcount,0)) / SUM(rsrpcount),1)  AS rsrpgoodcount_rate_110
       ,NVL(SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0)) / SUM(rsrpcount),1)   AS rsrpgoodcount_rate_105
       ,SUM(totalulsinr)                                    AS totalulsinr
       ,SUM(ulsinrcount)                                    AS ulsinrcount
       ,SUM(totalulsinr) / SUM(ulsinrcount)                 AS avgulsinr
       ,sum(ulsinrcount - ulsinr_level7mrcount)                           AS ulsinrgood_cnt
       ,nvl(sum(ulsinrcount - ulsinr_level7mrcount)/sum(ulsinrcount),1)   AS ulsinrgood_rate
       ,SUM(mod3interfer_mrcount)                           AS mod3interfer_mrcount
       ,SUM(overlap_mrcount)                                AS overlap_mrcount
       ,SUM(overshoot_mrcount)                              AS overshoot_mrcount
       ,NVL(SUM(mod3interfer_mrcount) / SUM(rsrpcount),0)   AS mod3interfer_mrratio
       ,NVL(SUM(overlap_mrcount) / SUM(rsrpcount),0)        AS overlap_mrratio
       ,NVL(SUM(overshoot_mrcount) / SUM(rsrpcount),0)      AS overshoot_mrratio
    FROM
        zxvmax.aggr_lte_coverage_base_refactor_d -- 更换输入表
    WHERE p_provincecode = $dm_highway_section_grd_lte_d.p_provincecode$
        AND p_date = '$dm_highway_section_grd_lte_d.p_date$'
        AND plmn = '46011'
        AND regionid IS NOT NULL
        AND x_offset IS NOT NULL
        AND y_offset IS NOT NULL
    GROUP BY
        freq
       ,regionid
       ,x_offset
       ,y_offset

    -- SELECT
        -- regionid
       -- ,x_offset
       -- ,y_offset
       -- ,sum(totalrsrp)  AS totalrsrp
       -- ,sum(rsrpcount)  AS rsrpcount
       -- ,sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount+rsrp_5div_level8mrcount)    AS rsrpgoodcount_110
       -- ,sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount) AS rsrpgoodcount_105
       -- ,nvl(sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount+rsrp_5div_level8mrcount)/sum(rsrpcount),1)  AS rsrpgoodcount_rate_110
       -- ,nvl(sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount)/sum(rsrpcount),1)  AS rsrpgoodcount_rate_105
       -- ,sum(totalrsrp)/sum(rsrpcount)                                     AS avgrsrp
       -- ,sum(totalulsinr)                                                  AS totalulsinr
       -- ,sum(ulsinrcount)                                                  AS ulsinrcount
       -- ,sum(totalulsinr)/sum(ulsinrcount)                                 AS avgulsinr
       -- ,sum(ulsinrcount - ulsinr_level7mrcount)                           AS ulsinrgood_cnt
       -- ,nvl(sum(ulsinrcount - ulsinr_level7mrcount)/sum(ulsinrcount),1)   AS ulsinrgood_rate
       -- ,sum(mod3interfer_mrcount)                                         AS mod3interfer_mrcount
       -- ,sum(overlap_mrcount)                                              AS overlap_mrcount
       -- ,sum(overshoot_mrcount)                                            AS overshoot_mrcount
       -- ,nvl(sum(mod3interfer_mrcount)/sum(rsrpcount),0)                   AS mod3interfer_mrratio
       -- ,nvl(sum(overlap_mrcount)/sum(rsrpcount),0)                        AS overlap_mrratio
       -- ,nvl(sum(overshoot_mrcount)/sum(rsrpcount),0)                      AS overshoot_mrratio
    -- FROM
        -- zxvmax.aggr_lte_coverage_grd_refactor_d
    -- WHERE p_provincecode = $dm_highway_section_grd_lte_d.p_provincecode$
        -- AND p_date = '$dm_highway_section_grd_lte_d.p_date$'
        -- AND plmn = '46011'
    -- GROUP BY
        -- regionid
       -- ,x_offset
       -- ,y_offset
) t1
INNER JOIN
    tmp_dm_highway_section_grd_lte_d_mrgrid t2
ON t1.regionid = t2.region_id
    AND t1.x_offset = t2.x_offset
    AND t1.y_offset = t2.y_offset
INNER JOIN
(
    SELECT
        districtcode
        ,regionid
        ,x_offset_20
        ,y_offset_20
    FROM
        cfg_grid_tag
    WHERE p_provincecode = $dm_highway_section_grd_lte_d.p_provincecode$
) t3
ON t1.regionid = t3.regionid
    AND t1.x_offset = t3.x_offset_20
    AND t1.y_offset = t3.y_offset_20
INNER JOIN
(
    SELECT
        provincecode
        ,province_name
        ,city_id AS citycode
        ,city_name
        ,district_id
        ,district_name
    FROM
        cfg_district
    WHERE provincecode = $dm_highway_section_grd_lte_d.p_provincecode$
    GROUP BY
        provincecode
        ,province_name
        ,city_id
        ,city_name
        ,district_id
        ,district_name
) t4
ON t3.districtcode = t4.district_id
;

