-- 20250711updateby : goupengcheng 10207
-- algorithm : 调整小区表

set spark.sql.adaptive.enabled=true;
set spark.sql.codegen.maxFields=100;
set spark.sql.codegen.wholeStageMaxNumFields=100;

CACHE TABLE tmp_dm_highway_section_coverage_nr_d_info AS
-- 回填地区名称
SELECT
    b.provincecode
    ,d.province_name
    ,b.citycode
    ,d.city_name
    ,scene_type
    ,line_id
    ,line_name
    ,section_id
    ,section_name
    ,totalrsrp
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,case when rsrpgoodcount_110/rsrpcount>0.7 and rsrpcount>=20 then 1 else 0 end as is_section_coverage_110
    ,case when rsrpgoodcount_105/rsrpcount>0.7 and rsrpcount>=20 then 1 else 0 end as is_section_coverage_105
    ,avgrsrp
    ,good_grd_cnt_110
    ,good_grd_cnt_105
    ,grd_cnt
    ,good_grd_rate
    ,rsrp110_sinrf3_total
    ,validrsrp_sinr_mrcount_total
    ,rsrp110_sinrf3_rate_total
    ,rsrp110_sinrf3_ctcc
    ,validrsrp_sinr_mrcount_ctcc
    ,rsrp110_sinrf3_rate_ctcc
    ,section_id_1km
FROM
(
    -- 5G覆盖指标汇总到路段
    select
        provincecode
        ,citycode
        ,scene_type
        ,line_id
        ,line_name
        ,section_id
        ,section_name
        ,section_id_1km
        ,sum(totalrsrp) totalrsrp
        ,sum(rsrpcount) rsrpcount
        ,sum(rsrpgoodcount_110) rsrpgoodcount_110
        ,sum(rsrpgoodcount_105) rsrpgoodcount_105
        ,sum(rsrpgoodcount_110)/sum(rsrpcount)  rsrpgoodcount_rate_110
        ,sum(rsrpgoodcount_105)/sum(rsrpcount)  rsrpgoodcount_rate_105
        ,sum(totalrsrp)/sum(rsrpcount)  avgrsrp
        ,sum(good_grd_cnt_110)  good_grd_cnt_110
        ,sum(good_grd_cnt_105)  good_grd_cnt_105
        ,sum(grd_cnt)   grd_cnt
        ,sum(good_grd_cnt_110)/sum(grd_cnt) good_grd_rate
        ,sum(rsrp110_sinrf3_total)  rsrp110_sinrf3_total
        ,sum(validrsrp_sinr_mrcount_total)  validrsrp_sinr_mrcount_total
        ,sum(rsrp110_sinrf3_total)/sum(validrsrp_sinr_mrcount_total)    rsrp110_sinrf3_rate_total
        ,sum(rsrp110_sinrf3_ctcc)   rsrp110_sinrf3_ctcc
        ,sum(validrsrp_sinr_mrcount_ctcc)   validrsrp_sinr_mrcount_ctcc
        ,sum(rsrp110_sinrf3_ctcc)/sum(validrsrp_sinr_mrcount_ctcc)  rsrp110_sinrf3_rate_ctcc
    from
        dm_highway_section_coverage_nr_d
    WHERE p_provincecode = $dm_highway_section_nr_d.p_provincecode$
        AND p_date = '$dm_highway_section_nr_d.p_date$'
    group by
         provincecode
        ,citycode
        ,scene_type
        ,line_id
        ,line_name
        ,section_id
        ,section_name
        ,section_id_1km
) b
INNER JOIN
(
    -- 地市配置表
    SELECT
        provincecode
        ,province_name
        ,city_id AS citycode
        ,city_name
    FROM
        cfg_district
    WHERE provincecode = $dm_highway_section_nr_d.p_provincecode$
    GROUP BY
        provincecode
        ,province_name
        ,city_id
        ,city_name
) d
ON b.provincecode = d.provincecode
    and b.citycode = d.citycode
;

INSERT OVERWRITE TABLE dm_highway_section_nr_d
PARTITION (
    p_provincecode = $dm_highway_section_nr_d.p_provincecode$
    ,p_date = '$dm_highway_section_nr_d.p_date$'
)
SELECT
    '$dm_highway_section_nr_d.p_date$'        AS day
    ,$dm_highway_section_nr_d.p_provincecode$   AS provincecode
    ,t1.province_name
    ,t1.citycode
    ,t1.city_name
    ,t1.scene_type
    ,t1.line_id
    ,t1.line_name
    ,t1.section_id
    ,t1.section_name
    ,totalrsrp
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,is_section_coverage_110
    ,is_section_coverage_105
    ,avgrsrp
    ,good_grd_cnt_110
    ,good_grd_cnt_105
    ,grd_cnt
    ,good_grd_rate
    ,rsrp110_sinrf3_total
    ,validrsrp_sinr_mrcount_total
    ,rsrp110_sinrf3_rate_total
    ,rsrp110_sinrf3_ctcc
    ,validrsrp_sinr_mrcount_ctcc
    ,rsrp110_sinrf3_rate_ctcc
    ,prb_usedul
    ,prb_availul
    ,prb_usedul_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_useddl_rate
    ,cel_cnt
    ,cell_cnt_35_5g
    ,highload_cnt
    ,flux_ul
    ,flux_dl
    ,flux
    ,cqi_good_count
    ,cqi_total_count
    ,cqi_good_rate
    ,rrc_connreq
    ,rrc_connsucc
    ,rrc_connsucc_rate
    ,ng_connatt
    ,ng_connsucc
    ,ng_connsucc_rate
    ,qos_initialestabreq
    ,qos_initialestabsucc
    ,qos_initialestabsucc_rate
    ,access_success_rate
    ,bad_access_cnt
    ,ue_contextrelease
    ,ue_normalcontextrelease
    ,uecntx_drop_rate
    ,bad_drop_cnt
    ,vonr_connreq
    ,vonr_connsucc
    ,vonr_connsucc_rate
    ,vonr_releasesum
    ,vonr_normalrelease
    ,vonr_drop_rate
    ,rlc_txbytesdl
    ,rlc_lasttxbytesdl
    ,rlc_txtimedl_exceptlastslot
    ,uexp_meanspeeddl
    ,bad_uexp_meanspeeddl_cnt
    ,vonr_rtp_rxpktul
    ,vonr_rtp_losspktul
    ,vonr_rtp_losspktul_rate
    ,vonr_rtp_rxpktdl
    ,vonr_rtp_losspktdl
    ,vonr_rtp_losspktdl_rate
    ,bad_losspkt_cnt
    ,vonr_ho_atttovolte
    ,vonr_ho_succtovolte
    ,vonr_ho_succtovolte_rate
    ,videoplay_suc_cnt
    ,videoplay_req_cnt
    ,videoplay_suc_rate
    ,bad_cel_cnt
    ,uexp_meanspeeddl_35_flow
    ,uexp_meanspeeddl_35_duration
    ,uexp_meanspeeddl_35
    ,uexp_meanspeeddl_21_flow
    ,uexp_meanspeeddl_21_duration
    ,uexp_meanspeeddl_21
    ,cell_cnt_nr_ctcc
    ,cell_cnt_nr_cucc
    ,t1.section_id_1km
FROM
    tmp_dm_highway_section_coverage_nr_d_info t1
left join
(
    -- 指标汇总到路段
    SELECT
        e.provincecode
        ,e.line_id
        ,e.line_name
        ,a.section_id
        ,a.section_name
        ,a.section_id_1km
        ,sum(prb_usedul)    prb_usedul
        ,sum(prb_availul)   prb_availul
        ,sum(prb_usedul)/sum(prb_availul)   prb_usedul_rate
        ,sum(prb_useddl)    prb_useddl
        ,sum(prb_availdl)   prb_availdl
        ,sum(prb_useddl)/sum(prb_availdl)   prb_useddl_rate
        ,count(distinct e.cellkey)    cel_cnt
        ,count(distinct case when freq='3.5G' then e.cellkey else null end)   cell_cnt_35_5g
        ,count(case when is_highload=1 then 1 else null end)    highload_cnt
        ,sum(flux_ul)   flux_ul
        ,sum(flux_dl)   flux_dl
        ,sum(flux)  flux
        ,sum(cqi_good_count)    cqi_good_count
        ,sum(cqi_total_count)   cqi_total_count
        ,sum(cqi_good_count)/sum(cqi_total_count)   cqi_good_rate
        ,sum(rrc_connreq)   rrc_connreq
        ,sum(rrc_connsucc)  rrc_connsucc
        ,nvl(sum(rrc_connsucc)/sum(rrc_connreq),1)  rrc_connsucc_rate
        ,sum(ng_connatt)    ng_connatt
        ,sum(ng_connsucc)   ng_connsucc
        ,nvl(sum(ng_connsucc)/sum(ng_connatt),1)    ng_connsucc_rate
        ,sum(qos_initialestabreq)   qos_initialestabreq
        ,sum(qos_initialestabsucc)  qos_initialestabsucc
        ,nvl(sum(qos_initialestabsucc)/sum(qos_initialestabreq),1)  qos_initialestabsucc_rate
        ,nvl(sum(rrc_connsucc)/sum(rrc_connreq),1)*nvl(sum(ng_connsucc)/sum(ng_connatt),1)*nvl(sum(qos_initialestabsucc)/sum(qos_initialestabreq),1)    access_success_rate
        ,count(case when is_bad_access=1 then 1 else null end)  bad_access_cnt
        ,sum(ue_contextrelease) ue_contextrelease
        ,sum(ue_normalcontextrelease)   ue_normalcontextrelease
        ,nvl(sum(ue_contextrelease - ue_normalcontextrelease)/sum(ue_contextrelease),0) uecntx_drop_rate
        ,count(case when is_bad_drop=1 then 1 else null end)    bad_drop_cnt
        ,sum(vonr_connreq)  vonr_connreq
        ,sum(vonr_connsucc) vonr_connsucc
        ,nvl(sum(vonr_connsucc)/sum(vonr_connreq),1)    vonr_connsucc_rate
        ,sum(vonr_releasesum)   vonr_releasesum
        ,sum(vonr_normalrelease)    vonr_normalrelease
        ,nvl(sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum),0)    vonr_drop_rate
        ,sum(rlc_txbytesdl) rlc_txbytesdl
        ,sum(rlc_lasttxbytesdl) rlc_lasttxbytesdl
        ,sum(rlc_txtimedl_exceptlastslot)   rlc_txtimedl_exceptlastslot
        ,(sum(rlc_txbytesdl-rlc_lasttxbytesdl)*8)/(sum(rlc_txtimedl_exceptlastslot)/1000)   uexp_meanspeeddl
        ,count(case when is_bad_uexp_meanspeeddl=1 then 1 else null end)    bad_uexp_meanspeeddl_cnt
        ,sum(vonr_rtp_rxpktul)  vonr_rtp_rxpktul
        ,sum(vonr_rtp_losspktul)    vonr_rtp_losspktul
        ,sum(vonr_rtp_losspktul)/sum(vonr_rtp_rxpktul)  vonr_rtp_losspktul_rate
        ,sum(vonr_rtp_rxpktdl)  vonr_rtp_rxpktdl
        ,sum(vonr_rtp_losspktdl)    vonr_rtp_losspktdl
        ,sum(vonr_rtp_losspktdl)/sum(vonr_rtp_rxpktdl)  vonr_rtp_losspktdl_rate
        ,count(case when is_bad_losspkt=1 then 1 else null end) bad_losspkt_cnt
        ,sum(vonr_ho_atttovolte)    vonr_ho_atttovolte
        ,sum(vonr_ho_succtovolte)   vonr_ho_succtovolte
        ,sum(vonr_ho_succtovolte)/sum(vonr_ho_atttovolte)   vonr_ho_succtovolte_rate
        ,sum(videoplay_suc_cnt) videoplay_suc_cnt
        ,sum(videoplay_req_cnt) videoplay_req_cnt
        ,sum(videoplay_suc_cnt)/sum(videoplay_req_cnt)  videoplay_suc_rate
        ,count(case when is_bad=1 then 1 else null end) bad_cel_cnt
        ,sum(case when freq = '3.5G' then (rlc_txbytesdl-rlc_lasttxbytesdl)*8 else 0 end)   uexp_meanspeeddl_35_flow
        ,sum(case when freq = '3.5G' then (rlc_txtimedl_exceptlastslot)/1000 else 0 end)    uexp_meanspeeddl_35_duration
        ,sum(case when freq = '3.5G' then (rlc_txbytesdl-rlc_lasttxbytesdl)*8 else 0 end) / sum(case when freq = '3.5G' then (rlc_txtimedl_exceptlastslot)/1000 else 0 end) uexp_meanspeeddl_35
        ,sum(case when freq = '2.1G' then (rlc_txbytesdl-rlc_lasttxbytesdl)*8 else 0 end)   uexp_meanspeeddl_21_flow
        ,sum(case when freq = '2.1G' then (rlc_txtimedl_exceptlastslot)/1000 else 0 end)    uexp_meanspeeddl_21_duration
        ,sum(case when freq = '2.1G' then (rlc_txbytesdl-rlc_lasttxbytesdl)*8 else 0 end)  / sum(case when freq = '2.1G' then (rlc_txtimedl_exceptlastslot)/1000 else 0 end)    uexp_meanspeeddl_21
        ,count(distinct case when master_operators='电信承建' then e.cellkey else null end)   cell_cnt_nr_ctcc
        ,count(distinct case when master_operators='联通承建' then e.cellkey else null end)   cell_cnt_nr_cucc
    from
    (
        -- 调整查询字段，之前是*
        select
            provincecode
            ,province_name
            ,citycode
            ,city_name
            ,districtcode
            ,district_name
            ,scene_type
            ,line_id
            ,line_name
            ,net_type
            ,gnbid
            ,cellid
            ,cellkey
            ,cellname
            ,cell_lon
            ,cell_lat
            ,freq
            ,pci
            ,height
            ,indoor_flag
            ,azimuth
            ,vendor
            ,bandwidth
            ,cover_rate
            ,is_inside
            ,master_operators
            ,is_highload
            ,prb_usedul
            ,prb_availul
            ,prb_usedul_rate
            ,prb_useddl
            ,prb_availdl
            ,prb_useddl_rate
            ,totalrsrp
            ,rsrpcount_scene
            ,rsrpcount
            ,rsrpgoodcount_110
            ,rsrpgoodcount_105
            ,rsrpgoodcount_rate_110
            ,rsrpgoodcount_rate_105
            ,rsrp110_sinrf3_total
            ,validrsrp_sinr_mrcount_total
            ,rsrp110_sinrf3_rate_total
            ,rsrp110_sinrf3_ctcc
            ,validrsrp_sinr_mrcount_ctcc
            ,rsrp110_sinrf3_rate_ctcc
            ,avgrsrp
            ,flux_ul
            ,flux_dl
            ,flux
            ,cqi_good_count
            ,cqi_total_count
            ,cqi_good_rate
            ,rrc_connreq
            ,rrc_connsucc
            ,rrc_connsucc_rate
            ,ng_connatt
            ,ng_connsucc
            ,ng_connsucc_rate
            ,qos_initialestabreq
            ,qos_initialestabsucc
            ,qos_initialestabsucc_rate
            ,access_success_rate
            ,is_bad_access
            ,ue_contextrelease
            ,ue_normalcontextrelease
            ,uecntx_drop_rate
            ,is_bad_drop
            ,vonr_connreq
            ,vonr_connsucc
            ,vonr_connsucc_rate
            ,vonr_releasesum
            ,vonr_normalrelease
            ,vonr_drop_rate
            ,rlc_txbytesdl
            ,rlc_lasttxbytesdl
            ,rlc_txtimedl_exceptlastslot
            ,uexp_meanspeeddl
            ,is_bad_uexp_meanspeeddl
            ,vonr_rtp_rxpktul
            ,vonr_rtp_losspktul
            ,vonr_rtp_losspktul_rate
            ,vonr_rtp_rxpktdl
            ,vonr_rtp_losspktdl
            ,vonr_rtp_losspktdl_rate
            ,is_bad_losspkt
            ,vonr_ho_atttovolte
            ,vonr_ho_succtovolte
            ,vonr_ho_succtovolte_rate
            ,videoplay_suc_cnt
            ,videoplay_req_cnt
            ,videoplay_suc_rate
            ,is_bad
            ,bad_cause
            ,solution
        FROM
            dm_highway_line_cell_nr_d
        WHERE p_provincecode = $dm_highway_section_nr_d.p_provincecode$
            AND p_date = '$dm_highway_section_nr_d.p_date$'
    ) e
    inner join
    (
        -- 根据小区回填路段
        select
            line_id
            ,line_name
            ,section_id
            ,section_name
            ,cellkey
            ,section_id_1km
        from
            dm_highway_section_sector_nr_rel_use_d -- 更换数据源
        WHERE p_provincecode = $dm_highway_section_nr_d.p_provincecode$
            AND p_date = '$dm_highway_section_nr_d.p_date$'
            AND valid_flag = 1 -- 添加过滤条件
    ) a
    ON e.line_id = a.line_id
        AND e.cellkey = a.cellkey
    group by
        e.provincecode
        ,e.line_id
        ,e.line_name
        ,a.section_id
        ,a.section_name
        ,a.section_id_1km
) t2
ON t1.line_id = t2.line_id
    AND t1.section_id_1km = t2.section_id_1km
    AND t1.section_id = t2.section_id
    and t1.provincecode = t2.provincecode
;

