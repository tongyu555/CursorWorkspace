-- 20250711updateby : goupengcheng 10207
-- algorithm : 调整小区表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

-- 高速栅格
cache table tmp_cfg_highway_plane_scene_grid20m_rel as
select
    distinct
    provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,regionid
    ,x_offset_20
    ,y_offset_20
    ,grid_lon
    ,grid_lat
from
    cfg_highway_plane_scene_grid20m_rel
where p_provincecode = $dm_highway_plane_celgrd_lte_d.p_provincecode$
;

INSERT OVERWRITE TABLE dm_highway_plane_celgrd_lte_d
PARTITION (
    p_provincecode = $dm_highway_plane_celgrd_lte_d.p_provincecode$
    ,p_date = '$dm_highway_plane_celgrd_lte_d.p_date$'
)
select
    '$dm_highway_plane_celgrd_lte_d.p_date$'
    ,$dm_highway_plane_celgrd_lte_d.p_provincecode$
    ,b.province_name
    ,b.citycode
    ,b.city_name
    ,b.scene_type
    ,b.line_id
    ,b.line_name
    ,b.scene_subclass_type
    ,b.scene_subclass_id
    ,b.scene_subclass_name
    ,b.regionid
    ,b.x_offset_20
    ,b.y_offset_20
    ,b.grid_lon
    ,b.grid_lat
    ,c.cellkey
    ,c.cellname
    ,c.cell_lon
    ,c.cell_lat
    ,c.freq
    ,c.pci
    ,c.height
    ,c.indoor_flag
    ,c.azimuth
    ,c.vendor
    ,c.bandwidth
    ,c.master_operators
    ,totalrsrp
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,avgrsrp
    ,totalulsinr
    ,ulsinrcount
    ,avgulsinr
    ,ulsinrgood_cnt
    ,ulsinrgood_rate
    ,mod3interfer_mrcount
    ,overlap_mrcount
    ,overshoot_mrcount
    ,mod3interfer_mrratio
    ,overlap_mrratio
    ,overshoot_mrratio
from
    tmp_cfg_highway_plane_scene_grid20m_rel b
left join
(
    -- mr数据汇总到小区栅格
    select
         cellkey
        ,regionid
        ,x_offset
        ,y_offset
        ,sum(totalrsrp) totalrsrp
        ,sum(rsrpcount) rsrpcount
        ,sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+ rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount+rsrp_5div_level8mrcount)                          as rsrpgoodcount_110
        ,sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+ rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount)                                                  as rsrpgoodcount_105
        ,nvl(sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+ rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount+rsrp_5div_level8mrcount)/sum(rsrpcount),1)    as rsrpgoodcount_rate_110
        ,nvl(sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+ rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount)/sum(rsrpcount),1)                            as rsrpgoodcount_rate_105
        ,sum(totalrsrp)/sum(rsrpcount) as avgrsrp
        ,sum(totalulsinr)                                                      as totalulsinr
        ,sum(ulsinrcount)                                                             as ulsinrcount
        ,sum(totalulsinr)/sum(ulsinrcount)                                            as avgulsinr
        ,sum(ulsinrcount - ulsinr_level7mrcount)                                      as ulsinrgood_cnt
        ,nvl(sum(ulsinrcount - ulsinr_level7mrcount)/sum(ulsinrcount),1)              as ulsinrgood_rate
        ,sum(mod3interfer_mrcount)                                                    as mod3interfer_mrcount
        ,sum(overlap_mrcount)                                                         as overlap_mrcount
        ,sum(overshoot_mrcount)                                                       as overshoot_mrcount
        ,nvl(sum(mod3interfer_mrcount)/sum(rsrpcount),0)                              as mod3interfer_mrratio
        ,nvl(sum(overlap_mrcount)/sum(rsrpcount),0)                                   as overlap_mrratio
        ,nvl(sum(overshoot_mrcount)/sum(rsrpcount),0)                                 as overshoot_mrratio
    from
        zxvmax.aggr_lte_coverage_base_refactor_d
    WHERE p_provincecode = $dm_highway_plane_celgrd_lte_d.p_provincecode$
        AND p_date = '$dm_highway_plane_celgrd_lte_d.p_date$'
        AND plmn = '46011'
    group by
        cellkey
        ,regionid
        ,x_offset
        ,y_offset
) d
on  b.regionid = d.regionid
    AND b.x_offset_20 = d.x_offset
    AND b.y_offset_20 = d.y_offset
left join
(
    -- 回填小区信息
    select
        cellkey
        ,cellname
        ,cell_lon
        ,cell_lat
        ,freq
        ,pci
        ,height
        ,indoor_flag
        ,azimuth
        ,vendor
        ,bandwidth
        ,master_operators
    from
        cfg_highway_plane_sector_lte_rel_use_d -- 更换输入表
    WHERE p_provincecode = $dm_highway_plane_celgrd_lte_d.p_provincecode$
        AND p_date = '$dm_highway_plane_celgrd_lte_d.p_date$'
        AND valid_flag = 1 -- 添加过滤条件
) c
on c.cellkey = d.cellkey
;

