-- auth : goupengcheng
-- since : 2025-07-16
-- algorithm :  高速4G路段小区栅格覆盖指标天表
-- 处理小文件
set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

SET hive.enforce.bucketing=TRUE;
SET hive.exec.compress.output=TRUE;
SET mapred.output.compress=TRUE;
SET mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
SET io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- 电联工参
CACHE TABLE tmp_lte_cm AS
SELECT
    cellkey
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,height
    ,indoor_flag
    ,azimuth
    ,enbname
    ,cellname
    ,vendor
    ,bandwidth
    ,master_operators
FROM
(
    -- 电信工参
    SELECT
        reportcellkey                                AS cellkey
        ,celllon                                     AS cell_lon
        ,celllat                                     AS cell_lat
        ,bandclass                                   AS freq
        ,pci                                         AS pci
        ,height                                      AS height
        ,CASE WHEN covertype = 2 THEN 1 ELSE 0 END   AS indoor_flag
        ,azimuth                                     AS azimuth
        ,REGEXP_REPLACE(enodebname,',','_')          AS enbname
        ,REGEXP_REPLACE(cellname,',','_')            AS cellname
        ,vendor                                      AS vendor
        ,dlband                                      AS bandwidth
        ,'电信承建'                                  AS master_operators
        ,ROW_NUMBER() OVER(PARTITION BY reportcellkey ORDER BY celllon DESC) rn
    FROM
        lte_cm_projdata
    WHERE p_provincecode = $dm_highway_section_celgrd_lte_d.p_provincecode$
    HAVING rn = 1
    UNION ALL
    -- 联通工参
    SELECT
        cellkey                              AS cellkey
        ,cell_lon                            AS cell_lon
        ,cell_lat                            AS cell_lat
        ,freq                                AS freq
        ,pci                                 AS pci
        ,cell_height                         AS height
        ,indoor_flag                         AS indoor_flag
        ,azimuth                             AS azimuth
        ,REGEXP_REPLACE(enodeb_name,',','_') AS enbname
        ,REGEXP_REPLACE(cell_name,',','_')   AS cellname
        ,vendor                              AS vendor
        ,bandwidth_dl                        AS bandwidth
        ,'联通承建'                          AS master_operators
        ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDER BY cell_lon DESC) rn
    FROM
        lte_cucc_cm_projdata
    WHERE p_provincecode = $dm_highway_section_celgrd_lte_d.p_provincecode$
    HAVING rn = 1
) A
;

INSERT OVERWRITE TABLE dm_highway_section_celgrd_lte_d
PARTITION (
    p_provincecode = $dm_highway_section_celgrd_lte_d.p_provincecode$
    ,p_date = '$dm_highway_section_celgrd_lte_d.p_date$'
)
SELECT
    '$dm_highway_section_celgrd_lte_d.p_date$'  AS day
    ,$dm_highway_section_celgrd_lte_d.p_provincecode$   AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,11             AS scene_type
    ,A2.line_id     AS line_id
    ,section_id_1km
    ,line_name
    ,section_id
    ,section_name
    ,A1.regionid    AS regionid
    ,A1.x_offset_20 AS x_offset_20
    ,A1.y_offset_20 AS y_offset_20
    ,grd_lon
    ,grd_lat
    ,A1.cellkey     AS cellkey
    ,cellname
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,height
    ,indoor_flag
    ,azimuth
    ,vendor
    ,bandwidth
    ,master_operators
    -- 关联到场景小区则赋值1
    ,CASE WHEN A4.cellkey IS NOT NULL THEN 1 ELSE 0 END AS is_scene_cell
    ,totalrsrp
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,avgrsrp
    ,totalulsinr
    ,ulsinrcount
    ,avgulsinr
    ,ulsinrgood_cnt
    ,ulsinrgood_rate
    ,mod3interfer_mrcount
    ,overlap_mrcount
    ,overshoot_mrcount
    ,mod3interfer_mrratio
    ,overlap_mrratio
    ,overshoot_mrratio
FROM
(
    -- mr数据
    SELECT
        cellkey                 AS cellkey
        ,regionid                AS regionid
        ,x_offset                AS x_offset_20
        ,y_offset                AS y_offset_20
        ,SUM(totalrsrp)          AS totalrsrp
        ,SUM(rsrpcount)          AS rsrpcount
        ,SUM(totalrsrp) / SUM(rsrpcount) AS avgrsrp
        ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0) + NVL(rsrp_5div_level8mrcount,0))  AS rsrpgoodcount_110
        ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0))   AS rsrpgoodcount_105
        ,NVL(SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0) + NVL(rsrp_5div_level8mrcount,0)) / SUM(rsrpcount),1)  AS rsrpgoodcount_rate_110
        ,NVL(SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0)) / SUM(rsrpcount),1)   AS rsrpgoodcount_rate_105
        ,SUM(totalulsinr)                                    AS totalulsinr
        ,SUM(ulsinrcount)                                    AS ulsinrcount
        ,SUM(totalulsinr) / SUM(ulsinrcount)                 AS avgulsinr
        ,SUM(mod3interfer_mrcount)                           AS mod3interfer_mrcount
        ,SUM(overlap_mrcount)                                AS overlap_mrcount
        ,SUM(overshoot_mrcount)                              AS overshoot_mrcount
        ,NVL(SUM(mod3interfer_mrcount) / SUM(rsrpcount),0)   AS mod3interfer_mrratio
        ,NVL(SUM(overlap_mrcount) / SUM(rsrpcount),0)        AS overlap_mrratio
        ,NVL(SUM(overshoot_mrcount) / SUM(rsrpcount),0)      AS overshoot_mrratio
        ,SUM(ulsinrcount - ulsinr_level7mrcount)                            AS ulsinrgood_cnt
        ,NVL(SUM(ulsinrcount - ulsinr_level7mrcount)/ SUM(ulsinrcount),1)   AS ulsinrgood_rate
    FROM
        zxvmax.aggr_lte_coverage_base_refactor_d
    WHERE p_provincecode = $dm_highway_section_celgrd_lte_d.p_provincecode$
        AND p_date = '$dm_highway_section_celgrd_lte_d.p_date$'
        AND plmn = '46011'
        AND regionid IS NOT NULL
        AND x_offset IS NOT NULL
        AND y_offset IS NOT NULL
    GROUP BY
        cellkey
       ,regionid
       ,x_offset
       ,y_offset
) A1
INNER JOIN
(
    -- 高速栅格
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,id             AS line_id
        ,name           AS line_name
        ,section_id_1km
        ,section_id
        ,CONCAT(name,section_id)    AS section_name
        ,region_id
        ,x_offset       AS x_offset_20
        ,y_offset       AS y_offset_20
        ,lon            AS grd_lon
        ,lat            AS grd_lat
    FROM
        cfg_highway_100m_section_20m_grid_rel
    WHERE p_provincecode = $dm_highway_section_celgrd_lte_d.p_provincecode$
) A2
ON A1.regionid = A2.region_id
    AND A1.x_offset_20 = A2.x_offset_20
    AND A1.y_offset_20 = A2.y_offset_20
LEFT JOIN
    -- 回填小区信息
    tmp_lte_cm A3
ON A1.cellkey = A3.cellkey
LEFT JOIN
(
    -- 判断是否高速小区
    SELECT
        cellkey
        ,line_id
    FROM
        -- 新高速小区表
        dm_highway_section_sector_lte_rel_use_d
    WHERE p_provincecode = $dm_highway_section_celgrd_lte_d.p_provincecode$
        AND p_date = '$dm_highway_section_celgrd_lte_d.p_date$'
        AND valid_flag = 1
    GROUP BY
        cellkey
        ,line_id
) A4
ON A1.cellkey = A4.cellkey
    AND A2.line_id = A4.line_id
;

