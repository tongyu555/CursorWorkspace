-- 20250709updateby : goupengcheng 10207
-- algorithm : 添加维度

create temporary function MultiGridToLonLat as 'com.gstools.impala.MultiGridToLonLat';

CACHE TABLE tmp_dm_highway_section_grd_nr_d_mrgrid AS
SELECT
    id                      AS line_id
   ,name                    AS line_name
   ,section_id
   ,CONCAT(name,section_id) AS section_name
   ,region_id
   ,x_offset
   ,y_offset
   ,section_id_1km
   ,split(MultiGridToLonLat(region_id,CAST(x_offset AS int),CAST(y_offset AS int),20),',') AS arr_lonlat
FROM
    cfg_highway_100m_section_20m_grid_rel
WHERE p_provincecode = $dm_highway_section_grd_nr_d.p_provincecode$
    AND region_id IS NOT NULL
    AND x_offset IS NOT NULL
    AND y_offset IS NOT NULL
    AND id IS NOT NULL
    AND section_id IS NOT NULL
    AND section_id_1km IS NOT NULL
;


INSERT OVERWRITE TABLE dm_highway_section_grd_nr_d
PARTITION (
    p_provincecode = $dm_highway_section_grd_nr_d.p_provincecode$
    ,p_date = '$dm_highway_section_grd_nr_d.p_date$'
)
SELECT
    '$dm_highway_section_grd_nr_d.p_date$'                             AS day
    ,$dm_highway_section_grd_nr_d.p_provincecode$                       AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,districtcode
    ,district_name
    ,11                                                                  AS scene_type
    ,line_id
    ,line_name
    ,section_id
    ,section_name
    ,t1.regionid                                                         AS regionid
    ,t1.x_offset                                                         AS x_offset_20
    ,t1.y_offset                                                         AS y_offset_20
    ,(CAST(arr_lonlat[0] AS double) + CAST(arr_lonlat[2] AS double)) / 2 AS grd_lon
    ,(CAST(arr_lonlat[1] AS double) + CAST(arr_lonlat[3] AS double)) / 2 AS grd_lat
    ,totalrsrp
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,avgrsrp
    ,totalulsinr
    ,ulsinrcount
    ,avgulsinr
    ,ulsinrgood_cnt
    ,ulsinrgood_rate
    ,mod30interfer_mrcount       AS mod30interfer_mrcount
    ,overlap_mrcount
    ,overshoot_mrcount
    ,mod30interfer_mrratio       AS mod30interfer_mrratio
    ,overlap_mrratio
    ,overshoot_mrratio
    --add
    ,rsrp110_sinrf3_total
    ,validrsrp_sinr_mrcount_total
    ,rsrp110_sinrf3_rate_total
    ,rsrp110_sinrf3_ctcc
    ,validrsrp_sinr_mrcount_ctcc
    ,rsrp110_sinrf3_rate_ctcc
    ,section_id_1km
    -- 添加维度
    ,t1.freq    AS freq
FROM
(
    -- 电信用户
    SELECT
         regionid
        ,x_offset_20         AS x_offset
        ,y_offset_20         AS y_offset
        -- 添加维度
        ,freq
        ,sum(totalssrsrp)    AS totalrsrp
        ,sum(ssrsrpcount)    AS rsrpcount
        ,sum(ssrsrp_level3mrcount+ssrsrp_level4mrcount+ssrsrp_level5mrcount+ssrsrp_level6mrcount+ssrsrp_level7mrcount+ssrsrp_level8mrcount+ssrsrp_level9mrcount+ssrsrp_level10mrcount+ssrsrp_level11mrcount+ssrsrp_level12mrcount)   AS rsrpgoodcount_110
        ,sum(ssrsrp_level4mrcount+ssrsrp_level5mrcount+ssrsrp_level6mrcount+ssrsrp_level7mrcount+ssrsrp_level8mrcount+ssrsrp_level9mrcount+ssrsrp_level10mrcount+ssrsrp_level11mrcount+ssrsrp_level12mrcount)    AS rsrpgoodcount_105
        ,nvl(sum(ssrsrp_level3mrcount+ssrsrp_level4mrcount+ssrsrp_level5mrcount+ssrsrp_level6mrcount+ssrsrp_level7mrcount+ssrsrp_level8mrcount+ssrsrp_level9mrcount+ssrsrp_level10mrcount+ssrsrp_level11mrcount+ssrsrp_level12mrcount)/sum(ssrsrpcount),1)   AS rsrpgoodcount_rate_110
        ,nvl(sum(ssrsrp_level4mrcount+ssrsrp_level5mrcount+ssrsrp_level6mrcount+ssrsrp_level7mrcount+ssrsrp_level8mrcount+ssrsrp_level9mrcount+ssrsrp_level10mrcount+ssrsrp_level11mrcount+ssrsrp_level12mrcount)/sum(ssrsrpcount),1)    AS rsrpgoodcount_rate_105
        ,sum(totalssrsrp)/sum(ssrsrpcount)               AS avgrsrp
        ,sum(totalsssinr)                                AS totalulsinr
        ,sum(sssinrcount)                                AS ulsinrcount
        ,sum(totalsssinr)/sum(sssinrcount)               AS avgulsinr
        ,sum(sssinrgoodcount)                            AS ulsinrgood_cnt
        ,nvl(sum(sssinrgoodcount)/sum(sssinrcount),1)    AS ulsinrgood_rate
        ,sum(overlap_mrcount)                            AS overlap_mrcount
        ,sum(overshoot_mrcount)                          AS overshoot_mrcount
        ,nvl(sum(overlap_mrcount)/sum(ssrsrpcount),0)    AS overlap_mrratio
        ,nvl(sum(overshoot_mrcount)/sum(ssrsrpcount),0)  AS overshoot_mrratio
        ,sum(rsrp110_sinrf3) rsrp110_sinrf3_ctcc
        ,sum(validrsrp_sinr_totalmrcount)    validrsrp_sinr_mrcount_ctcc
        ,sum(rsrp110_sinrf3)/sum(validrsrp_sinr_totalmrcount)    rsrp110_sinrf3_rate_ctcc
        ,sum(mod30interfer_mrcount) as mod30interfer_mrcount
        ,sum(mod30interfer_mrcount)/sum(sssinrcount) as mod30interfer_mrratio
    FROM
        aggr_nr_coverage_celgrd_refactor_d
    WHERE p_provincecode = $dm_highway_section_grd_nr_d.p_provincecode$
        AND p_date = '$dm_highway_section_grd_nr_d.p_date$'
        AND plmn = '46011'
    GROUP BY
        regionid
       ,x_offset_20
       ,y_offset_20
       ,freq
) t1
left join
(
    -- 全量用户
    select
        regionid
        ,freq
        ,x_offset_20         AS x_offset
        ,y_offset_20         AS y_offset
        ,sum(rsrp110_sinrf3) rsrp110_sinrf3_total
        ,sum(validrsrp_sinr_totalmrcount)    validrsrp_sinr_mrcount_total
        ,sum(rsrp110_sinrf3)/sum(validrsrp_sinr_totalmrcount)    rsrp110_sinrf3_rate_total
    FROM
        aggr_nr_coverage_celgrd_refactor_d
    WHERE p_provincecode = $dm_highway_section_grd_nr_d.p_provincecode$
        AND p_date = '$dm_highway_section_grd_nr_d.p_date$'
    GROUP BY
        regionid
        ,freq
        ,x_offset_20
        ,y_offset_20
) t0
ON t1.regionid = t0.regionid
    AND t1.x_offset = t0.x_offset
    AND t1.y_offset = t0.y_offset
    AND t1.freq = t0.freq
INNER JOIN
    tmp_dm_highway_section_grd_nr_d_mrgrid t2
ON t1.regionid = t2.region_id
    AND t1.x_offset = t2.x_offset
    AND t1.y_offset = t2.y_offset
INNER JOIN
(
    SELECT
        districtcode
       ,regionid
       ,x_offset_20
       ,y_offset_20
    FROM
        cfg_grid_tag
    WHERE p_provincecode = $dm_highway_section_grd_nr_d.p_provincecode$
) t3
ON t1.regionid = t3.regionid
    AND t1.x_offset = t3.x_offset_20
    AND t1.y_offset = t3.y_offset_20
INNER JOIN
(
    SELECT
        provincecode
       ,province_name
       ,city_id AS citycode
       ,city_name
       ,district_id
       ,district_name
    FROM
        cfg_district
    WHERE provincecode = $dm_highway_section_grd_nr_d.p_provincecode$
    GROUP BY
        provincecode
       ,province_name
       ,city_id
       ,city_name
       ,district_id
       ,district_name
) t4
ON t3.districtcode = t4.district_id
;
