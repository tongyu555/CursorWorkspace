-- 20250701updateby : goupengcheng 10207
-- algorithm : 修改小区表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

cache table busytime_cell_flux_rank AS
select
    cellkey
    ,is_highload    is_highload
    ,puschprbtotmeanul  prb_usedul
    ,prb_ul_avail   prb_availul
    ,puschprbtotmeanul_rate prb_usedul_rate
    ,puschprbtotmeandl  prb_useddl
    ,prb_dl_avail   prb_availdl
    ,puschprbtotmeandl_rate prb_useddl_rate
    ,row_number() over(partition by cellkey order by (pdcp_sduoctul+pdcp_sduoctdl) desc) as cell_flux_rank
from
    aggr_lte_load_cell_h
where p_provincecode = $dm_highway_line_cell_lte_d.p_provincecode$
    and p_date = '$dm_highway_line_cell_lte_d.p_date$'
having cell_flux_rank = 1
;

INSERT OVERWRITE TABLE dm_highway_line_cell_lte_d
PARTITION (
    p_provincecode = $dm_highway_line_cell_lte_d.p_provincecode$
    ,p_date = '$dm_highway_line_cell_lte_d.p_date$'
)
SELECT
    '$dm_highway_line_cell_lte_d.p_date$'          AS day
    ,$dm_highway_line_cell_lte_d.p_provincecode$    AS provincecode
    ,a.province_name
    ,a.citycode
    ,a.city_name
    ,a.districtcode
    ,a.district_name
    ,a.scene_type
    ,a.line_id
    ,a.line_name
    ,'4G' as net_type
    ,a.enbid
    ,a.cellid
    ,a.cellkey
    ,a.cellname
    ,a.cell_lon
    ,a.cell_lat
    ,a.freq
    ,a.pci
    ,a.height
    ,a.indoor_flag
    ,a.azimuth
    ,a.vendor
    ,a.bandwidth
    ,a.cover_rate
    ,0  is_inside
    ,a.master_operators
    ,is_highload
    ,prb_usedul
    ,prb_availul
    ,prb_usedul_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_useddl_rate
    ,totalrsrp
    ,rsrpcount*cover_rate as rsrpcount_scene
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,avgrsrp
    ,flux_ul*cover_rate as  flux_ul
    ,flux_dl*cover_rate as  flux_dl
    ,flux*cover_rate as flux
    ,cqi_good_count
    ,cqi_total_count
    ,cqi_good_rate
    ,rrc_connreq
    ,rrc_connsucc
    ,rrc_connsucc_rate
    ,s1sig_attconnestab
    ,s1sig_succconnestab
    ,s1sig_succconnestab_rate
    ,erab_attestab
    ,erab_succestab
    ,erab_succestab_rate
    ,access_success_rate
    ,case when access_success_rate<0.98 then 1 else 0 end as is_bad_access
    ,erab_attestab_qci1
    ,erab_succestab_qci1
    ,erab_succestab_rate_qci1
    ,access_success_rate_qci1
    ,erab_abnormrel
    ,erab_normrel
    ,erab_drop_rate
    ,case when erab_drop_rate>0.02 then 1 else 0 end as is_bad_drop
    ,erab_abnormrel_qci1
    ,erab_normrel_qci1
    ,erab_drop_qci1_rate
    ,pdcp_sduoctdl
    ,pdcp_sdutailflowdl
    ,pdcp_thrptimedl
    ,pdcp_tailtimedl
    ,uexp_meanspeeddl
    ,case when uexp_meanspeeddl/bandwidth<0.4 then 1 else 0 end as is_bad_uexp_meanspeeddl
    ,pdcp_sdulosspktul_qci1
    ,pdcp_sdupktul_qci1
    ,pdcp_sdulosspktul_qci1_rate
    ,pdcp_sdulosspktdl_qci1
    ,pdcp_sdupktdl_qci1
    ,pdcp_sdulosspktdl_qci1_rate
    ,case when pdcp_sdulosspktul_qci1_rate>0.001 or pdcp_sdulosspktdl_qci1_rate>0.001 then 1 else 0 end as is_bad_losspkt
    ,videoplay_suc_cnt
    ,videoplay_req_cnt
    ,videoplay_suc_rate
    ,case
        when access_success_rate<0.98 then 1
        when erab_drop_rate>0.02 then 1
        when uexp_meanspeeddl/bandwidth<0.4 then 1
        else 0
    end as is_bad
from
(
    select
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,districtcode
        ,district_name
        ,scene_type
        ,line_id
        ,line_name
        ,enbid
        ,enbname
        ,cellid
        ,cellkey
        ,master_operators
        ,cell_lon
        ,cell_lat
        ,freq
        ,pci
        ,height
        ,indoor_flag
        ,azimuth
        ,cellname
        ,vendor
        ,bandwidth
        ,cover_rate
    from
        dm_highway_sector_lte_rel_use_d -- 修改输入表
    WHERE p_provincecode = $dm_highway_line_cell_lte_d.p_provincecode$
        AND p_date = '$dm_highway_line_cell_lte_d.p_date$'
        AND valid_flag = 1 -- 添加过滤条件
  ) a
left join
    busytime_cell_flux_rank  c
on a.cellkey =c.cellkey

left join
(
    select
        cellkey
        ,sum(totalrsrp) totalrsrp
        ,sum(rsrpcount) rsrpcount
        ,sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount+rsrp_5div_level8mrcount) rsrpgoodcount_110
        ,sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount) rsrpgoodcount_105
        ,nvl(sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount+rsrp_5div_level8mrcount)/sum(rsrpcount),1) rsrpgoodcount_rate_110
        ,nvl(sum(rsrp_5div_level1mrcount+rsrp_5div_level2mrcount+rsrp_5div_level3mrcount+rsrp_5div_level4mrcount+rsrp_5div_level5mrcount+rsrp_5div_level6mrcount+rsrp_5div_level7mrcount)/sum(rsrpcount),1) rsrpgoodcount_rate_105
        ,sum(totalrsrp)/sum(rsrpcount) avgrsrp
    from
        zxvmax.aggr_lte_coverage_cel_refactor_d
    WHERE p_provincecode = $dm_highway_line_cell_lte_d.p_provincecode$
        AND p_date = '$dm_highway_line_cell_lte_d.p_date$'
        AND plmn = '46011'
    GROUP BY cellkey
) d
on a.cellkey =d.cellkey

left join
(
    select
        concat(related_enb_id,'_',cel_id) as cellkey
        ,nvl(sum(pdcp_sduoctul)/1024,0)  as flux_ul
        ,nvl(sum(pdcp_sduoctdl)/1024,0)  as flux_dl
        ,nvl(sum(nvl(pdcp_sduoctul,0)+nvl(pdcp_sduoctdl,0))/1024,0) as flux
        ,sum(cqi7+cqi8+cqi9+cqi10+cqi11+cqi12+cqi13+cqi14+cqi15)    cqi_good_count
        ,sum(cqi)   cqi_total_count
        ,nvl(sum(cqi7+cqi8+cqi9+cqi10+cqi11+cqi12+cqi13+cqi14+cqi15)/sum(cqi),1)    cqi_good_rate
        ,sum(case when rrc_attconnestab_ue+rrc_attconnestab_net < rrc_succconnestab_ue+rrc_succconnestab_net then rrc_succconnestab_ue+rrc_succconnestab_net else rrc_attconnestab_ue+rrc_attconnestab_net end) rrc_connreq
        ,sum(rrc_succconnestab_ue+rrc_succconnestab_net)    rrc_connsucc
        ,nvl(sum(rrc_succconnestab_ue+rrc_succconnestab_net)/sum(case when rrc_attconnestab_ue+rrc_attconnestab_net < rrc_succconnestab_ue+rrc_succconnestab_net then rrc_succconnestab_ue+rrc_succconnestab_net else rrc_attconnestab_ue+rrc_attconnestab_net end),1)  rrc_connsucc_rate
        ,sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end)   s1sig_attconnestab
        ,sum(s1sig_succconnestab)   s1sig_succconnestab
        ,nvl(sum(s1sig_succconnestab)/sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end),1)   s1sig_succconnestab_rate
        ,sum(case when erab_initattestab+erab_addattestab < erab_initsuccestab+erab_addsuccestab then erab_initsuccestab+erab_addsuccestab else erab_initattestab+erab_addattestab end) erab_attestab
        ,sum(erab_initsuccestab+erab_addsuccestab)  erab_succestab
        ,nvl(sum(erab_initsuccestab+erab_addsuccestab)/sum(case when erab_initattestab+erab_addattestab < erab_initsuccestab+erab_addsuccestab then erab_initsuccestab+erab_addsuccestab else erab_initattestab+erab_addattestab end),1)    erab_succestab_rate
        ,nvl(sum(rrc_succconnestab_ue+rrc_succconnestab_net)/sum(case when rrc_attconnestab_ue+rrc_attconnestab_net < rrc_succconnestab_ue+rrc_succconnestab_net then rrc_succconnestab_ue+rrc_succconnestab_net else rrc_attconnestab_ue+rrc_attconnestab_net end),1) * nvl(sum(s1sig_succconnestab)/sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end),1) * nvl(sum(erab_initsuccestab+erab_addsuccestab)/sum(case when erab_initattestab+erab_addattestab < erab_initsuccestab+erab_addsuccestab then erab_initsuccestab+erab_addsuccestab else erab_initattestab+erab_addattestab end),1) access_success_rate
        ,sum(case when erab_initattestab_qci1+erab_addattestab_qci1 < erab_initsuccestab_qci1+erab_addsuccestab_qci1 then erab_initsuccestab_qci1+erab_addsuccestab_qci1 else erab_initattestab_qci1+erab_addattestab_qci1 end) erab_attestab_qci1
        ,sum(erab_initsuccestab_qci1+erab_addsuccestab_qci1)    erab_succestab_qci1
        ,nvl(sum(erab_initsuccestab_qci1+erab_addsuccestab_qci1)/sum(case when erab_initattestab_qci1+erab_addattestab_qci1 < erab_initsuccestab_qci1+erab_addsuccestab_qci1 then erab_initsuccestab_qci1+erab_addsuccestab_qci1 else erab_initattestab_qci1+erab_addattestab_qci1 end),1)  erab_succestab_rate_qci1
        ,nvl(sum(rrc_succconnestab_ue+rrc_succconnestab_net)/sum(case when rrc_attconnestab_ue+rrc_attconnestab_net < rrc_succconnestab_ue+rrc_succconnestab_net then rrc_succconnestab_ue+rrc_succconnestab_net else rrc_attconnestab_ue+rrc_attconnestab_net end),1) * nvl(sum(s1sig_succconnestab)/sum(case when s1sig_attconnestab < s1sig_succconnestab then s1sig_succconnestab else s1sig_attconnestab end),1) * nvl(sum(erab_initsuccestab_qci1+erab_addsuccestab_qci1)/sum(case when erab_initattestab_qci1+erab_addattestab_qci1 < erab_initsuccestab_qci1+erab_addsuccestab_qci1 then erab_initsuccestab_qci1+erab_addsuccestab_qci1 else erab_initattestab_qci1+erab_addattestab_qci1 end),1)   access_success_rate_qci1
        ,sum(erab_abnormrel)    erab_abnormrel
        ,sum(erab_normrel)  erab_normrel
        ,sum(erab_abnormrel)/sum(erab_abnormrel+erab_normrel)   erab_drop_rate
        ,sum(erab_abnormrel_qci1)   erab_abnormrel_qci1
        ,sum(erab_normrel_qci1) erab_normrel_qci1
        ,nvl(sum(erab_abnormrel_qci1)/sum(erab_abnormrel_qci1+erab_normrel_qci1),0) erab_drop_qci1_rate
        ,sum(pdcp_sduoctdl) pdcp_sduoctdl
        ,sum(pdcp_sdutailflowdl)    pdcp_sdutailflowdl
        ,sum(pdcp_thrptimedl)   pdcp_thrptimedl
        ,sum(pdcp_tailtimedl)   pdcp_tailtimedl
        ,sum((pdcp_sduoctdl-pdcp_sdutailflowdl)*8)/sum(( pdcp_thrptimedl-pdcp_tailtimedl)/1000) uexp_meanspeeddl
        ,sum(pdcp_sdulosspktul_qci1)    pdcp_sdulosspktul_qci1
        ,sum(pdcp_sdupktul_qci1)    pdcp_sdupktul_qci1
        ,nvl(sum(pdcp_sdulosspktul_qci1)/sum(pdcp_sdupktul_qci1),0) pdcp_sdulosspktul_qci1_rate
        ,sum(pdcp_sdulosspktdl_qci1)    pdcp_sdulosspktdl_qci1
        ,sum(pdcp_sdupktdl_qci1)    pdcp_sdupktdl_qci1
        ,nvl(sum(pdcp_sdulosspktdl_qci1)/sum(pdcp_sdupktdl_qci1),0) pdcp_sdulosspktdl_qci1_rate
    from
        itg_pm_lte_cel_h_cel_d
    WHERE p_provincecode = $dm_highway_line_cell_lte_d.p_provincecode$
        AND p_date = '$dm_highway_line_cell_lte_d.p_date$'
    group by
        concat(related_enb_id,'_',cel_id)
) e
on a.cellkey =e.cellkey
left join
(
    select
        concat(nodebid,'_',cellid) as cellkey
        ,sum(videoplaysuccesscount) videoplay_suc_cnt
        ,sum(videoplayrequestcount) videoplay_req_cnt
        ,sum(videoplaysuccesscount)/sum(videoplayrequestcount)  videoplay_suc_rate
    from
        aggr_4g_video_cel_e2e_d
    WHERE p_provincecode = $dm_highway_line_cell_lte_d.p_provincecode$
        AND reportdate = '$dm_highway_line_cell_lte_d.p_date$'
    group by
        concat(nodebid,'_',cellid)
) h
on a.cellkey =h.cellkey
;
