-- 20250709updateby : goupengcheng 10207
-- algorithm : 修改小区表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;
set spark.sql.crossJoin.enabled=true;

cache table busytime_cell_flux_rank
select
    cellkey
    ,is_highload    is_highload
    ,prb_usedul
    ,prb_availul
    ,prb_usedul_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_useddl_rate
    ,row_number() over(partition by cellkey order by flux desc) as cell_flux_rank
from
    aggr_nr_load_cell_h
where p_provincecode = $dm_highway_line_cell_nr_d.p_provincecode$
    and p_date = '$dm_highway_line_cell_nr_d.p_date$'
having cell_flux_rank = 1
;

INSERT OVERWRITE TABLE dm_highway_line_cell_nr_d
PARTITION (
    p_provincecode = $dm_highway_line_cell_nr_d.p_provincecode$
    ,p_date = '$dm_highway_line_cell_nr_d.p_date$'
)
SELECT
    '$dm_highway_line_cell_nr_d.p_date$'          AS day
    ,$dm_highway_line_cell_nr_d.p_provincecode$    AS provincecode
    ,a.province_name
    ,a.citycode
    ,a.city_name
    ,a.districtcode
    ,a.district_name
    ,a.scene_type
    ,a.line_id
    ,a.line_name
    ,'5G' AS net_type
    ,a.gnbid
    ,a.cellid
    ,a.cellkey
    ,a.cellname
    ,a.cell_lon
    ,a.cell_lat
    ,a.freq
    ,a.pci
    ,a.height
    ,a.indoor_flag
    ,a.azimuth
    ,a.vendor
    ,a.bandwidth
    ,a.cover_rate
    ,NULL as is_inside
    ,a.master_operators
    ,is_highload
    ,prb_usedul
    ,prb_availul
    ,prb_usedul_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_useddl_rate
    ,totalrsrp
    ,rsrpcount*cover_rate  as  rsrpcount_scene
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,nvl(rsrpgoodcount_110/rsrpcount,1)       rsrpgoodcount_rate_110
    ,nvl(rsrpgoodcount_105/rsrpcount,1)       rsrpgoodcount_rate_105
    ,rsrp110_sinrf3_total
    ,validrsrp_sinr_mrcount_total
    ,rsrp110_sinrf3_rate_total
    ,rsrp110_sinrf3_ctcc
    ,validrsrp_sinr_mrcount_ctcc
    ,rsrp110_sinrf3_ctcc/validrsrp_sinr_mrcount_ctcc  as rsrp110_sinrf3_rate_ctcc
    ,avgrsrp
    ,flux_ul*cover_rate as flux_ul
    ,flux_dl*cover_rate as flux_dl
    ,flux*cover_rate    as flux
    ,cqi_good_count
    ,cqi_total_count
    ,nvl(cqi_total_count/cqi_total_count,1)  cqi_good_rate
    ,rrc_connreq
    ,rrc_connsucc
    ,rrc_connsucc_rate
    ,ng_connatt
    ,ng_connsucc
    ,ng_connsucc_rate
    ,qos_initialestabreq
    ,qos_initialestabsucc
    ,qos_initialestabsucc_rate
    ,nvl(rrc_connsucc/rrc_connreq,1) * nvl(ng_connsucc/ng_connatt,1) * nvl(qos_initialestabsucc/qos_initialestabreq,1) access_success_rate
    ,case when nvl(rrc_connsucc/rrc_connreq,1) * nvl(ng_connsucc/ng_connatt,1) * nvl(qos_initialestabsucc/qos_initialestabreq,1)<0.98 then 1 else 0 end as is_bad_access
    ,ue_contextrelease
    ,ue_normalcontextrelease
    ,uecntx_drop_rate
    ,case when uecntx_drop_rate>0.02 then 1 else 0 end as is_bad_drop
    ,vonr_connreq
    ,vonr_connsucc
    ,vonr_connsucc_rate
    ,vonr_releasesum
    ,vonr_normalrelease
    ,vonr_drop_rate
    ,rlc_txbytesdl
    ,rlc_lasttxbytesdl
    ,rlc_txtimedl_exceptlastslot
    ,uexp_meanspeeddl
    ,case when freq='3.5G' and uexp_meanspeeddl/bandwidth<0.4 then 1 when  freq='2.1G' and uexp_meanspeeddl/bandwidth<0.5 then 1 else 0 end as is_bad_uexp_meanspeeddl
    ,vonr_rtp_rxpktul
    ,vonr_rtp_losspktul
    ,vonr_rtp_losspktul_rate
    ,vonr_rtp_rxpktdl
    ,vonr_rtp_losspktdl
    ,vonr_rtp_losspktdl_rate
    ,case when vonr_rtp_losspktul_rate>0.001 or vonr_rtp_losspktdl_rate>0.001 then 1 else 0 end as is_bad_losspkt
    ,vonr_ho_atttovolte
    ,vonr_ho_succtovolte
    ,vonr_ho_succtovolte_rate
    ,videoplay_suc_cnt
    ,videoplay_req_cnt
    ,videoplay_suc_rate
    -- 有一个质差就为质差
    ,case
        when nvl(rrc_connsucc/rrc_connreq,1) * nvl(ng_connsucc/ng_connatt,1) * nvl(qos_initialestabsucc/qos_initialestabreq,1)<0.98 then 1
        when uecntx_drop_rate>0.02 then 1
        when vonr_rtp_losspktul_rate>0.001 or vonr_rtp_losspktdl_rate>0.001 then 1
        else 0
    end as is_bad
    ,null as bad_cause
    ,null as solution
from
(
    -- 测试时需要确认字段是否足够，之前是*
    select
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,districtcode
        ,district_name
        ,scene_type
        ,line_id
        ,line_name
        ,enbid AS gnbid
        ,enbname
        ,cellid
        ,cellkey
        ,master_operators
        ,cell_lon
        ,cell_lat
        ,freq
        ,pci
        ,height
        ,indoor_flag
        ,azimuth
        ,cellname
        ,vendor
        ,bandwidth
        ,cover_rate
    from
        dm_highway_sector_nr_rel_use_d -- 修改输入表
    WHERE p_provincecode = $dm_highway_line_cell_nr_d.p_provincecode$
        AND p_date = '$dm_highway_line_cell_nr_d.p_date$'
        AND valid_flag = 1 -- 添加过滤条件
) a
left join
    busytime_cell_flux_rank c
on a.cellkey = c.cellkey
left join
(
    -- mr
    select
        cellkey
        ,sum(case when plmn='46011' then totalssrsrp else null end ) totalrsrp
        --rsrpcount*cover_rate  rsrpcount_scene
        ,sum(case when plmn='46011' then ssrsrpcount else null end )   rsrpcount
        ,sum(case when plmn='46011' then ssrsrp_level3mrcount+ssrsrp_level4mrcount+ssrsrp_level5mrcount+ssrsrp_level6mrcount+ssrsrp_level7mrcount+ssrsrp_level8mrcount+ssrsrp_level9mrcount+ssrsrp_level10mrcount+ssrsrp_level11mrcount+ssrsrp_level12mrcount else null end )  as rsrpgoodcount_110
        ,sum(case when plmn='46011' then ssrsrp_level4mrcount+ssrsrp_level5mrcount+ssrsrp_level6mrcount+ssrsrp_level7mrcount+ssrsrp_level8mrcount+ssrsrp_level9mrcount+ssrsrp_level10mrcount+ssrsrp_level11mrcount+ssrsrp_level12mrcount else null end )  as rsrpgoodcount_105
        --nvl(rsrpgoodcount_110/rsrpcount,1)       rsrpgoodcount_rate_110
        --nvl(rsrpgoodcount_105/rsrpcount,1)       rsrpgoodcount_rate_105
        ,sum(rsrp110_sinrf3) as rsrp110_sinrf3_total
        ,sum(validrsrp_sinr_totalmrcount) as validrsrp_sinr_mrcount_total
        ,sum(rsrp110_sinrf3)/sum(validrsrp_sinr_totalmrcount)  as rsrp110_sinrf3_rate_total
        ,sum(case when plmn='46011' then rsrp110_sinrf3 else null end )     as rsrp110_sinrf3_ctcc
        ,sum(case when plmn='46011' then validrsrp_sinr_totalmrcount else null end ) as validrsrp_sinr_mrcount_ctcc
        --rsrp110_sinrf3_ctcc/validrsrp_sinr_mrcount_ctcc  as rsrp110_sinrf3_rate_ctcc
        ,sum(totalssrsrp)/sum(ssrsrpcount)     avgrsrp
    from
        aggr_nr_coverage_cel_refactor_d
    WHERE p_provincecode = $dm_highway_line_cell_nr_d.p_provincecode$
        AND p_date = '$dm_highway_line_cell_nr_d.p_date$'
    group by cellkey
) d
on a.cellkey = d.cellkey
left join
(
    -- ldu
    select
        concat(split(cel_id,'-')[1],'_',split(cel_id,'-')[2]) as cellkey
        ,(nvl(sum(rlc_rxbytesul)/1024,0)+nvl(sum(nsa_rlc_rxbytesul)/1024,0)) flux_ul
        ,(nvl(sum(rlc_txbytesdl)/1024,0)+nvl(sum(nsa_rlc_txbytesdl)/1024,0)) flux_dl
        ,(nvl(sum(rlc_rxbytesul)/1024,0)+nvl(sum(nsa_rlc_rxbytesul)/1024,0)+nvl(sum(rlc_txbytesdl)/1024,0)+nvl(sum(nsa_rlc_txbytesdl)/1024,0))   flux
        ,sum(rlc_txbytesdl) rlc_txbytesdl
        ,sum(rlc_lasttxbytesdl) rlc_lasttxbytesdl
        ,sum(rlc_txtimedl_exceptlastslot)   rlc_txtimedl_exceptlastslot
        ,(sum(rlc_txbytesdl-rlc_lasttxbytesdl)*8)/(sum(rlc_txtimedl_exceptlastslot)/1000)   uexp_meanspeeddl
    from
        fact_pm_nr_lceldu_d
    WHERE p_provincecode = $dm_highway_line_cell_nr_d.p_provincecode$
        AND p_date = '$dm_highway_line_cell_nr_d.p_date$'
        and split(cel_id,'-')[0] = '46011'
    group by
        concat(split(cel_id,'-')[1],'_',split(cel_id,'-')[2])
) f
on a.cellkey = f.cellkey
left join
(
    -- celldu
    select
        concat(split(cel_id,'-')[1],'_',split(cel_id,'-')[2]) as cellkey
        ,sum(cqi_numintable_cqi10+cqi_numintable_cqi11+cqi_numintable_cqi12+cqi_numintable_cqi13+cqi_numintable_cqi14+cqi_numintable_cqi15+cqi_numintable2_cqi7+cqi_numintable2_cqi8+cqi_numintable2_cqi9+cqi_numintable2_cqi10+cqi_numintable2_cqi11+cqi_numintable2_cqi12+cqi_numintable2_cqi13+cqi_numintable2_cqi14+cqi_numintable2_cqi15)  cqi_good_count
        ,sum(cqi_numintable_cqi0+cqi_numintable_cqi1+cqi_numintable_cqi2+cqi_numintable_cqi3+cqi_numintable_cqi4+cqi_numintable_cqi5+cqi_numintable_cqi6+cqi_numintable_cqi7+cqi_numintable_cqi8+cqi_numintable_cqi9+cqi_numintable_cqi10+cqi_numintable_cqi11+cqi_numintable_cqi12+cqi_numintable_cqi13+cqi_numintable_cqi14+cqi_numintable_cqi15+cqi_numintable2_cqi0+cqi_numintable2_cqi1+cqi_numintable2_cqi2+cqi_numintable2_cqi3+cqi_numintable2_cqi4+cqi_numintable2_cqi5+cqi_numintable2_cqi6+cqi_numintable2_cqi7+cqi_numintable2_cqi8+cqi_numintable2_cqi9+cqi_numintable2_cqi10+cqi_numintable2_cqi11+cqi_numintable2_cqi12+cqi_numintable2_cqi13+cqi_numintable2_cqi14+cqi_numintable2_cqi15)   cqi_total_count
    --,nvl(cqi_total_count/cqi_total_count,1)   cqi_good_rate
    from
        fact_pm_nr_celldu_d
    WHERE p_provincecode = $dm_highway_line_cell_nr_d.p_provincecode$
        AND p_date = '$dm_highway_line_cell_nr_d.p_date$'
    group by
        concat(split(cel_id,'-')[1],'_',split(cel_id,'-')[2])
) e
on a.cellkey = e.cellkey
left join
(
    -- cellcu
    select
        concat(split(cel_id,'-')[1],'_',split(cel_id,'-')[2]) as cellkey
        ,sum(case when rrc_connreq < rrc_connsucc then rrc_connsucc else rrc_connreq end)   rrc_connreq
        ,sum(rrc_connsucc)  rrc_connsucc
        ,nvl(sum(rrc_connsucc)/sum(case when rrc_connreq < rrc_connsucc then rrc_connsucc else rrc_connreq end),1)  rrc_connsucc_rate
    from
        fact_pm_nr_cellcu_d
    WHERE p_provincecode = $dm_highway_line_cell_nr_d.p_provincecode$
        AND p_date = '$dm_highway_line_cell_nr_d.p_date$'
    group by
        concat(split(cel_id,'-')[1],'_',split(cel_id,'-')[2])
) h
on a.cellkey = h.cellkey
left join
(
    -- lcu
    select
        concat(split(cel_id,'-')[1],'_',split(cel_id,'-')[2]) as cellkey
        ,sum(case when ng_connatt < ng_connsucc then ng_connsucc else ng_connatt end)   ng_connatt
        ,sum(ng_connsucc)   ng_connsucc
        ,nvl(sum(ng_connsucc)/sum(case when ng_connatt < ng_connsucc then ng_connsucc else ng_connatt end),1)   ng_connsucc_rate
        ,sum(case when qos_initialestabreq < qos_initialestabsucc then qos_initialestabsucc else qos_initialestabreq end)   qos_initialestabreq
        ,sum(qos_initialestabsucc)  qos_initialestabsucc
        ,nvl(sum(qos_initialestabsucc)/sum(case when qos_initialestabreq < qos_initialestabsucc then qos_initialestabsucc else qos_initialestabreq end),1)  qos_initialestabsucc_rate
        ,sum(ue_contextrelease) ue_contextrelease
        ,sum(ue_normalcontextrelease)   ue_normalcontextrelease
        ,nvl(sum(ue_contextrelease - ue_normalcontextrelease)/sum(ue_contextrelease),0) uecntx_drop_rate
        ,sum(vonr_connreq)  vonr_connreq
        ,sum(vonr_connsucc) vonr_connsucc
        ,nvl(sum(vonr_connsucc)/sum(vonr_connreq),1)    vonr_connsucc_rate
        ,sum(vonr_releasesum)   vonr_releasesum
        ,sum(vonr_normalrelease)    vonr_normalrelease
        ,nvl(sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum),0)    vonr_drop_rate
        ,sum(vonr_rtp_rxpktul)  vonr_rtp_rxpktul
        ,sum(vonr_rtp_losspktul)    vonr_rtp_losspktul
        ,sum(vonr_rtp_losspktul)/sum(vonr_rtp_rxpktul)  vonr_rtp_losspktul_rate
        ,sum(vonr_rtp_rxpktdl)  vonr_rtp_rxpktdl
        ,sum(vonr_rtp_losspktdl)    vonr_rtp_losspktdl
        ,sum(vonr_rtp_losspktdl)/sum(vonr_rtp_rxpktdl)  vonr_rtp_losspktdl_rate
        ,sum(vonr_ho_atttovolte)    vonr_ho_atttovolte
        ,sum(vonr_ho_succtovolte)   vonr_ho_succtovolte
        ,sum(vonr_ho_succtovolte)/sum(vonr_ho_atttovolte)   vonr_ho_succtovolte_rate
    from
        fact_pm_nr_lcelcu_d
    WHERE p_provincecode = $dm_highway_line_cell_nr_d.p_provincecode$
        AND p_date = '$dm_highway_line_cell_nr_d.p_date$'
        and split(cel_id,'-')[0] = '46011'
    group by
        concat(split(cel_id,'-')[1],'_',split(cel_id,'-')[2])
) g
on a.cellkey = g.cellkey
left join
(
    -- video
    select
        concat(nodebid,'_',cellid) as cellkey
        ,sum(videoplaysuccesscount) videoplay_suc_cnt
        ,sum(videoplayrequestcount) videoplay_req_cnt
        ,sum(videoplaysuccesscount)/sum(videoplayrequestcount)  videoplay_suc_rate
    from
        aggr_5g_video_cel_e2e_d
    WHERE p_provincecode = $dm_highway_line_cell_nr_d.p_provincecode$
        AND p_date = '$dm_highway_line_cell_nr_d.p_date$'
        and interface=100
    group by
        nodebid
        ,cellid
) m
on a.cellkey = m.cellkey
;
