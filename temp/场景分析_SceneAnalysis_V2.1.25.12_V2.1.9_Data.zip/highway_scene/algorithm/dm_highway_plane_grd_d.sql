-- 20250711updateby : goupengcheng 10207
-- algorithm : 添加维度
create temporary function MultiGridToLonLat as 'com.gstools.impala.MultiGridToLonLat';

INSERT OVERWRITE TABLE dm_highway_plane_grd_d
PARTITION (
    p_provincecode = $dm_highway_plane_grd_d.p_provincecode$
    ,p_date = '$dm_highway_plane_grd_d.p_date$'
)
SELECT
    '$dm_highway_plane_grd_d.p_date$'                             AS day
    ,$dm_highway_plane_grd_d.p_provincecode$                      AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,net_type
    ,regionid
    ,x_offset_20
    ,y_offset_20
    ,(arr_lonlat[0] + arr_lonlat[2]) / 2    AS grd_lon
    ,(arr_lonlat[1] + arr_lonlat[3]) / 2    AS grd_lat
    ,rsrpcount
    ,avgrsrp
    ,ulsinrcount
    ,avgulsinr
    -- 添加维度
    ,freq
from
(
    -- 4G栅格覆盖汇总
    select
        province_name
        ,citycode
        ,city_name
        ,scene_type
        ,line_id
        ,line_name
        ,scene_subclass_type
        ,scene_subclass_id
        ,scene_subclass_name
        ,'4G'  net_type
        ,regionid
        ,x_offset_20
        ,y_offset_20
        ,split(MultiGridToLonLat(cast (regionid as int),cast(x_offset_20 as int ),cast(y_offset_20 as int) ,20), ',') AS arr_lonlat
        ,sum(rsrpcount)     rsrpcount
        ,sum(totalrsrp)/sum(rsrpcount)      avgrsrp
        ,sum(ulsinrcount)   ulsinrcount
        ,sum(totalulsinr)/sum(ulsinrcount)  avgulsinr
        -- 添加维度
        ,freq
    from
        dm_highway_plane_celgrd_lte_d
    WHERE p_provincecode = $dm_highway_plane_grd_d.p_provincecode$
        AND p_date = '$dm_highway_plane_grd_d.p_date$'
        AND regionid IS NOT NULL
        AND x_offset_20 IS NOT NULL
        AND y_offset_20 IS NOT NULL
    group by
        province_name
        ,citycode
        ,city_name
        ,scene_type
        ,line_id
        ,line_name
        ,scene_subclass_type
        ,scene_subclass_id
        ,scene_subclass_name
        ,regionid
        ,x_offset_20
        ,y_offset_20
        ,arr_lonlat
        -- 添加维度
        ,freq
    union all
    -- 5G栅格覆盖汇总
    select
        province_name
        ,citycode
        ,city_name
        ,scene_type
        ,line_id
        ,line_name
        ,scene_subclass_type
        ,scene_subclass_id
        ,scene_subclass_name
        ,'5G'  net_type
        ,regionid
        ,x_offset_20
        ,y_offset_20
        ,split(MultiGridToLonLat(cast (regionid as int),cast(x_offset_20 as int ),cast(y_offset_20 as int) ,20), ',') AS arr_lonlat
        ,sum(rsrpcount)     rsrpcount
        ,sum(totalrsrp)/sum(rsrpcount)      avgrsrp
        ,sum(ulsinrcount)   ulsinrcount
        ,sum(totalulsinr)/sum(ulsinrcount)  avgulsinr
        -- 添加维度
        ,freq
    from
        dm_highway_plane_celgrd_nr_d
    WHERE p_provincecode = $dm_highway_plane_grd_d.p_provincecode$
        AND p_date = '$dm_highway_plane_grd_d.p_date$'
        AND regionid IS NOT NULL
        AND x_offset_20 IS NOT NULL
        AND y_offset_20 IS NOT NULL
    group by
        province_name
        ,citycode
        ,city_name
        ,scene_type
        ,line_id
        ,line_name
        ,scene_subclass_type
        ,scene_subclass_id
        ,scene_subclass_name
        ,regionid
        ,x_offset_20
        ,y_offset_20
        ,arr_lonlat
        -- 添加维度
        ,freq
) A
;
