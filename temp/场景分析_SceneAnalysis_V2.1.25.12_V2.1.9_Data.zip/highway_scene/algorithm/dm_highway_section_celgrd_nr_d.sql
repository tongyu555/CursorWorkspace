-- auth : goupengcheng
-- since : 2025-07-16
-- algorithm :  高速5G路段小区栅格覆盖指标天表

-- 处理小文件
set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

SET hive.enforce.bucketing=TRUE;
SET hive.exec.compress.output=TRUE;
SET mapred.output.compress=TRUE;
SET mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
SET io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- 电联工参
CACHE TABLE tmp_nr_cm AS
SELECT
    cellkey
   ,cell_longitude                                      AS cell_lon
   ,cell_latitude                                       AS cell_lat
   ,freq                                                AS freq
   ,pci                                                 AS pci
   ,cell_height                                         AS height
   ,indoor_flag                                         AS indoor_flag
   ,cell_azimuth                                        AS azimuth
   ,REGEXP_REPLACE(gnbname,'\\\\;|,','_')               AS gnbname
   ,REGEXP_REPLACE(cellname,'\\\\;|,','_')              AS cellname
   ,vendor                                              AS vendor
   ,bandwidth_dl                                        AS bandwidth
   ,master_operators                                    AS master_operators
   ,ROW_NUMBER() OVER(PARTITION BY cellkey ORDER BY cell_longitude DESC) rn
FROM
    fact_nr_cm_projdata
WHERE p_provincecode = $dm_highway_section_celgrd_nr_d.p_provincecode$
HAVING rn = 1
;

INSERT OVERWRITE TABLE dm_highway_section_celgrd_nr_d
PARTITION (
    p_provincecode = $dm_highway_section_celgrd_nr_d.p_provincecode$
    ,p_date = '$dm_highway_section_celgrd_nr_d.p_date$'
)
SELECT
    '$dm_highway_section_celgrd_nr_d.p_date$'day
    ,$dm_highway_section_celgrd_nr_d.p_provincecode$    AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,11             AS scene_type
    ,A2.line_id     AS line_id
    ,line_name
    ,section_id
    ,section_id_1km
    ,section_name
    ,A1.regionid    AS regionid
    ,A1.x_offset_20 AS x_offset_20
    ,A1.y_offset_20 AS y_offset_20
    ,grd_lon
    ,grd_lat
    ,A1.cellkey     AS cellkey
    ,cellname
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,height
    ,indoor_flag
    ,azimuth
    ,vendor
    ,bandwidth
    ,master_operators
    -- 关联到场景小区则赋值1
    ,CASE WHEN A4.cellkey IS NOT NULL THEN 1 ELSE 0 END AS is_scene_cell
    ,totalrsrp
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,avgrsrp
    ,totalulsinr
    ,ulsinrcount
    ,avgulsinr
    ,ulsinrgood_cnt
    ,ulsinrgood_rate
    ,mod30interfer_mrcount
    ,overlap_mrcount
    ,overshoot_mrcount
    ,mod30interfer_mrratio
    ,overlap_mrratio
    ,overshoot_mrratio
    ,rsrp110_sinrf3_total
    ,validrsrp_sinr_mrcount_total
    ,rsrp110_sinrf3_rate_total
    ,rsrp110_sinrf3_ctcc
    ,validrsrp_sinr_mrcount_ctcc
    ,rsrp110_sinrf3_rate_ctcc
FROM
(
    -- mr数据
    SELECT
        cellkey                                                      AS cellkey
        ,regionid                                                    AS regionid
        ,x_offset_20                                                 AS x_offset_20
        ,y_offset_20                                                 AS y_offset_20
        ,sum(case when plmn='46011' then totalssrsrp else 0 end)     AS totalrsrp
        ,sum(case when plmn='46011' then ssrsrpcount else 0 end)     AS rsrpcount
        ,sum(case when plmn='46011' then totalssrsrp else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end) AS avgrsrp
        ,sum(case when plmn='46011' then NVL(ssrsrp_level3mrcount,0) + NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) else 0 end)    AS rsrpgoodcount_110
        ,sum(case when plmn='46011' then NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) else 0 end)  AS rsrpgoodcount_105
        ,nvl(sum(case when plmn='46011' then NVL(ssrsrp_level3mrcount,0) + NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end),1) AS rsrpgoodcount_rate_110
        ,nvl(sum(case when plmn='46011' then NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0) else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end),1)   AS rsrpgoodcount_rate_105
        ,sum(case when plmn='46011' then totalsssinr else 0 end)                                                                                                        AS totalulsinr
        ,sum(case when plmn='46011' then sssinrcount else 0 end)                                                                                                        AS ulsinrcount
        ,sum(case when plmn='46011' then totalsssinr else 0 end)/sum(case when plmn='46011' then sssinrcount else 0 end)                                                AS avgulsinr
        ,sum(case when plmn='46011' then mod30interfer_mrcount else 0 end)                                                                                              AS mod30interfer_mrcount
        ,sum(case when plmn='46011' then overlap_mrcount else 0 end)                                                                                                    AS overlap_mrcount
        ,sum(case when plmn='46011' then overshoot_mrcount else 0 end)                                                                                                  AS overshoot_mrcount
        ,nvl(sum(case when plmn='46011' then mod30interfer_mrcount else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end),0)                               AS mod30interfer_mrratio
        ,nvl(sum(case when plmn='46011' then overlap_mrcount else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end),0)                                     AS overlap_mrratio
        ,nvl(sum(case when plmn='46011' then overshoot_mrcount else 0 end)/sum(case when plmn='46011' then ssrsrpcount else 0 end),0)                                   AS overshoot_mrratio
        ,sum(rsrp110_sinrf3)                                                                                                                                            AS rsrp110_sinrf3_total
        ,sum(validrsrp_sinr_totalmrcount)                                                                                                                               AS validrsrp_sinr_mrcount_total
        ,sum(rsrp110_sinrf3)/sum(validrsrp_sinr_totalmrcount)                                                                                                           AS rsrp110_sinrf3_rate_total
        ,sum(case when plmn='46011' then rsrp110_sinrf3 else 0 end)                                                                                                     AS rsrp110_sinrf3_ctcc
        ,sum(case when plmn='46011' then validrsrp_sinr_totalmrcount else 0 end)                                                                                        AS validrsrp_sinr_mrcount_ctcc
        ,sum(case when plmn='46011' then rsrp110_sinrf3 else 0 end)/sum(case when plmn='46011' then validrsrp_sinr_totalmrcount else 0 end)                             AS rsrp110_sinrf3_rate_ctcc
        ,sum(case when plmn='46011' then sssinrgoodcount else 0 end)                                                                                                    AS ulsinrgood_cnt
        ,nvl(sum(case when plmn='46011' then sssinrgoodcount else 0 end)/sum(case when plmn='46011' then sssinrcount else 0 end),1)                                     AS ulsinrgood_rate
    FROM
        aggr_nr_coverage_celgrd_refactor_d
    WHERE p_provincecode = $dm_highway_section_celgrd_nr_d.p_provincecode$
        AND p_date = '$dm_highway_section_celgrd_nr_d.p_date$'
        AND regionid IS NOT NULL
        AND x_offset_20 IS NOT NULL
        AND y_offset_20 IS NOT NULL
    GROUP BY
        cellkey
       ,regionid
       ,x_offset_20
       ,y_offset_20
) A1
INNER JOIN
(
    -- 高速栅格
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,id             AS line_id
        ,name           AS line_name
        ,section_id_1km
        ,section_id
        ,CONCAT(name,section_id)    AS section_name
        ,region_id
        ,x_offset       AS x_offset_20
        ,y_offset       AS y_offset_20
        ,lon            AS grd_lon
        ,lat            AS grd_lat
    FROM
        cfg_highway_100m_section_20m_grid_rel
    WHERE p_provincecode = $dm_highway_section_celgrd_nr_d.p_provincecode$
) A2
ON A1.regionid = A2.region_id
    AND A1.x_offset_20 = A2.x_offset_20
    AND A1.y_offset_20 = A2.y_offset_20
LEFT JOIN
    -- 回填小区信息
    tmp_nr_cm A3
ON A1.cellkey = A3.cellkey
LEFT JOIN
(
    -- 判断是否高速小区
    SELECT
        cellkey
        ,line_id
    FROM
        -- 新高速小区表
        dm_highway_section_sector_nr_rel_use_d
    WHERE p_provincecode = $dm_highway_section_celgrd_nr_d.p_provincecode$
        AND p_date = '$dm_highway_section_celgrd_nr_d.p_date$'
        AND valid_flag = 1
    GROUP BY
        cellkey
        ,line_id
) A4
ON A1.cellkey = A4.cellkey
    AND A2.line_id = A4.line_id
;

