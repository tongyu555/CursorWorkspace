-- 20250711updateby : goupengcheng 10207
-- algorithm : 调整小区表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

-- 高速栅格
cache table tmp_cfg_highway_plane_scene_grid20m_rel
select
    distinct
     provincecode
    ,province_name
    ,citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,scene_subclass_type
    ,scene_subclass_id
    ,scene_subclass_name
    ,regionid
    ,x_offset_20
    ,y_offset_20
    ,grid_lon
    ,grid_lat
from
    cfg_highway_plane_scene_grid20m_rel
where p_provincecode=$dm_highway_plane_celgrd_nr_d.p_provincecode$
;

INSERT OVERWRITE TABLE dm_highway_plane_celgrd_nr_d
PARTITION (
    p_provincecode = $dm_highway_plane_celgrd_nr_d.p_provincecode$
    ,p_date = '$dm_highway_plane_celgrd_nr_d.p_date$'
)
SELECT
    '$dm_highway_plane_celgrd_nr_d.p_date$'                             AS day
    ,$dm_highway_plane_celgrd_nr_d.p_provincecode$                       AS provincecode
    ,b.province_name
    ,b.citycode
    ,b.city_name
    ,b.scene_type
    ,b.line_id
    ,b.line_name
    ,b.scene_subclass_type
    ,b.scene_subclass_id
    ,b.scene_subclass_name
    ,b.regionid
    ,b.x_offset_20
    ,b.y_offset_20
    ,b.grid_lon
    ,b.grid_lat
    ,c.cellkey
    ,c.cellname
    ,c.cell_lon
    ,c.cell_lat
    ,c.freq
    ,c.pci
    ,c.height
    ,c.indoor_flag
    ,c.azimuth
    ,c.vendor
    ,c.bandwidth
    ,c.master_operators
    ,totalrsrp
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,avgrsrp
    ,totalulsinr
    ,ulsinrcount
    ,avgulsinr
    ,ulsinrgood_cnt
    ,ulsinrgood_rate
    ,mod30interfer_mrcount
    ,overlap_mrcount
    ,overshoot_mrcount
    ,mod30interfer_mrratio
    ,overlap_mrratio
    ,overshoot_mrratio
    ,rsrp110_sinrf3_total
    ,validrsrp_sinr_mrcount_total
    ,rsrp110_sinrf3_rate_total
    ,rsrp110_sinrf3_ctcc
    ,validrsrp_sinr_mrcount_ctcc
    ,rsrp110_sinrf3_rate_ctcc
FROM
    tmp_cfg_highway_plane_scene_grid20m_rel b
left join
(
    -- mr数据汇总到小区栅格  电信
    SELECT
        regionid
        ,x_offset_20         AS x_offset
        ,y_offset_20         AS y_offset
        ,cellkey
        ,sum(totalssrsrp)    AS totalrsrp
        ,sum(ssrsrpcount)    AS rsrpcount
        ,sum(ssrsrp_level3mrcount+ssrsrp_level4mrcount+ssrsrp_level5mrcount+ssrsrp_level6mrcount+ssrsrp_level7mrcount+ssrsrp_level8mrcount+ssrsrp_level9mrcount+ssrsrp_level10mrcount+ssrsrp_level11mrcount+ssrsrp_level12mrcount)   AS rsrpgoodcount_110
        ,sum(ssrsrp_level4mrcount+ssrsrp_level5mrcount+ssrsrp_level6mrcount+ssrsrp_level7mrcount+ssrsrp_level8mrcount+ssrsrp_level9mrcount+ssrsrp_level10mrcount+ssrsrp_level11mrcount+ssrsrp_level12mrcount)    AS rsrpgoodcount_105
        ,nvl(sum(ssrsrp_level3mrcount+ssrsrp_level4mrcount+ssrsrp_level5mrcount+ssrsrp_level6mrcount+ssrsrp_level7mrcount+ssrsrp_level8mrcount+ssrsrp_level9mrcount+ssrsrp_level10mrcount+ssrsrp_level11mrcount+ssrsrp_level12mrcount)/sum(ssrsrpcount),1)   AS rsrpgoodcount_rate_110
        ,nvl(sum(ssrsrp_level4mrcount+ssrsrp_level5mrcount+ssrsrp_level6mrcount+ssrsrp_level7mrcount+ssrsrp_level8mrcount+ssrsrp_level9mrcount+ssrsrp_level10mrcount+ssrsrp_level11mrcount+ssrsrp_level12mrcount)/sum(ssrsrpcount),1)    AS rsrpgoodcount_rate_105
        ,sum(totalssrsrp)/sum(ssrsrpcount)               AS avgrsrp
        ,sum(totalsssinr)                                AS totalulsinr
        ,sum(sssinrcount)                                AS ulsinrcount
        ,sum(totalsssinr)/sum(sssinrcount)               AS avgulsinr
        ,sum(sssinrgoodcount)                            AS ulsinrgood_cnt
        ,nvl(sum(sssinrgoodcount)/sum(sssinrcount),1)    AS ulsinrgood_rate
        ,sum(overlap_mrcount)                            AS overlap_mrcount
        ,sum(overshoot_mrcount)                          AS overshoot_mrcount
        ,nvl(sum(overlap_mrcount)/sum(ssrsrpcount),0)    AS overlap_mrratio
        ,nvl(sum(overshoot_mrcount)/sum(ssrsrpcount),0)  AS overshoot_mrratio
        ,sum(rsrp110_sinrf3) rsrp110_sinrf3_ctcc
        ,sum(validrsrp_sinr_totalmrcount)    validrsrp_sinr_mrcount_ctcc
        ,sum(rsrp110_sinrf3)/sum(validrsrp_sinr_totalmrcount)    rsrp110_sinrf3_rate_ctcc
        ,sum(mod30interfer_mrcount) as mod30interfer_mrcount
        ,sum(mod30interfer_mrcount)/sum(sssinrcount) as mod30interfer_mrratio
    FROM
        aggr_nr_coverage_celgrd_refactor_d
    WHERE p_provincecode = $dm_highway_plane_celgrd_nr_d.p_provincecode$
        AND p_date = '$dm_highway_plane_celgrd_nr_d.p_date$'
        AND plmn = '46011'
    GROUP BY
        regionid
        ,x_offset_20
        ,y_offset_20
        ,cellkey
) d
ON b.regionid = d.regionid
    AND b.x_offset_20 = d.x_offset
    AND b.y_offset_20 = d.y_offset
left join
(
    -- mr数据汇总到小区栅格 全量
    select
        regionid
        ,x_offset_20         AS x_offset
        ,y_offset_20         AS y_offset
        ,cellkey
        ,sum(rsrp110_sinrf3) rsrp110_sinrf3_total
        ,sum(validrsrp_sinr_totalmrcount)    validrsrp_sinr_mrcount_total
        ,sum(rsrp110_sinrf3)/sum(validrsrp_sinr_totalmrcount)    rsrp110_sinrf3_rate_total
    FROM
        aggr_nr_coverage_celgrd_refactor_d
    WHERE p_provincecode = $dm_highway_plane_celgrd_nr_d.p_provincecode$
        AND p_date = '$dm_highway_plane_celgrd_nr_d.p_date$'
    GROUP BY
        regionid
        ,x_offset_20
        ,y_offset_20
        ,cellkey
) d1
ON d1.regionid = d.regionid
    AND d1.x_offset = d.x_offset
    AND d1.y_offset = d.y_offset
inner join
(
    -- 回填小区信息
    select
        cellkey
        ,cellname
        ,cell_lon
        ,cell_lat
        ,freq
        ,pci
        ,height
        ,indoor_flag
        ,azimuth
        ,vendor
        ,bandwidth
        ,master_operators
    from
        cfg_highway_plane_sector_nr_rel_use_d -- 更换输入表
    WHERE p_provincecode = $dm_highway_plane_celgrd_nr_d.p_provincecode$
        AND p_date = '$dm_highway_plane_celgrd_nr_d.p_date$'
        AND valid_flag = 1 -- 添加过滤条件

) c
on c.cellkey =d.cellkey
;

