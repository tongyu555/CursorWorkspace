-- 20250710updateby : goupengcheng 10207
-- algorithm : 调整小区表

set spark.sql.adaptive.enabled=true;

CACHE TABLE tmp_dm_highway_section_coverage_lte_d_info AS
-- 回填名称
SELECT
    b.provincecode
    ,province_name
    ,b.citycode
    ,city_name
    ,scene_type
    ,line_id
    ,line_name
    ,section_id
    ,section_name
    ,totalrsrp
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,case when rsrpgoodcount_110/rsrpcount>0.7 and rsrpcount>=20 then 1 else 0 end as is_section_coverage_110
    ,case when rsrpgoodcount_105/rsrpcount>0.7 and rsrpcount>=20 then 1 else 0 end as is_section_coverage_105
    ,avgrsrp
    ,good_grd_cnt_110
    ,good_grd_cnt_105
    ,grd_cnt
    ,good_grd_rate
    ,section_id_1km
FROM
(
    -- 汇总到路段
    select
        provincecode
        ,citycode
        ,scene_type
        ,line_id
        ,section_id_1km
        ,line_name
        ,section_id
        ,section_name
        ,sum(totalrsrp) totalrsrp
        ,sum(rsrpcount) rsrpcount
        ,sum(rsrpgoodcount_110) rsrpgoodcount_110
        ,sum(rsrpgoodcount_105) rsrpgoodcount_105
        ,sum(rsrpgoodcount_110)/sum(rsrpcount)  rsrpgoodcount_rate_110
        ,sum(rsrpgoodcount_105)/sum(rsrpcount)  rsrpgoodcount_rate_105
        ,sum(totalrsrp)/sum(rsrpcount)  avgrsrp
        ,sum(good_grd_cnt_110)  good_grd_cnt_110
        ,sum(good_grd_cnt_105)  good_grd_cnt_105
        ,sum(grd_cnt)   grd_cnt
        ,sum(good_grd_cnt_110)/sum(grd_cnt) good_grd_rate
    from
        dm_highway_section_coverage_lte_d
    WHERE p_provincecode = $dm_highway_section_lte_d.p_provincecode$
        AND p_date = '$dm_highway_section_lte_d.p_date$'
    group by
        provincecode
        ,citycode
        ,scene_type
        ,line_id
        ,section_id_1km
        ,line_name
        ,section_id
        ,section_name
)b
INNER JOIN
(
    -- 区县名称
    SELECT
        provincecode
       ,province_name
       ,city_id AS citycode
       ,city_name
    FROM
        cfg_district
    WHERE provincecode = $dm_highway_section_lte_d.p_provincecode$
    GROUP BY
        provincecode
       ,province_name
       ,city_id
       ,city_name
) d
ON b.provincecode = d.provincecode
    and b.citycode = d.citycode
;

INSERT OVERWRITE TABLE dm_highway_section_lte_d
PARTITION (
    p_provincecode = $dm_highway_section_lte_d.p_provincecode$
    ,p_date = '$dm_highway_section_lte_d.p_date$'
)
SELECT
    '$dm_highway_section_lte_d.p_date$'         AS day
    ,$dm_highway_section_lte_d.p_provincecode$   AS provincecode
    ,t1.province_name
    ,t1.citycode
    ,t1.city_name
    ,t1.scene_type
    ,t1.line_id
    ,t1.line_name
    ,t1.section_id
    ,t1.section_name
    ,totalrsrp
    ,rsrpcount
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,is_section_coverage_110
    ,is_section_coverage_105
    ,avgrsrp
    ,good_grd_cnt_110
    ,good_grd_cnt_105
    ,grd_cnt
    ,good_grd_rate
    ,prb_usedul
    ,prb_availul
    ,prb_usedul_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_useddl_rate
    ,cel_cnt
    ,highload_cnt
    ,flux_ul
    ,flux_dl
    ,flux
    ,cqi_good_count
    ,cqi_total_count
    ,cqi_good_rate
    ,rrc_connreq
    ,rrc_connsucc
    ,rrc_connsucc_rate
    ,s1sig_attconnestab
    ,s1sig_succconnestab
    ,s1sig_succconnestab_rate
    ,erab_attestab
    ,erab_succestab
    ,erab_succestab_rate
    ,access_success_rate
    ,bad_access_cnt
    ,erab_attestab_qci1
    ,erab_succestab_qci1
    ,erab_succestab_rate_qci1
    ,access_success_rate_qci1
    ,erab_abnormrel
    ,erab_normrel
    ,erab_drop_rate
    ,bad_drop_cnt
    ,erab_abnormrel_qci1
    ,erab_normrel_qci1
    ,erab_drop_qci1_rate
    ,pdcp_sduoctdl
    ,pdcp_sdutailflowdl
    ,pdcp_thrptimedl
    ,pdcp_tailtimedl
    ,uexp_meanspeeddl
    ,bad_uexp_meanspeeddl_cnt
    ,pdcp_sdulosspktul_qci1
    ,pdcp_sdupktul_qci1
    ,pdcp_sdulosspktul_qci1_rate
    ,pdcp_sdulosspktdl_qci1
    ,pdcp_sdupktdl_qci1
    ,pdcp_sdulosspktdl_qci1_rate
    ,bad_losspkt_cnt
    ,videoplay_suc_cnt
    ,videoplay_req_cnt
    ,videoplay_suc_rate
    ,bad_cel_cnt
    ,uexp_meanspeeddl_21_flow
    ,uexp_meanspeeddl_21_duration
    ,uexp_meanspeeddl_21
    ,cell_cnt_lte_ctcc
    ,cell_cnt_lte_cucc
    ,t1.section_id_1km
FROM
    tmp_dm_highway_section_coverage_lte_d_info t1
left join
(
    -- 指标汇总到路段
    SELECT
        provincecode
        ,e.line_id
        ,e.line_name
        ,a.section_id
        ,a.section_name
        ,a.section_id_1km
        ,sum(prb_usedul)    prb_usedul
        ,sum(prb_availul)   prb_availul
        ,sum(prb_usedul)/sum(prb_availul)   prb_usedul_rate
        ,sum(prb_useddl)    prb_useddl
        ,sum(prb_availdl)   prb_availdl
        ,sum(prb_useddl)/sum(prb_availdl)   prb_useddl_rate
        ,count(distinct e.cellkey)    cel_cnt
        ,count(case when is_highload=1 then 1 else null end)    highload_cnt
        ,sum(flux_ul)   flux_ul
        ,sum(flux_dl)   flux_dl
        ,sum(flux)  flux
        ,sum(cqi_good_count)    cqi_good_count
        ,sum(cqi_total_count)   cqi_total_count
        ,sum(cqi_good_count)/sum(cqi_total_count)   cqi_good_rate
        ,sum(rrc_connreq)   rrc_connreq
        ,sum(rrc_connsucc)  rrc_connsucc
        ,nvl(sum(rrc_connsucc)/sum(rrc_connreq),1)  rrc_connsucc_rate
        ,sum(s1sig_attconnestab)    s1sig_attconnestab
        ,sum(s1sig_succconnestab)   s1sig_succconnestab
        ,nvl(sum(s1sig_succconnestab)/sum(s1sig_attconnestab),1)    s1sig_succconnestab_rate
        ,sum(erab_attestab) erab_attestab
        ,sum(erab_succestab)    erab_succestab
        ,nvl(sum(erab_succestab)/sum(erab_attestab),1)  erab_succestab_rate
        ,nvl(sum(rrc_connsucc)/sum(rrc_connreq),1)*nvl(sum(s1sig_succconnestab)/sum(s1sig_attconnestab),1)*nvl(sum(erab_succestab)/sum(erab_attestab),1)    access_success_rate
        ,count(case when is_bad_access=1 then 1 else null end)  bad_access_cnt
        ,sum(erab_attestab_qci1)    erab_attestab_qci1
        ,sum(erab_succestab_qci1)   erab_succestab_qci1
        ,nvl(avg(erab_succestab_rate_qci1),1)  erab_succestab_rate_qci1
        ,nvl(avg(access_success_rate_qci1),1)   access_success_rate_qci1
        ,sum(erab_abnormrel)    erab_abnormrel
        ,sum(erab_normrel)  erab_normrel
        ,sum(erab_abnormrel)/sum(erab_abnormrel+erab_normrel)   erab_drop_rate
        ,count(case when is_bad_drop=1 then 1 else null end)    bad_drop_cnt
        ,sum(erab_abnormrel_qci1)   erab_abnormrel_qci1
        ,sum(erab_normrel_qci1) erab_normrel_qci1
        ,nvl(sum(erab_abnormrel_qci1)/sum(erab_abnormrel_qci1+erab_normrel_qci1),0) erab_drop_qci1_rate
        ,sum(pdcp_sduoctdl) pdcp_sduoctdl
        ,sum(pdcp_sdutailflowdl)    pdcp_sdutailflowdl
        ,sum(pdcp_thrptimedl)   pdcp_thrptimedl
        ,sum(pdcp_tailtimedl)   pdcp_tailtimedl
        ,sum((pdcp_sduoctdl-pdcp_sdutailflowdl)*8)/sum(( pdcp_thrptimedl-pdcp_tailtimedl)/1000) uexp_meanspeeddl
        ,count(case when is_bad_uexp_meanspeeddl=1 then 1 else null end)    bad_uexp_meanspeeddl_cnt
        ,sum(pdcp_sdulosspktul_qci1)    pdcp_sdulosspktul_qci1
        ,sum(pdcp_sdupktul_qci1)    pdcp_sdupktul_qci1
        ,nvl(sum(pdcp_sdulosspktul_qci1)/sum(pdcp_sdupktul_qci1),0) pdcp_sdulosspktul_qci1_rate
        ,sum(pdcp_sdulosspktdl_qci1)    pdcp_sdulosspktdl_qci1
        ,sum(pdcp_sdupktdl_qci1)    pdcp_sdupktdl_qci1
        ,nvl(sum(pdcp_sdulosspktdl_qci1)/sum(pdcp_sdupktdl_qci1),0) pdcp_sdulosspktdl_qci1_rate
        ,count(case when is_bad_losspkt=1 then 1 else null end) bad_losspkt_cnt
        ,sum(videoplay_suc_cnt) videoplay_suc_cnt
        ,sum(videoplay_req_cnt) videoplay_req_cnt
        ,sum(videoplay_suc_cnt)/sum(videoplay_req_cnt)  videoplay_suc_rate
        ,count(case when is_bad=1 then 1 else null end) bad_cel_cnt
        ,sum(case when freq = '2.1G' then (pdcp_sduoctdl-pdcp_sdutailflowdl)*8 else 0 end)  uexp_meanspeeddl_21_flow
        ,sum(case when freq = '2.1G' then (pdcp_thrptimedl-pdcp_tailtimedl)/1000 else 0 end)    uexp_meanspeeddl_21_duration
        ,sum(case when freq = '2.1G' then (pdcp_sduoctdl-pdcp_sdutailflowdl)*8 else 0 end) / sum(case when freq = '2.1G' then (pdcp_thrptimedl-pdcp_tailtimedl)/1000 else 0 end)    uexp_meanspeeddl_21
        ,count(distinct case when master_operators='电信承建' then e.cellkey else null end)   cell_cnt_lte_ctcc
        ,count(distinct case when master_operators='联通承建' then e.cellkey else null end)   cell_cnt_lte_cucc
    from
    (
        -- 调整为字段 之前是 *
        select
            provincecode
            ,province_name
            ,citycode
            ,city_name
            ,districtcode
            ,district_name
            ,scene_type
            ,line_id
            ,line_name
            ,net_type
            ,enbid
            ,cellid
            ,cellkey
            ,cellname
            ,cell_lon
            ,cell_lat
            ,freq
            ,pci
            ,height
            ,indoor_flag
            ,azimuth
            ,vendor
            ,bandwidth
            ,cover_rate
            ,is_inside
            ,master_operators
            ,is_highload
            ,prb_usedul
            ,prb_availul
            ,prb_usedul_rate
            ,prb_useddl
            ,prb_availdl
            ,prb_useddl_rate
            ,totalrsrp
            ,rsrpcount_scene
            ,rsrpcount
            ,rsrpgoodcount_110
            ,rsrpgoodcount_105
            ,rsrpgoodcount_rate_110
            ,rsrpgoodcount_rate_105
            ,avgrsrp
            ,flux_ul
            ,flux_dl
            ,flux
            ,cqi_good_count
            ,cqi_total_count
            ,cqi_good_rate
            ,rrc_connreq
            ,rrc_connsucc
            ,rrc_connsucc_rate
            ,s1sig_attconnestab
            ,s1sig_succconnestab
            ,s1sig_succconnestab_rate
            ,erab_attestab
            ,erab_succestab
            ,erab_succestab_rate
            ,access_success_rate
            ,is_bad_access
            ,erab_attestab_qci1
            ,erab_succestab_qci1
            ,erab_succestab_rate_qci1
            ,access_success_rate_qci1
            ,erab_abnormrel
            ,erab_normrel
            ,erab_drop_rate
            ,is_bad_drop
            ,erab_abnormrel_qci1
            ,erab_normrel_qci1
            ,erab_drop_qci1_rate
            ,pdcp_sduoctdl
            ,pdcp_sdutailflowdl
            ,pdcp_thrptimedl
            ,pdcp_tailtimedl
            ,uexp_meanspeeddl
            ,is_bad_uexp_meanspeeddl
            ,pdcp_sdulosspktul_qci1
            ,pdcp_sdupktul_qci1
            ,pdcp_sdulosspktul_qci1_rate
            ,pdcp_sdulosspktdl_qci1
            ,pdcp_sdupktdl_qci1
            ,pdcp_sdulosspktdl_qci1_rate
            ,is_bad_losspkt
            ,videoplay_suc_cnt
            ,videoplay_req_cnt
            ,videoplay_suc_rate
            ,is_bad
        FROM
            dm_highway_line_cell_lte_d
        WHERE p_provincecode = $dm_highway_section_lte_d.p_provincecode$
            AND p_date = '$dm_highway_section_lte_d.p_date$'
    ) e
    inner join
    (
        -- 根据小区回填路段
        select
             line_id
            ,line_name
            ,section_id
            ,section_name
            ,cellkey
            ,section_id_1km
        from
            dm_highway_section_sector_lte_rel_use_d -- 修改来源表
        WHERE p_provincecode = $dm_highway_section_lte_d.p_provincecode$
            AND p_date = '$dm_highway_section_lte_d.p_date$'
            AND valid_flag = 1 -- 添加过滤条件
    ) a
    ON e.line_id = a.line_id
        AND e.cellkey = a.cellkey
    group by
        provincecode
        ,e.line_id
        ,e.line_name
        ,a.section_id
        ,a.section_name
        ,a.section_id_1km
) t2
ON t1.line_id = t2.line_id
    AND t1.section_id_1km = t2.section_id_1km
    AND t1.section_id = t2.section_id
    AND t1.provincecode = t2.provincecode
;
