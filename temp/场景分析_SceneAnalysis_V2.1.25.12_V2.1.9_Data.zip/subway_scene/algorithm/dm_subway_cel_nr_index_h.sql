-- 20250626updateby : goupengcheng 10207
-- algorithm : 更换地铁小区输入表

set spark.sql.adaptive.enabled = true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 2;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;
set spark.sql.shuffle.partitions=1;

INSERT OVERWRITE TABLE dm_subway_cel_nr_index_h
PARTITION (
    p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
    ,p_date = '$dm_subway_cel_nr_index_h.p_date$'
    ,p_hour = $dm_subway_cel_nr_index_h.p_hour$
)
SELECT
    '$dm_subway_cel_nr_index_h.p_date$'         AS day
    ,$dm_subway_cel_nr_index_h.p_hour$           AS hour
    ,$dm_subway_cel_nr_index_h.p_provincecode$   AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,t1.subway_line_id                           AS subway_line_id
    ,subway_line
    ,t1.type                                     AS type
    ,t1.section_station_id                       AS section_station_id
    ,name
    ,t1.net_type                                 AS net_type
    ,gnbid
    ,gnbname
    ,cellid
    ,cellname
    ,t1.cellkey                                  AS cellkey
    ,master_operators
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,indoor_flag
    ,azimuth
    ,vendor
    ,bandwidth
    ,n1n2_usr_cnt
    ,NVL(flux_ul,0)                              AS flux_ul
    ,NVL(flux_dl,0)                              AS flux_dl
    ,NVL(flux,0)                                 AS flux
    ,rrc_userconnmean
    ,rrc_userconnmax
    ,is_highload
    ,prb_usedul
    ,prb_availul
    ,prb_usedul_rate
    ,prb_useddl
    ,prb_availdl
    ,prb_useddl_rate
    ,totalrsrp
    ,rsrpcount
    ,avgrsrp
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,NVL(rsrpgoodcount_rate_110,1)               AS rsrpgoodcount_rate_110
    ,NVL(rsrpgoodcount_rate_105,1)               AS rsrpgoodcount_rate_105
    ,NVL(is_bad_cover,0)                         AS is_bad_cover
    ,cqi_good_count
    ,cqi_total_count
    ,NVL(cqi_good_rate,1)                        AS cqi_good_rate
    ,rrc_connreq
    ,rrc_connsucc
    ,NVL(rrc_connsucc_rate,1)                    AS rrc_connsucc_rate
    ,ng_connatt
    ,ng_connsucc
    ,NVL(ng_connsucc_rate,1)                     AS ng_connsucc_rate
    ,qos_initialestabreq
    ,qos_initialestabsucc
    ,NVL(qos_initialestabsucc_rate,1)            As qos_initialestabsucc_rate
    ,NVL(rrc_connsucc_rate,1) * NVL(qos_initialestabsucc_rate,1) AS access_success_rate
    ,ue_contextrelease
    ,ue_normalcontextrelease
    ,NVL(uecntx_drop_rate,0)                     AS uecntx_drop_rate
    ,rlc_txbytesdl
    ,rlc_lasttxbytesdl
    ,rlc_txtimedl_exceptlastslot
    ,uexp_meanspeeddl
    ,CASE WHEN t9.gnodebid IS NOT NULL THEN 1 ELSE 0 END AS is_alarm
    ,scan_pay_suc_cnt
    ,scan_pay_req_cnt
    ,scan_pay_suc_rate
    ,scan_pay_tcpsetupackdelay
    ,CASE WHEN scan_pay_suc_rate < 0.8 OR scan_pay_tcpsetupackdelay > 800 THEN 1 ELSE 0 END AS is_bad_scan_pay
    ,CASE WHEN NVL(is_bad_cover,0) + NVL(is_highload,0) + NVL(CASE WHEN scan_pay_suc_rate < 0.8 OR scan_pay_tcpsetupackdelay > 800 THEN 1 ELSE 0 END,0) + NVL(if(t3.cellkey is not null and flux=0, 1, 0 ),0) + (0) > 0 THEN 1 ELSE 0 END AS is_bad
    ,web_duration
    ,video_duration
    ,im_duration
    ,game_duration
    ,NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0) AS duration_total
    ,httpwebrspcount
    ,httpwebreqcount
    ,httpwebrsprate
    ,httpwebdspdelay
    ,CASE WHEN httpwebscreendelay >= 30000 THEN NULL ELSE httpwebscreendelay END AS httpwebscreendelay
    ,videoplaysuccesscount
    ,videoplayrequestcount
    ,videothroughput
    ,videoplaytime_without_halt_sum
    ,videoplayhaltcount
    ,kqi_videoplayhaltcountpermin
    ,times_excellentdownlink
    ,times_inferiordownlink
    ,times_welldownlink
    ,times_excellentstallfrequ
    ,times_inferiorstallfrequ
    ,times_wellstallfrequ
    ,messagesucccount
    ,messagereqcount
    ,messagesucc_rate
    ,game_cnt
    ,gameinteractdelay
    ,dnsqueryrspcount
    ,dnsqueryreqcount
    ,dnsquerysuc_rate
    ,ROUND(0.1 * NVL(dnsquerysuc_rate,1) + 0.9 * (NVL(web_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(httpwebrsprate,1) + NVL(video_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(video_good_rate,1) + NVL(game_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(game_good_rate,1) + NVL(im_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(im_good_rate,1)),5) AS kqi_good_rate
    ,web_good_rate
    ,video_good_rate
    ,im_good_rate
    ,game_good_rate
    ,vonr_ho_atttovolte
    ,vonr_ho_succtovolte
    ,vonr_ho_succtovolte_rate
    ,vonr_rtp_rxpktul
    ,vonr_rtp_losspktul
    ,vonr_rtp_losspktul_rate
    ,vonr_rtp_rxpktdl
    ,vonr_rtp_losspktdl
    ,vonr_rtp_losspktdl_rate
    ,vonr_connreq
    ,vonr_connsucc
    ,vonr_connsucc_rate
    ,vonr_releasesum
    ,vonr_normalrelease
    ,vonr_abnorrelease_rate
    ,ho_succintragnb
    ,ho_succbyxn
    ,ho_succbyng
    ,ho_attintragnb
    ,ho_attbyxn
    ,ho_attbyng
    ,NVL(ho_succ_rate,1)     AS ho_succ_rate
    ,epsfb_voice_suc
    ,epsfb_voice_req
    ,epsfb_voice_suc_rate
    ,intra_5gstoepsbydata
    ,intra_5gstoepsbydata / rrc_connsucc AS intra_5gstoepsbydata_rate
    ,section_type
    ,is_indoor_section_station
    ,if(t3.cellkey is not null, 1, 0 ) is_pm_flag
    ,if(t3.cellkey is not null and flux=0, 1, 0 ) is_zero_flux
    ,wechat_message_suc_cnt
    ,wechat_message_req_cnt
    ,wechat_message_suc_rate
FROM
(
    SELECT
        provincecode
       ,province_name
       ,citycode
       ,city_name
       ,subway_line_id
       ,subway_line
       ,type
       ,section_station_id
       ,name
       ,net_type
       -- 字段名统一改成了enb了
       ,enbid   AS gnbid
       ,REGEXP_REPLACE(enbname,',','_') AS gnbname
       ,cellid
       ,REGEXP_REPLACE(cellname,',','_') AS cellname
       ,cellkey
       ,master_operators
       ,cell_lon
       ,cell_lat
       ,freq
       ,pci
       ,indoor_flag
       ,azimuth
       ,vendor
       ,bandwidth
        ,section_type
        ,is_indoor_section_station
    FROM
        dm_subway_section_station_sector_nr_rel_use_d  -- 切换数据源 20250626
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_section_station_sector_nr_rel_use_d.p_date$'
        AND citycode > 0
        AND valid_flag = 1  -- 添加过滤条件 20250626
) t1
LEFT JOIN
(
    SELECT
        subway_line_id
       ,type
       ,section_station_id
       ,cellkey
       ,count(distinct imsi)  AS n1n2_usr_cnt
    FROM
        dm_subway_usrcel_list_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
        AND net_type = '5G'
    GROUP BY
        subway_line_id
       ,type
       ,section_station_id
       ,cellkey
) t2
ON t1.subway_line_id = t2.subway_line_id
    AND t1.type = t2.type
    AND t1.section_station_id = t2.section_station_id
    AND t1.cellkey = t2.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,SUM(flux_ul) / 1024                         AS flux_ul
       ,SUM(flux_dl) / 1024                         AS flux_dl
       ,SUM(NVL(flux_ul,0) + NVL(flux_dl,0)) / 1024 AS flux
       ,AVG(rrc_userconnmean)                       AS rrc_userconnmean
       ,MAX(rrc_userconnmax)                        AS rrc_userconnmax
       ,MAX(is_highload)                            AS is_highload
       ,SUM(prb_usedul)                             AS prb_usedul
       ,SUM(prb_availul)                            AS prb_availul
       ,SUM(prb_usedul) / SUM(prb_availul)          AS prb_usedul_rate
       ,SUM(prb_useddl)                             AS prb_useddl
       ,SUM(prb_availdl)                            AS prb_availdl
       ,SUM(prb_useddl) / SUM(prb_availdl)          AS prb_useddl_rate
    FROM
        aggr_nr_load_cell_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
    GROUP BY cellkey
) t3
ON t1.cellkey = t3.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,SUM(totalssrsrp)                  AS totalrsrp
       ,SUM(ssrsrpcount)                  AS rsrpcount
       ,SUM(totalssrsrp)/SUM(ssrsrpcount) AS avgrsrp
       ,SUM(NVL(ssrsrp_level3mrcount,0) + NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0))   AS rsrpgoodcount_110
       ,SUM(NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0)) AS rsrpgoodcount_105
       ,SUM(NVL(ssrsrp_level3mrcount,0) + NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0))/  SUM(ssrsrpcount)    AS rsrpgoodcount_rate_110
       ,SUM(NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0))/SUM(ssrsrpcount)    AS rsrpgoodcount_rate_105
       ,CASE WHEN SUM(NVL(ssrsrp_level4mrcount,0) + NVL(ssrsrp_level5mrcount,0) + NVL(ssrsrp_level6mrcount,0) + NVL(ssrsrp_level7mrcount,0) + NVL(ssrsrp_level8mrcount,0) + NVL(ssrsrp_level9mrcount,0) + NVL(ssrsrp_level10mrcount,0) + NVL(ssrsrp_level11mrcount,0) + NVL(ssrsrp_level12mrcount,0)) / SUM(ssrsrpcount) < 0.95 THEN 1 ELSE 0 END   AS is_bad_cover
    FROM
        aggr_nr_coverage_cel_refactor_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
        AND plmn = '46011'
    GROUP BY cellkey
) t4
ON t1.cellkey = t4.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])   AS cellkey
       ,SUM(NVL(cqi_numintable_cqi10,0) + NVL(cqi_numintable_cqi11,0) + NVL(cqi_numintable_cqi12,0) + NVL(cqi_numintable_cqi13,0) + NVL(cqi_numintable_cqi14,0) + NVL(cqi_numintable_cqi15,0) + NVL(cqi_numintable2_cqi7,0) + NVL(cqi_numintable2_cqi8,0) + NVL(cqi_numintable2_cqi9,0) + NVL(cqi_numintable2_cqi10,0) + NVL(cqi_numintable2_cqi11,0) + NVL(cqi_numintable2_cqi12,0) + NVL(cqi_numintable2_cqi13,0) + NVL(cqi_numintable2_cqi14,0) + NVL(cqi_numintable2_cqi15,0)) AS cqi_good_count
       ,SUM(NVL(cqi_numintable_cqi0,0) + NVL(cqi_numintable_cqi1,0) + NVL(cqi_numintable_cqi2,0) + NVL(cqi_numintable_cqi3,0) + NVL(cqi_numintable_cqi4,0) + NVL(cqi_numintable_cqi5,0) + NVL(cqi_numintable_cqi6,0) + NVL(cqi_numintable_cqi7,0) + NVL(cqi_numintable_cqi8,0) + NVL(cqi_numintable_cqi9,0) + NVL(cqi_numintable_cqi10,0) + NVL(cqi_numintable_cqi11,0) + NVL(cqi_numintable_cqi12,0) + NVL(cqi_numintable_cqi13,0) + NVL(cqi_numintable_cqi14,0) + NVL(cqi_numintable_cqi15,0) + NVL(cqi_numintable2_cqi0,0) + NVL(cqi_numintable2_cqi1,0) + NVL(cqi_numintable2_cqi2,0) + NVL(cqi_numintable2_cqi3,0) + NVL(cqi_numintable2_cqi4,0) + NVL(cqi_numintable2_cqi5,0) + NVL(cqi_numintable2_cqi6,0) + NVL(cqi_numintable2_cqi7,0) + NVL(cqi_numintable2_cqi8,0) + NVL(cqi_numintable2_cqi9,0) + NVL(cqi_numintable2_cqi10,0) + NVL(cqi_numintable2_cqi11,0) + NVL(cqi_numintable2_cqi12,0) + NVL(cqi_numintable2_cqi13,0) + NVL(cqi_numintable2_cqi14,0) + NVL(cqi_numintable2_cqi15,0)) AS cqi_total_count
       ,SUM(NVL(cqi_numintable_cqi10,0) + NVL(cqi_numintable_cqi11,0) + NVL(cqi_numintable_cqi12,0) + NVL(cqi_numintable_cqi13,0) + NVL(cqi_numintable_cqi14,0) + NVL(cqi_numintable_cqi15,0) + NVL(cqi_numintable2_cqi7,0) + NVL(cqi_numintable2_cqi8,0) + NVL(cqi_numintable2_cqi9,0) + NVL(cqi_numintable2_cqi10,0) + NVL(cqi_numintable2_cqi11,0) + NVL(cqi_numintable2_cqi12,0) + NVL(cqi_numintable2_cqi13,0) + NVL(cqi_numintable2_cqi14,0) + NVL(cqi_numintable2_cqi15,0)) / SUM(NVL(cqi_numintable_cqi0,0) + NVL(cqi_numintable_cqi1,0) + NVL(cqi_numintable_cqi2,0) + NVL(cqi_numintable_cqi3,0) + NVL(cqi_numintable_cqi4,0) + NVL(cqi_numintable_cqi5,0) + NVL(cqi_numintable_cqi6,0) + NVL(cqi_numintable_cqi7,0) + NVL(cqi_numintable_cqi8,0) + NVL(cqi_numintable_cqi9,0) + NVL(cqi_numintable_cqi10,0) + NVL(cqi_numintable_cqi11,0) + NVL(cqi_numintable_cqi12,0) + NVL(cqi_numintable_cqi13,0) + NVL(cqi_numintable_cqi14,0) + NVL(cqi_numintable_cqi15,0) + NVL(cqi_numintable2_cqi0,0) + NVL(cqi_numintable2_cqi1,0) + NVL(cqi_numintable2_cqi2,0) + NVL(cqi_numintable2_cqi3,0) + NVL(cqi_numintable2_cqi4,0) + NVL(cqi_numintable2_cqi5,0) + NVL(cqi_numintable2_cqi6,0) + NVL(cqi_numintable2_cqi7,0) + NVL(cqi_numintable2_cqi8,0) + NVL(cqi_numintable2_cqi9,0) + NVL(cqi_numintable2_cqi10,0) + NVL(cqi_numintable2_cqi11,0) + NVL(cqi_numintable2_cqi12,0) + NVL(cqi_numintable2_cqi13,0) + NVL(cqi_numintable2_cqi14,0) + NVL(cqi_numintable2_cqi15,0)) AS cqi_good_rate
    FROM
        fact_pm_nr_celldu_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
    GROUP BY CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])
) t5
ON t1.cellkey = t5.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])   AS cellkey
       ,sum(case when rrc_connreq < rrc_connsucc then rrc_connsucc else rrc_connreq end)                    AS rrc_connreq
       ,sum(rrc_connsucc)                                                                                   AS rrc_connsucc
       ,sum(rrc_connsucc)/sum(case when rrc_connreq < rrc_connsucc then rrc_connsucc else rrc_connreq end)  AS rrc_connsucc_rate
    FROM
        fact_pm_nr_cellcu_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
    GROUP BY CONCAT(SPLIT(master_phy_cell_id,'-')[1],'_',SPLIT(master_phy_cell_id,'-')[2])
) t6
ON t1.cellkey = t6.cellkey
LEFT JOIN
(

    SELECT
        CONCAT(SPLIT(cel_id,'-')[1],'_',SPLIT(cel_id,'-')[2])   AS cellkey
       ,max(rrc_connmax)                                                                                                                                    AS rrc_connmax
       ,avg(rrc_connmean)                                                                                                                                   AS rrc_connmean
       ,sum(case when ng_connatt < ng_connsucc then ng_connsucc else ng_connatt end)                                                                        AS ng_connatt
       ,sum(ng_connsucc)                                                                                                                                    AS ng_connsucc
       ,nvl(sum(ng_connsucc)/sum(case when ng_connatt < ng_connsucc then ng_connsucc else ng_connatt end),1)                                                AS ng_connsucc_rate
       ,sum(case when qos_initialestabreq < qos_initialestabsucc then qos_initialestabsucc else qos_initialestabreq end)                                    AS qos_initialestabreq
       ,sum(qos_initialestabsucc)                                                                                                                           AS qos_initialestabsucc
       ,nvl(sum(qos_initialestabsucc)/sum(case when qos_initialestabreq < qos_initialestabsucc then qos_initialestabsucc else qos_initialestabreq end),1)   AS qos_initialestabsucc_rate
       ,sum(ue_contextrelease)                                                                                                                              AS ue_contextrelease
       ,sum(ue_normalcontextrelease)                                                                                                                        AS ue_normalcontextrelease
       ,nvl(sum(ue_contextrelease - ue_normalcontextrelease)/sum(ue_contextrelease),0)                                                                      AS uecntx_drop_rate
       ,sum(vonr_ho_atttovolte)                                                                                                                             AS vonr_ho_atttovolte
       ,sum(vonr_ho_succtovolte)                                                                                                                            AS vonr_ho_succtovolte
       ,sum(vonr_ho_succtovolte)/sum(vonr_ho_atttovolte)                                                                                                    AS vonr_ho_succtovolte_rate
       ,sum(vonr_rtp_rxpktul)                                                                                                                               AS vonr_rtp_rxpktul
       ,sum(vonr_rtp_losspktul)                                                                                                                             AS vonr_rtp_losspktul
       ,sum(vonr_rtp_losspktul)/sum(vonr_rtp_rxpktul)                                                                                                       AS vonr_rtp_losspktul_rate
       ,sum(vonr_rtp_rxpktdl)                                                                                                                               AS vonr_rtp_rxpktdl
       ,sum(vonr_rtp_losspktdl)                                                                                                                             AS vonr_rtp_losspktdl
       ,sum(vonr_rtp_losspktdl)/sum(vonr_rtp_rxpktdl)                                                                                                       AS vonr_rtp_losspktdl_rate
       ,sum(vonr_connreq)                                                                                                                                   AS vonr_connreq
       ,sum(vonr_connsucc)                                                                                                                                  AS vonr_connsucc
       ,sum(vonr_connsucc)/sum(vonr_connreq)                                                                                                                AS vonr_connsucc_rate
       ,sum(vonr_releasesum)                                                                                                                                AS vonr_releasesum
       ,sum(vonr_normalrelease)                                                                                                                             AS vonr_normalrelease
       ,sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)                                                                                        AS vonr_abnorrelease_rate
       ,sum(ho_succintragnb)                                                                                                                                AS ho_succintragnb
       ,sum(ho_succbyxn)                                                                                                                                    AS ho_succbyxn
       ,sum(ho_succbyng)                                                                                                                                    AS ho_succbyng
       ,sum(case when ho_attintragnb<ho_succintragnb then ho_succintragnb else ho_attintragnb end)                                                          AS ho_attintragnb
       ,sum(case when ho_attbyxn<ho_succbyxn then ho_succbyxn else ho_attbyxn end)                                                                          AS ho_attbyxn
       ,sum(case when ho_attbyng<ho_succbyng then ho_succbyng else ho_attbyng end)                                                                          AS ho_attbyng
       ,nvl(sum(NVL(ho_succintragnb,0) + NVL(ho_succbyxn,0) + NVL(ho_succbyng,0))/sum(case when ho_attintragnb<ho_succintragnb then ho_succintragnb else ho_attintragnb end + case when ho_attbyxn<ho_succbyxn then ho_succbyxn else ho_attbyxn end + case when ho_attbyng<ho_succbyng then ho_succbyng else ho_attbyng end),1)         AS ho_succ_rate
       ,sum(ho_5gstoepssuccbyvoice)                                                                                                                         AS epsfb_voice_suc
       ,sum(ho_5gstoepsreqbyvoice)                                                                                                                          AS epsfb_voice_req
       ,sum(ho_5gstoepssuccbyvoice)/sum(ho_5gstoepsreqbyvoice)                                                                                              AS epsfb_voice_suc_rate
       ,sum(intra_5gstoepsbydata)                                                                                                                           AS intra_5gstoepsbydata
    FROM
        fact_pm_nr_lcelcu_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
        AND SPLIT(cel_id,'-')[0] = '46011'
    GROUP BY cel_id
) t7
ON t1.cellkey = t7.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(SPLIT(cel_id,'-')[1],'_',SPLIT(cel_id,'-')[2])                               AS cellkey
       ,SUM(rlc_txbytesdl)                                                                  AS rlc_txbytesdl
       ,SUM(rlc_lasttxbytesdl)                                                              AS rlc_lasttxbytesdl
       ,SUM(rlc_txtimedl_exceptlastslot)                                                    AS rlc_txtimedl_exceptlastslot
       ,(SUM(rlc_txbytesdl-rlc_lasttxbytesdl)*8)/(SUM(rlc_txtimedl_exceptlastslot)/1000)    AS uexp_meanspeeddl
    FROM
        fact_pm_nr_lceldu_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
        AND SPLIT(cel_id,'-')[0] = '46011'
    GROUP BY cel_id
) t8
ON t1.cellkey = t8.cellkey
LEFT JOIN
(
    SELECT
        gnodebid
    FROM
        ods_ran_5g_alarm_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND src_eventtime <= CONCAT(REGEXP_REPLACE('$dm_subway_cel_nr_index_h.p_date$','-','/'),' ',LPAD($dm_subway_cel_nr_index_h.p_hour$ + 1,2,'0'))
        AND (src_clearancetimestamp IS NULL OR src_clearancetimestamp >= CONCAT(REGEXP_REPLACE('$dm_subway_cel_nr_index_h.p_date$','-','/'),' ',LPAD($dm_subway_cel_nr_index_h.p_hour$,2,'0')))
        AND src_eventtime < src_clearancetimestamp
    GROUP BY gnodebid
) t9
ON t1.gnbid = t9.gnodebid
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,sum(case when servicetype='88888888' then httpwebrspcount else 0 end)   AS scan_pay_suc_cnt
       ,sum(case when servicetype='88888888' then httpwebreqcount else 0 end)   AS scan_pay_req_cnt
       ,sum(case when servicetype='88888888' then httpwebrspcount else 0 end)/sum(case when servicetype='88888888' then httpwebreqcount else 0 end) AS scan_pay_suc_rate
       ,sum(case when servicetype='88888888' then tcpsetupackdelay_avg*httpwebreqcount else 0 end)/sum(case when servicetype='88888888' then httpwebreqcount else 0 end)    AS scan_pay_tcpsetupackdelay
        ,sum(case when servicetype='01000202' then httpwebrspcount else 0 end) wechat_message_suc_cnt
        ,sum(case when servicetype='01000202' then httpwebreqcount else 0 end) wechat_message_req_cnt
        ,sum(case when servicetype='01000202' then httpwebrspcount else 0 end)/sum(case when servicetype='01000202' then httpwebreqcount else 0 end) wechat_message_suc_rate

    FROM
        aggr_5g_im_appcel_e2e_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
        AND interface = 100
    GROUP BY
        nodebid
       ,cellid
) t10
ON t1.cellkey = t10.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)                                          AS cellkey
       ,sum(duration_sum)                                                   AS web_duration
       ,sum(httpwebrspcount)                                                AS httpwebrspcount
       ,sum(httpwebreqcount)                                                AS httpwebreqcount
       ,sum(httpwebrspcount)/sum(httpwebreqcount)                           AS httpwebrsprate
       ,sum(httpwebdspdelay_avg*httpwebrspcount)/sum(httpwebrspcount)       AS httpwebdspdelay
       ,sum(case when httpwebscreendelay_avg >= 30000 then null else httpwebscreendelay_avg end *httpwebrspcount)/sum(httpwebrspcount)    AS httpwebscreendelay
       ,sum(httpwebrspcount)/sum(httpwebreqcount)                           AS web_good_rate
    FROM
        aggr_5g_web_cel_e2e_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
        AND interface = 100
    GROUP BY
        nodebid
       ,cellid
) t11
ON t1.cellkey = t11.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,video_duration
       ,videoplaysuccesscount
       ,videoplayrequestcount
       ,videothroughput
       ,videoplaytime_without_halt_sum
       ,videoplayhaltcount
       ,kqi_videoplayhaltcountpermin
       ,times_excellentdownlink
       ,times_inferiordownlink
       ,times_welldownlink
       ,times_excellentstallfrequ
       ,times_inferiorstallfrequ
       ,times_wellstallfrequ
       ,CASE
            WHEN NVL(video_good_rate_1,0) <= NVL(video_good_rate_2,0) THEN NVL(video_good_rate_1,0)
            ELSE NVL(video_good_rate_2,0)
        END     AS video_good_rate
    FROM
    (
        SELECT
            CONCAT(nodebid,'_',cellid)                                              AS cellkey
           ,sum(duration_sum)                                                       AS video_duration
           ,sum(videoplaysuccesscount)                                              AS videoplaysuccesscount
           ,sum(videoplayrequestcount)                                              AS videoplayrequestcount
           ,sum(videothroughput*videoplaysuccesscount)/sum(videoplaysuccesscount) / 1024   AS videothroughput
           ,sum(videoplaytime_without_halt_sum)                                     AS videoplaytime_without_halt_sum
           ,sum(videoplayhaltcount)                                                 AS videoplayhaltcount
           ,case when sum(videoplaytime_without_halt_sum) !=0 then sum(videoplayhaltcount)*60000/sum(videoplaytime_without_halt_sum) else 0 end AS kqi_videoplayhaltcountpermin
           ,sum(times_excellentdownlink)                                            AS times_excellentdownlink
           ,sum(times_excellentdownlink)                                            AS times_inferiordownlink
           ,sum(times_welldownlink)                                                 AS times_welldownlink
           ,sum(times_excellentstallfrequ)                                          AS times_excellentstallfrequ
           ,sum(times_inferiorstallfrequ)                                           AS times_inferiorstallfrequ
           ,sum(times_wellstallfrequ)                                               AS times_wellstallfrequ
           ,sum(NVL(times_excellentdownlink,0) + NVL(times_welldownlink,0))/sum(NVL(times_excellentdownlink,0) + NVL(times_welldownlink,0) + NVL(times_inferiordownlink,0)) AS video_good_rate_1
           ,sum(NVL(times_excellentstallfrequ,0) + NVL(times_wellstallfrequ,0))/sum(NVL(times_excellentstallfrequ,0) + NVL(times_wellstallfrequ,0) + NVL(times_inferiorstallfrequ,0))  AS video_good_rate_2
        FROM
            aggr_5g_video_cel_e2e_h
        WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
            AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
            AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
            AND interface = 100
        GROUP BY
            nodebid
           ,cellid
    ) t
) t12
ON t1.cellkey = t12.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)                                              AS cellkey
       ,sum(duration_sum)                                                       AS im_duration
       ,sum(times_excellentsentrate)                                            AS messagesucccount
       ,sum(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate,0) + NVL(times_wellsentrate,0)) AS messagereqcount
       ,sum(times_excellentsentrate)/sum(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate,0) + NVL(times_wellsentrate,0))    AS messagesucc_rate
       ,sum(times_excellentsentrate)/sum(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate,0) + NVL(times_wellsentrate,0))    AS im_good_rate
    FROM
        aggr_5g_im_cel_e2e_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
        AND interface = 100
    GROUP BY
        nodebid
       ,cellid
) t13
ON t1.cellkey = t13.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,game_duration
       ,game_cnt
       ,gameinteractdelay
       ,CASE
            WHEN gameinteractdelay <= 150                       THEN 1
            WHEN 100 - (gameinteractdelay - 150) * 0.75 <= 0    THEN 0
            ELSE (100 - (gameinteractdelay - 150) * 0.75) / 100
        END AS game_good_rate
    FROM
    (
        SELECT
            CONCAT(nodebid,'_',cellid)  AS cellkey
           ,sum(duration_sum)           AS game_duration
           ,sum(httpwebreqcount)        AS game_cnt
           ,case when sum(httpwebreqcount)  !=0 then sum(gameinteractdelay_sum)/sum(httpwebreqcount) else 0 end AS gameinteractdelay
        FROM
            aggr_5g_game_cel_e2e_h
        WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
            AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
            AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
            AND interface = 100
        GROUP BY
            nodebid
           ,cellid
    ) t
) t14
ON t1.cellkey = t14.cellkey
LEFT JOIN
(
    SELECT
        cellkey                                    AS cellkey
       ,sum(dns_suc_cnt)                      AS dnsqueryrspcount
       ,sum(dns_query_cnt)                          AS dnsqueryreqcount
       ,sum(dns_suc_cnt)/sum(dns_query_cnt)   AS dnsquerysuc_rate
    FROM
        aggr_nr_dpi_dns_cel_h
    WHERE p_provincecode = $dm_subway_cel_nr_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_nr_index_h.p_date$'
        AND p_hour = $dm_subway_cel_nr_index_h.p_hour$
        AND interface = 100
    GROUP BY cellkey
) t15
ON t1.cellkey = t15.cellkey
distribute by rand()
;

