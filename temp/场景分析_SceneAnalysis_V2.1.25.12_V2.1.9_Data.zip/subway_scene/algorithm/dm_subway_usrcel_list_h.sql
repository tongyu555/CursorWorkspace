-- 20250626updateby : goupengcheng 10207
-- algorithm : 更换地铁小区输入表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 10;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;
set spark.sql.shuffle.partitions=8;

INSERT OVERWRITE TABLE dm_subway_usrcel_list_h
PARTITION (
    p_provincecode = $dm_subway_usrcel_list_h.p_provincecode$
    ,p_date = '$dm_subway_usrcel_list_h.p_date$'
    ,p_hour = $dm_subway_usrcel_list_h.p_hour$
)
SELECT
    '$dm_subway_usrcel_list_h.p_date$'          AS day
    ,$dm_subway_usrcel_list_h.p_hour$            AS hour
    ,$dm_subway_usrcel_list_h.p_provincecode$    AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,subway_line_id
    ,subway_line
    ,type
    ,section_station_id
    ,name
    ,net_type
    ,cellkey
    ,master_operators
    ,msisdn
    ,imsi
    ,imei
FROM
(
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,subway_line_id
        ,subway_line
        ,type
        ,section_station_id
        ,name
        ,net_type
        ,B1.cellkey  AS cellkey
        ,master_operators
        ,msisdn
        ,imsi
        ,imei
    FROM
    (
        SELECT
            provincecode
            ,province_name
            ,citycode
            ,city_name
            ,subway_line_id
            ,subway_line
            ,type
            ,section_station_id
            ,name
            ,net_type
            ,cellkey
            ,master_operators
        FROM
            dm_subway_section_station_sector_lte_rel_use_d  -- 切换数据源 20250626
        WHERE p_provincecode = $dm_subway_usrcel_list_h.p_provincecode$
            AND p_date = '$dm_subway_section_station_sector_lte_rel_use_d.p_date$'
            AND is_indoor_section_station = 1  -- 添加过滤条件 20250626
            AND valid_flag = 1  -- 添加过滤条件 20250626
    ) B1
    LEFT JOIN
    (
        SELECT
            CONCAT(enbid,'_',cellid)    AS cellkey
            ,msisdn
            ,imsi
            ,imei
        FROM
            aggr_4g_resident_celusr_h
        WHERE p_provincecode = $dm_subway_usrcel_list_h.p_provincecode$
            AND p_date = '$dm_subway_usrcel_list_h.p_date$'
            AND p_hour = $dm_subway_usrcel_list_h.p_hour$
        GROUP BY
            enbid
            ,cellid
            ,msisdn
            ,imsi
            ,imei
    ) B2
    ON B1.cellkey = B2.cellkey
    UNION ALL
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,subway_line_id
        ,subway_line
        ,type
        ,section_station_id
        ,name
        ,net_type
        ,B1.cellkey  AS cellkey
        ,master_operators
        ,msisdn
        ,imsi
        ,imei
    FROM
    (
        SELECT
            provincecode
            ,province_name
            ,citycode
            ,city_name
            ,subway_line_id
            ,subway_line
            ,type
            ,section_station_id
            ,name
            ,net_type
            ,cellkey
            ,master_operators
        FROM
            dm_subway_section_station_sector_nr_rel_use_d  -- 切换数据源 20250626
        WHERE p_provincecode = $dm_subway_usrcel_list_h.p_provincecode$
            AND p_date = '$dm_subway_section_station_sector_lte_rel_use_d.p_date$'
            AND is_indoor_section_station = 1  -- 添加过滤条件 20250626
            AND valid_flag = 1  -- 添加过滤条件 20250626
    ) B1
    LEFT JOIN
    (
        SELECT
            CONCAT(gnbid,'_',cellid)  AS cellkey
            ,msisdn
            ,supi    AS imsi
            ,pei     AS imei
        FROM
            aggr_nr_resident_usrcel_h
        WHERE p_provincecode = $dm_subway_usrcel_list_h.p_provincecode$
            AND p_date = '$dm_subway_usrcel_list_h.p_date$'
            AND p_hour = $dm_subway_usrcel_list_h.p_hour$
-- 去掉了原来多余group by
    ) B2
    ON B1.cellkey = B2.cellkey
) A
distribute by rand()
;
