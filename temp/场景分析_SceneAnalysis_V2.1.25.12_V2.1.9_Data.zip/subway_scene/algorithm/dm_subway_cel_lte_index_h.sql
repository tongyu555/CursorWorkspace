-- 20250626updateby : goupengcheng 10207
-- algorithm : 更换地铁小区输入表

set spark.sql.adaptive.enabled = true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 2;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;
set spark.sql.shuffle.partitions=1;

INSERT OVERWRITE TABLE dm_subway_cel_lte_index_h
PARTITION (
    p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
    ,p_date = '$dm_subway_cel_lte_index_h.p_date$'
    ,p_hour = $dm_subway_cel_lte_index_h.p_hour$
)
SELECT
    '$dm_subway_cel_lte_index_h.p_date$'        AS day
    ,$dm_subway_cel_lte_index_h.p_hour$          AS hour
    ,$dm_subway_cel_lte_index_h.p_provincecode$  AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,t1.subway_line_id                           AS subway_line_id
    ,subway_line
    ,t1.type                                     AS type
    ,t1.section_station_id                       AS section_station_id
    ,name
    ,t1.net_type                                 AS net_type
    ,enbid
    ,enbname
    ,cellid
    ,cellname
    ,t1.cellkey                                  AS cellkey
    ,master_operators
    ,cell_lon
    ,cell_lat
    ,freq
    ,pci
    ,indoor_flag
    ,azimuth
    ,vendor
    ,bandwidth
    ,mme_usr_cnt
    ,NVL(flux_ul,0)                              AS flux_ul
    ,NVL(flux_dl,0)                              AS flux_dl
    ,NVL(flux,0)                                 AS flux
    ,rrc_userconnmean
    ,rrc_userconnmax
    ,is_highload
    ,puschprbtotmeanul
    ,prb_ul_avail
    ,puschprbtotmeanul_rate
    ,puschprbtotmeandl
    ,prb_dl_avail
    ,puschprbtotmeandl_rate
    ,totalrsrp
    ,rsrpcount
    ,avgrsrp
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,NVL(is_bad_cover,0)                         AS is_bad_cover
    ,cqi_good_count
    ,cqi_total_count
    ,NVL(cqi_good_rate,1)                        AS cqi_good_rate
    ,rrc_attconnestab
    ,rrc_succconnestab
    ,NVL(rrc_succconnestab_rate,1)               AS rrc_succconnestab_rate
    ,s1sig_attconnestab
    ,s1sig_succconnestab
    ,NVL(s1sig_succconnestab_rate,1)             AS s1sig_succconnestab_rate
    ,erab_attestab
    ,erab_succestab
    ,NVL(erab_succestab_rate,1)                  AS erab_succestab_rate
    ,NVL(rrc_succconnestab_rate,1) * NVL(s1sig_succconnestab_rate,1) * NVL(erab_succestab_rate,1)    AS access_success_rate
    ,erab_attestab_qci1
    ,erab_succestab_qci1
    ,NVL(erab_succestab_rate_qci1,1)             AS erab_succestab_rate_qci1
    ,NVL(rrc_succconnestab_rate,1) * NVL(s1sig_succconnestab_rate,1) * NVL(erab_succestab_rate_qci1,1)    AS access_success_rate_qci1
    ,uecntx_abnormrel
    ,uecntx_normrel
    ,NVL(uecntx_drop_rate,0)                     AS uecntx_drop_rate
    ,erab_abnormrel_qci1
    ,erab_normrel_qci1
    ,NVL(erab_drop_qci1_rate,0)                  AS erab_drop_qci1_rate
    ,pdcp_sduoctdl
    ,pdcp_sdutailflowdl
    ,pdcp_thrptimedl
    ,pdcp_tailtimedl
    ,uexp_meanspeeddl
    ,cell_unserv_time
    ,cell_unservnum_rate
    ,cell_servtime_rate
    ,pdcp_sdulosspktul_qci1
    ,pdcp_sdupktul_qci1
    ,NVL(pdcp_sdulosspktul_qci1_rate,0)          AS pdcp_sdulosspktul_qci1_rate
    ,pdcp_sdulosspktdl_qci1
    ,pdcp_sdupktdl_qci1
    ,NVL(pdcp_sdulosspktdl_qci1_rate,0)          AS pdcp_sdulosspktdl_qci1_rate
    ,NULL                                        AS is_alarm
    ,scan_pay_suc_cnt
    ,scan_pay_req_cnt
    ,scan_pay_suc_rate
    ,scan_pay_tcpsetupackdelay
    ,CASE WHEN scan_pay_suc_rate < 0.8 OR scan_pay_tcpsetupackdelay > 800 THEN 1 ELSE 0 END  AS is_bad_scan_pay
    ,CASE WHEN NVL(is_bad_cover,0) + NVL(is_highload,0) + NVL(CASE WHEN scan_pay_suc_rate < 0.8 OR scan_pay_tcpsetupackdelay > 800 THEN 1 ELSE 0 END,0) + NVL(if(t3.cellkey is not null and flux=0, 1, 0 ),0) + (0) > 0 THEN 1 ELSE 0 END AS is_bad
    ,web_duration
    ,video_duration
    ,im_duration
    ,game_duration
    ,NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0) AS duration_total
    ,httpwebrspcount
    ,httpwebreqcount
    ,httpwebrsprate
    ,httpwebdspdelay
    ,httpwebscreendelay
    ,videoplaysuccesscount
    ,videoplayrequestcount
    ,videothroughput
    ,videoplaytime_without_halt_sum
    ,videoplayhaltcount
    ,kqi_videoplayhaltcountpermin
    ,times_excellentdownlink
    ,times_inferiordownlink
    ,times_welldownlink
    ,times_excellentstallfrequ
    ,times_inferiorstallfrequ
    ,times_wellstallfrequ
    ,messagesucccount
    ,messagereqcount
    ,messagesucc_rate
    ,game_cnt
    ,gameinteractdelay
    ,dnsqueryrspcount
    ,dnsqueryreqcount
    ,dnsquerysuc_rate
    ,ROUND(0.1 * NVL(dnsquerysuc_rate,1) + 0.9 * (NVL(web_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(httpwebrsprate,1) + NVL(video_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(video_good_rate,1) + NVL(game_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(game_good_rate,1) + NVL(im_duration,0) / (NVL(web_duration,0) + NVL(video_duration,0) + NVL(im_duration,0) + NVL(game_duration,0)) * NVL(im_good_rate,1)),5) AS kqi_good_rate
    ,web_good_rate
    ,video_good_rate
    ,im_good_rate
    ,game_good_rate
    ,section_type
    ,is_indoor_section_station
    ,if(t3.cellkey is not null, 1, 0 ) is_pm_flag
    ,if(t3.cellkey is not null and flux=0, 1, 0 ) is_zero_flux
    ,wechat_message_suc_cnt
    ,wechat_message_req_cnt
    ,wechat_message_suc_rate
FROM
(
    SELECT
        provincecode
        ,province_name
        ,citycode
        ,city_name
        ,subway_line_id
        ,subway_line
        ,type
        ,section_station_id
        ,name
        ,net_type
        ,enbid
        ,REGEXP_REPLACE(enbname,',','_') AS enbname
        ,cellid
        ,REGEXP_REPLACE(cellname,',','_') AS cellname
        ,cellkey
        ,master_operators
        ,cell_lon
        ,cell_lat
        ,freq
        ,pci
        ,indoor_flag
        ,azimuth
        ,vendor
        ,bandwidth
        ,section_type
        ,is_indoor_section_station
    FROM
        dm_subway_section_station_sector_lte_rel_use_d  -- 切换数据源 20250626
    WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
        AND p_date = '$dm_subway_section_station_sector_lte_rel_use_d.p_date$'
        AND valid_flag = 1  -- 添加过滤条件 20250626
        and citycode > 0  -- 添加过滤条件 20250626
) t1
LEFT JOIN
(
    SELECT
        subway_line_id
       ,type
       ,section_station_id
       ,cellkey
       ,count(distinct imsi)  AS mme_usr_cnt
    FROM
        dm_subway_usrcel_list_h
    WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_lte_index_h.p_date$'
        AND p_hour = $dm_subway_cel_lte_index_h.p_hour$
        AND net_type = '4G'
    GROUP BY
        subway_line_id
       ,type
       ,section_station_id
       ,cellkey
) t2
ON t1.subway_line_id = t2.subway_line_id
    AND t1.type = t2.type
    AND t1.section_station_id = t2.section_station_id
    AND t1.cellkey = t2.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,SUM(pdcp_sduoctul) / 1024                               AS flux_ul
       ,SUM(pdcp_sduoctdl) / 1024                               AS flux_dl
       ,SUM(NVL(pdcp_sduoctul,0) + NVL(pdcp_sduoctdl,0)) / 1024 AS flux
       ,AVG(rrc_userconnmean)                                   AS rrc_userconnmean
       ,MAX(rrc_userconnmax)                                    AS rrc_userconnmax
       ,MAX(is_highload)                                        AS is_highload
       ,SUM(puschprbtotmeanul)                                  AS puschprbtotmeanul
       ,SUM(prb_ul_avail)                                       AS prb_ul_avail
       ,SUM(puschprbtotmeanul) / SUM(prb_ul_avail)              AS puschprbtotmeanul_rate
       ,SUM(puschprbtotmeandl)                                  AS puschprbtotmeandl
       ,SUM(prb_dl_avail)                                       AS prb_dl_avail
       ,SUM(puschprbtotmeandl) / SUM(prb_dl_avail)              AS puschprbtotmeandl_rate
    FROM
        aggr_lte_load_cell_h
    WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_lte_index_h.p_date$'
        AND p_hour = $dm_subway_cel_lte_index_h.p_hour$
    GROUP BY cellkey
) t3
ON t1.cellkey = t3.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,case when data_source = 1 then '联通' else '电信' end AS plmn
       ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0) + NVL(rsrp_5div_level8mrcount,0))  AS rsrpgoodcount_110
       ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0))   AS rsrpgoodcount_105
       ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0) + NVL(rsrp_5div_level8mrcount,0)) / SUM(rsrpcount) AS rsrpgoodcount_rate_110
       ,SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0)) / SUM(rsrpcount)  AS rsrpgoodcount_rate_105
       ,CASE WHEN SUM(NVL(rsrp_5div_level1mrcount,0) + NVL(rsrp_5div_level2mrcount,0) + NVL(rsrp_5div_level3mrcount,0) + NVL(rsrp_5div_level4mrcount,0) + NVL(rsrp_5div_level5mrcount,0) + NVL(rsrp_5div_level6mrcount,0) + NVL(rsrp_5div_level7mrcount,0)) / SUM(rsrpcount) < 0.95 THEN 1 ELSE 0 END AS is_bad_cover
       ,sum(totalrsrp)  AS totalrsrp
       ,sum(rsrpcount)  AS rsrpcount
       ,sum(totalrsrp)/sum(rsrpcount)   AS avgrsrp
    FROM
        zxvmax.aggr_lte_coverage_cel_h
    WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_lte_index_h.p_date$'
        AND p_hour = $dm_subway_cel_lte_index_h.p_hour$
        AND plmn = '46011'
    GROUP BY cellkey
    ,case when data_source = 1 then '联通' else '电信' end

) t4
ON t1.cellkey = t4.cellkey
    AND t1.master_operators = t4.plmn
LEFT JOIN
(
    SELECT
        CONCAT(related_enb_id,'_',cel_id)   AS cellkey
       ,SUM(NVL(cqi7,0) + NVL(cqi8,0) + NVL(cqi9,0) + NVL(cqi10,0) + NVL(cqi11,0) + NVL(cqi12,0) + NVL(cqi13,0) + NVL(cqi14,0) + NVL(cqi15,0)) AS cqi_good_count
       ,SUM(cqi)    AS cqi_total_count
       ,SUM(NVL(cqi7,0) + NVL(cqi8,0) + NVL(cqi9,0) + NVL(cqi10,0) + NVL(cqi11,0) + NVL(cqi12,0) + NVL(cqi13,0) + NVL(cqi14,0) + NVL(cqi15,0)) / SUM(cqi) AS cqi_good_rate
       ,SUM(CASE WHEN NVL(rrc_attconnestab_ue,0) + NVL(rrc_attconnestab_net,0) < NVL(rrc_succconnestab_ue,0) + NVL(rrc_succconnestab_net,0) THEN NVL(rrc_succconnestab_ue,0) + NVL(rrc_succconnestab_net,0) ELSE NVL(rrc_attconnestab_ue,0) + NVL(rrc_attconnestab_net,0) END)  AS rrc_attconnestab
       ,SUM(NVL(rrc_succconnestab_ue,0) + NVL(rrc_succconnestab_net,0)) AS rrc_succconnestab
       ,SUM(NVL(rrc_succconnestab_ue,0) + NVL(rrc_succconnestab_net,0)) / SUM(CASE WHEN NVL(rrc_attconnestab_ue,0) + NVL(rrc_attconnestab_net,0) < NVL(rrc_succconnestab_ue,0) + NVL(rrc_succconnestab_net,0) THEN NVL(rrc_succconnestab_ue,0) + NVL(rrc_succconnestab_net,0) ELSE NVL(rrc_attconnestab_ue,0) + NVL(rrc_attconnestab_net,0) END)  AS rrc_succconnestab_rate
       ,SUM(CASE WHEN s1sig_attconnestab < s1sig_succconnestab THEN s1sig_succconnestab ELSE s1sig_attconnestab END)    AS s1sig_attconnestab
       ,SUM(s1sig_succconnestab)    AS s1sig_succconnestab
       ,SUM(s1sig_succconnestab)/SUM(CASE WHEN s1sig_attconnestab < s1sig_succconnestab THEN s1sig_succconnestab ELSE s1sig_attconnestab END)    AS s1sig_succconnestab_rate
       ,SUM(CASE WHEN NVL(erab_initattestab,0) + NVL(erab_addattestab,0) < NVL(erab_initsuccestab,0) + NVL(erab_addsuccestab,0) THEN NVL(erab_initsuccestab,0) + NVL(erab_addsuccestab,0) ELSE NVL(erab_initattestab,0) + NVL(erab_addattestab,0) END)  AS erab_attestab
       ,SUM(NVL(erab_initsuccestab,0) + NVL(erab_addsuccestab,0))   AS erab_succestab
       ,SUM(NVL(erab_initsuccestab,0) + NVL(erab_addsuccestab,0)) / SUM(CASE WHEN NVL(erab_initattestab,0) + NVL(erab_addattestab,0) < NVL(erab_initsuccestab,0) + NVL(erab_addsuccestab,0) THEN NVL(erab_initsuccestab,0) + NVL(erab_addsuccestab,0) ELSE NVL(erab_initattestab,0) + NVL(erab_addattestab,0) END) AS erab_succestab_rate
       ,SUM(CASE WHEN NVL(erab_initattestab_qci1,0) + NVL(erab_addattestab_qci1,0) < NVL(erab_initsuccestab_qci1,0) + NVL(erab_addsuccestab_qci1,0) THEN NVL(erab_initsuccestab_qci1,0) + NVL(erab_addsuccestab_qci1,0) ELSE NVL(erab_initattestab_qci1,0) + NVL(erab_addattestab_qci1,0) END) AS erab_attestab_qci1
       ,SUM(NVL(erab_initsuccestab_qci1,0) + NVL(erab_addsuccestab_qci1,0)) AS erab_succestab_qci1
       ,SUM(NVL(erab_initsuccestab_qci1,0) + NVL(erab_addsuccestab_qci1,0)) / SUM(CASE WHEN NVL(erab_initattestab_qci1,0) + NVL(erab_addattestab_qci1,0) < NVL(erab_initsuccestab_qci1,0) + NVL(erab_addsuccestab_qci1,0) THEN NVL(erab_initsuccestab_qci1,0) + NVL(erab_addsuccestab_qci1,0) ELSE NVL(erab_initattestab_qci1,0) + NVL(erab_addattestab_qci1,0) END) AS erab_succestab_rate_qci1
       ,SUM(uecntx_abnormrel) AS uecntx_abnormrel
       ,SUM(uecntx_normrel) AS uecntx_normrel
       ,SUM(uecntx_abnormrel) / SUM(NVL(uecntx_abnormrel,0) + NVL(uecntx_normrel,0))   AS uecntx_drop_rate
       ,SUM(erab_abnormrel_qci1)    AS erab_abnormrel_qci1
       ,SUM(erab_normrel_qci1)      AS erab_normrel_qci1
       ,SUM(erab_abnormrel_qci1) / SUM(NVL(erab_abnormrel_qci1,0) + NVL(erab_normrel_qci1,0))  AS erab_drop_qci1_rate
       ,SUM(pdcp_sduoctdl)  AS pdcp_sduoctdl
       ,SUM(pdcp_sdutailflowdl) AS pdcp_sdutailflowdl
       ,SUM(pdcp_thrptimedl)    AS pdcp_thrptimedl
       ,SUM(pdcp_tailtimedl)    AS pdcp_tailtimedl
       ,SUM((pdcp_sduoctdl-pdcp_sdutailflowdl)*8)/SUM(( pdcp_thrptimedl-pdcp_tailtimedl)/1000)  AS uexp_meanspeeddl
       ,SUM(cell_unserv_time)   AS cell_unserv_time
       ,AVG(cell_unservnum_rate)    AS cell_unservnum_rate
       ,AVG(cell_servtime_rate)     AS cell_servtime_rate
       ,SUM(pdcp_sdulosspktul_qci1) AS pdcp_sdulosspktul_qci1
       ,SUM(pdcp_sdupktul_qci1)     AS pdcp_sdupktul_qci1
       ,SUM(pdcp_sdulosspktul_qci1)/SUM(pdcp_sdupktul_qci1)  AS pdcp_sdulosspktul_qci1_rate
       ,SUM(pdcp_sdulosspktdl_qci1) AS pdcp_sdulosspktdl_qci1
       ,SUM(pdcp_sdupktdl_qci1)     AS pdcp_sdupktdl_qci1
       ,SUM(pdcp_sdulosspktdl_qci1)/SUM(pdcp_sdupktdl_qci1)  AS pdcp_sdulosspktdl_qci1_rate
    FROM
        itg_pm_lte_cel_h_cel_d
    WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_lte_index_h.p_date$'
        AND p_hour = $dm_subway_cel_lte_index_h.p_hour$
    GROUP BY
        related_enb_id
       ,cel_id
) t5
ON t1.cellkey = t5.cellkey
-- LEFT JOIN
-- (
--     SELECT
--         cellkey
--     FROM
--         lte_cell_alarm_d
--     WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
--         AND p_date = '$dm_subway_cel_lte_index_h.p_date$'
--         AND eventtime <= CONCAT(REGEXP_REPLACE('$dm_subway_cel_lte_index_h.p_date$','-','/'),' ',LPAD($dm_subway_cel_lte_index_h.p_hour$ + 1,2,'0'))
--         AND (canceltime IS NULL OR canceltime >= CONCAT(REGEXP_REPLACE('$dm_subway_cel_lte_index_h.p_date$','-','/'),' ',LPAD($dm_subway_cel_lte_index_h.p_hour$,2,'0')))
--         AND eventtime < canceltime
--     GROUP BY cellkey
-- ) t6
-- ON t1.cellkey = t6.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)  AS cellkey
       ,SUM(CASE WHEN servicetype=88888888 THEN httpwebrspcount ELSE 0 END) AS scan_pay_suc_cnt
       ,SUM(CASE WHEN servicetype=88888888 THEN httpwebreqcount ELSE 0 END) AS scan_pay_req_cnt
       ,SUM(CASE WHEN servicetype=88888888 THEN httpwebrspcount ELSE 0 END) / SUM(CASE WHEN servicetype=88888888 THEN httpwebreqcount ELSE 0 END)   AS scan_pay_suc_rate
       ,SUM(CASE WHEN servicetype=88888888 THEN tcpsetupackdelay_sum ELSE 0 END) / SUM(CASE WHEN servicetype=88888888 THEN httpwebreqcount ELSE 0 END)  AS scan_pay_tcpsetupackdelay
       ,SUM(duration_sum)   AS im_duration
       ,SUM(times_excellentsentrate)    AS messagesucccount
       ,SUM(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate,0) + NVL(times_wellsentrate,0)) AS messagereqcount
       ,SUM(times_excellentsentrate) / SUM(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate,0) + NVL(times_wellsentrate,0))  AS messagesucc_rate
       ,SUM(times_excellentsentrate) / SUM(NVL(times_excellentsentrate,0) + NVL(times_inferiorsentrate,0) + NVL(times_wellsentrate,0))  AS im_good_rate
        ,sum(case when servicetype='01000202' then httpwebrspcount else 0 end) wechat_message_suc_cnt
        ,sum(case when servicetype='01000202' then httpwebreqcount else 0 end) wechat_message_req_cnt
        ,sum(case when servicetype='01000202' then httpwebrspcount else 0 end)/sum(case when servicetype='01000202' then httpwebreqcount else 0 end) wechat_message_suc_rate

    FROM
        aggr_4g_im_usrappcel_e2e_h
    WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
        AND reportdate = '$dm_subway_cel_lte_index_h.p_date$'
        AND reporthour = $dm_subway_cel_lte_index_h.p_hour$
    GROUP BY
        nodebid
       ,cellid
) t7
ON t1.cellkey = t7.cellkey
LEFT JOIN
(
    SELECT
        CONCAT(nodebid,'_',cellid)                          AS cellkey
       ,SUM(duration_sum)                                   AS web_duration
       ,SUM(httpwebrspcount)                                AS httpwebrspcount
       ,SUM(httpwebreqcount)                                AS httpwebreqcount
       ,SUM(httpwebrspcount) / SUM(httpwebreqcount)         AS httpwebrsprate
       ,SUM(httpwebdspdelay_sum) / SUM(httpwebrspcount)     AS httpwebdspdelay
       ,SUM(httpwebscreendelay_sum) / SUM(httpwebrspcount)  AS httpwebscreendelay
       ,SUM(httpwebrspcount) / SUM(httpwebreqcount)         AS web_good_rate
    FROM
        aggr_4g_web_usrappcel_e2e_h
    WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
        AND reportdate = '$dm_subway_cel_lte_index_h.p_date$'
        AND reporthour = $dm_subway_cel_lte_index_h.p_hour$
    GROUP BY
        nodebid
       ,cellid
) t8
ON t1.cellkey = t8.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,video_duration
       ,videoplaysuccesscount
       ,videoplayrequestcount
       ,videothroughput
       ,videoplaytime_without_halt_sum
       ,videoplayhaltcount
       ,kqi_videoplayhaltcountpermin
       ,times_excellentdownlink
       ,times_inferiordownlink
       ,times_welldownlink
       ,times_excellentstallfrequ
       ,times_inferiorstallfrequ
       ,times_wellstallfrequ
       ,CASE
            WHEN NVL(video_good_rate_1,0) <= NVL(video_good_rate_2,0) THEN NVL(video_good_rate_1,0)
            ELSE NVL(video_good_rate_2,0)
        END     AS video_good_rate
    FROM
    (
        SELECT
            CONCAT(nodebid,'_',cellid)                          AS cellkey
           ,SUM(duration_sum)                                   AS video_duration
           ,SUM(videoplaysuccesscount)                          AS videoplaysuccesscount
           ,SUM(videoplayrequestcount)                          AS videoplayrequestcount
           ,SUM(videothroughput_avg*videoplaysuccesscount)/SUM(videoplaysuccesscount) / 1024   AS videothroughput
           ,SUM(videoplaytime_without_halt_sum)                 AS videoplaytime_without_halt_sum
           ,SUM(videoplayhaltcount)                             AS videoplayhaltcount
           ,CASE WHEN SUM(videoplaytime_without_halt_sum) !=0 THEN SUM(videoplayhaltcount)*60000/SUM(videoplaytime_without_halt_sum) ELSE 0 END AS kqi_videoplayhaltcountpermin
           ,SUM(times_excellentdownlink)                        AS times_excellentdownlink
           ,SUM(times_excellentdownlink)                        AS times_inferiordownlink
           ,SUM(times_welldownlink)                             AS times_welldownlink
           ,SUM(times_excellentstallfrequ)                      AS times_excellentstallfrequ
           ,SUM(times_inferiorstallfrequ)                       AS times_inferiorstallfrequ
           ,SUM(times_wellstallfrequ)                           AS times_wellstallfrequ
           ,SUM(NVL(times_excellentdownlink,0) + NVL(times_welldownlink,0)) / SUM(NVL(times_excellentdownlink,0) + NVL(times_welldownlink,0) + NVL(times_inferiordownlink,0))   AS video_good_rate_1
           ,SUM(NVL(times_excellentstallfrequ,0) + NVL(times_wellstallfrequ,0)) / SUM(NVL(times_excellentstallfrequ,0) + NVL(times_wellstallfrequ,0) + NVL(times_inferiorstallfrequ,0)) AS video_good_rate_2
        FROM
            aggr_4g_video_usrappcel_e2e_h
        WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
            AND reportdate = '$dm_subway_cel_lte_index_h.p_date$'
            AND reporthour = $dm_subway_cel_lte_index_h.p_hour$
        GROUP BY
            nodebid
           ,cellid
    ) t
) t9
ON t1.cellkey = t9.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,game_duration
       ,game_cnt
       ,gameinteractdelay
       ,CASE
            WHEN gameinteractdelay <= 150                       THEN 1
            WHEN 100 - (gameinteractdelay - 150) * 0.75 <= 0    THEN 0
            ELSE (100 - (gameinteractdelay - 150) * 0.75) / 100
        END AS game_good_rate
    FROM
    (
        SELECT
            CONCAT(nodebid,'_',cellid)  AS cellkey
           ,SUM(duration_sum)           AS game_duration
           ,SUM(httpwebreqcount)        AS game_cnt
           ,CASE WHEN SUM(httpwebreqcount)  !=0 THEN SUM(gameinteractdelay_sum)/SUM(httpwebreqcount) ELSE 0 END AS gameinteractdelay
        FROM
            aggr_4g_game_usrappcel_e2e_h
        WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
            AND reportdate = '$dm_subway_cel_lte_index_h.p_date$'
            AND reporthour = $dm_subway_cel_lte_index_h.p_hour$
        GROUP BY
            nodebid
           ,cellid
    ) t
) t10
ON t1.cellkey = t10.cellkey
LEFT JOIN
(
    SELECT
        cellkey
       ,SUM(dnsqueryrspcount) AS dnsqueryrspcount
       ,SUM(dnsqueryreqcount) AS dnsqueryreqcount
       ,SUM(dnsqueryrspcount)/SUM(dnsqueryreqcount) AS dnsquerysuc_rate
    FROM
        aggr_lte_dns_noc_cel_h
    WHERE p_provincecode = $dm_subway_cel_lte_index_h.p_provincecode$
        AND p_date = '$dm_subway_cel_lte_index_h.p_date$'
        AND p_hour = $dm_subway_cel_lte_index_h.p_hour$
    GROUP BY cellkey
) t11
ON t1.cellkey = t11.cellkey
distribute by rand()
;
