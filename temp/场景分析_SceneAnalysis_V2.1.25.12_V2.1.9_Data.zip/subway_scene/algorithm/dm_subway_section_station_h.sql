-- 20250626updateby : goupengcheng 10207
-- algorithm : 更换地铁小区输入表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;
set spark.sql.shuffle.partitions=1;

INSERT OVERWRITE TABLE dm_subway_section_station_h
PARTITION (
    p_provincecode = $dm_subway_section_station_h.p_provincecode$
    ,p_date = '$dm_subway_section_station_h.p_date$'
    ,p_hour = $dm_subway_section_station_h.p_hour$
)
SELECT
    '$dm_subway_section_station_h.p_date$'          AS day
    ,$dm_subway_section_station_h.p_hour$            AS hour
    ,$dm_subway_section_station_h.p_provincecode$    AS provincecode
    ,province_name
    ,citycode
    ,city_name
    ,t1.subway_line_id       AS subway_line_id
    ,subway_line
    ,t1.type                 AS type
    ,t1.section_station_id   AS section_station_id
    ,name
    ,section_distance
    ,usr_cnt_4g
    ,usr_cnt_5g
    ,usr_cnt
    ,cel_ctcc_cnt_4g
    ,cel_cucc_cnt_4g
    ,cel_cnt_4g
    ,cel_ctcc_cnt_5g
    ,cel_cucc_cnt_5g
    ,cel_cnt_5g
    ,NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0)       AS cel_cnt
    ,bad_cel_cnt_4g
    ,bad_cel_cnt_5g
    ,bad_cel_cnt
    ,bad_cel_cnt_4g / cel_cnt_4g                 AS bad_cel_rate_4g
    ,bad_cel_cnt_5g / cel_cnt_5g                 AS bad_cel_rate_5g
    ,bad_cel_cnt / (NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0))   AS bad_cel_rate
    ,flux_ul_4g
    ,flux_dl_4g
    ,flux_4g
    ,flux_ul_5g
    ,flux_dl_5g
    ,flux_5g
    ,flux_rate_5g
    ,rrc_userconnmax_4g
    ,rrc_userconnmax_5g
    ,highload_cnt_4g
    ,highload_cnt_5g
    ,highload_cnt
    ,highload_cnt / (NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0))  AS highload_rate
    ,prb_useddl_4g
    ,prb_availdl_4g
    ,prb_useddl_rate_4g
    ,prb_useddl_5g
    ,prb_availdl_5g
    ,prb_useddl_rate_5g
    ,totalrsrp_4g
    ,rsrpcount_4g
    ,avgrsrp_4g
    ,rsrpgoodcount_110_4g
    ,rsrpgoodcount_105_4g
    ,rsrpgoodcount_rate_110_4g
    ,rsrpgoodcount_rate_105_4g
    ,totalrsrp_5g
    ,rsrpcount_5g
    ,avgrsrp_5g
    ,rsrpgoodcount_110_5g
    ,rsrpgoodcount_105_5g
    ,rsrpgoodcount_rate_110_5g
    ,rsrpgoodcount_rate_105_5g
    ,totalrsrp
    ,rsrpcount
    ,avgrsrp
    ,null rsrpgoodcount_110
    ,null rsrpgoodcount_105
    ,0.5*nvl(rsrpgoodcount_rate_110_4g,1) + 0.5*nvl(rsrpgoodcount_rate_110_5g,1) rsrpgoodcount_rate_110
    ,0.5*nvl(rsrpgoodcount_rate_105_4g,1) + 0.5*nvl(rsrpgoodcount_rate_105_5g,1) rsrpgoodcount_rate_105
    ,rsrpcount_5g_rate
    ,weak_cover_cel_cnt_4g
    ,weak_cover_cel_cnt_5g
    ,weak_cover_cel_cnt
    ,alarm_cnt_4g
    ,alarm_cnt_5g
    ,alarm_cnt
    ,alarm_cnt / (NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0)) AS alarm_rate
    ,scan_pay_suc_cnt_4g
    ,scan_pay_req_cnt_4g
    ,scan_pay_suc_rate_4g
    ,scan_pay_tcpsetupackdelay_4g
    ,scan_pay_suc_cnt_5g
    ,scan_pay_req_cnt_5g
    ,scan_pay_suc_rate_5g
    ,scan_pay_tcpsetupackdelay_5g
    ,scan_pay_suc_cnt
    ,scan_pay_req_cnt
    ,scan_pay_suc_rate
    ,scan_pay_tcpsetupackdelay
    ,CASE WHEN scan_pay_suc_rate < 0.8 OR scan_pay_tcpsetupackdelay > 800 THEN 1 ELSE 0 END  AS is_bad_scan_pay
    ,is_bad_cover
    ,CASE WHEN highload_cnt / (NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0)) > 0.2 THEN 1 ELSE 0 END AS is_bad_highload
    ,CASE WHEN alarm_cnt / (NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0)) > 0.2 THEN 1 ELSE 0 END AS is_bad_alarm
    ,CASE WHEN is_bad_cover = 1 OR (scan_pay_suc_rate < 0.8 OR scan_pay_tcpsetupackdelay > 800) OR highload_cnt / (NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0)) > 0.2 OR alarm_cnt / (NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0)) > 0.2 THEN 1 ELSE 0 END AS is_bad
    ,cqi_good_count_4g
    ,cqi_total_count_4g
    ,cqi_good_rate_4g
    ,cqi_good_count_5g
    ,cqi_total_count_5g
    ,cqi_good_rate_5g
    ,rrc_attconnestab_4g
    ,rrc_succconnestab_4g
    ,rrc_succconnestab_rate_4g
    ,s1sig_attconnestab_4g
    ,s1sig_succconnestab_4g
    ,s1sig_succconnestab_rate_4g
    ,erab_attestab_4g
    ,erab_succestab_4g
    ,erab_succestab_rate_4g
    ,access_success_rate_4g
    ,erab_attestab_qci1
    ,erab_succestab_qci1
    ,erab_succestab_rate_qci1
    ,access_success_rate_qci1
    ,erab_abnormrel_qci1
    ,erab_normrel_qci1
    ,erab_drop_qci1_rate
    ,rrc_connreq_5g
    ,rrc_connsucc_5g
    ,rrc_connsucc_rate_5g
    ,ng_connatt_5g
    ,ng_connsucc_5g
    ,ng_connsucc_rate_5g
    ,qos_initialestabreq_5g
    ,qos_initialestabsucc_5g
    ,qos_initialestabsucc_rate_5g
    ,access_success_rate_5g
    ,uecntx_abnormrel_4g
    ,uecntx_normrel_4g
    ,uecntx_drop_rate_4g
    ,ue_contextrelease_5g
    ,ue_normalcontextrelease_5g
    ,uecntx_drop_rate_5g
    ,pdcp_sduoctdl_4g
    ,pdcp_sdutailflowdl_4g
    ,pdcp_thrptimedl_4g
    ,pdcp_tailtimedl_4g
    ,uexp_meanspeeddl_4g
    ,rlc_txbytesdl_5g
    ,rlc_lasttxbytesdl_5g
    ,rlc_txtimedl_exceptlastslot_5g
    ,uexp_meanspeeddl_5g
    ,pdcp_sdulosspktul_qci1
    ,pdcp_sdupktul_qci1
    ,pdcp_sdulosspktul_qci1_rate
    ,pdcp_sdulosspktdl_qci1
    ,pdcp_sdupktdl_qci1
    ,pdcp_sdulosspktdl_qci1_rate
    ,vonr_ho_atttovolte_5g
    ,vonr_ho_succtovolte_5g
    ,vonr_ho_succtovolte_rate_5g
    ,vonr_rtp_rxpktul_5g
    ,vonr_rtp_losspktul_5g
    ,vonr_rtp_losspktul_rate_5g
    ,vonr_rtp_rxpktdl_5g
    ,vonr_rtp_losspktdl_5g
    ,vonr_rtp_losspktdl_rate_5g
    ,vonr_connreq_5g
    ,vonr_connsucc_5g
    ,vonr_connsucc_rate_5g
    ,vonr_releasesum_5g
    ,vonr_normalrelease_5g
    ,vonr_abnorrelease_rate_5g
    ,ho_succintragnb_5g
    ,ho_succbyxn_5g
    ,ho_succbyng_5g
    ,ho_attintragnb_5g
    ,ho_attbyxn_5g
    ,ho_attbyng_5g
    ,ho_succ_rate_5g
    ,epsfb_voice_suc
    ,epsfb_voice_req
    ,epsfb_voice_suc_rate
    ,intra_5gstoepsbydata
    ,intra_5gstoepsbydata_rate
    ,web_duration_4g
    ,video_duration_4g
    ,im_duration_4g
    ,game_duration_4g
    ,duration_total_4g
    ,httpwebrspcount_4g
    ,httpwebreqcount_4g
    ,httpwebrsprate_4g
    ,httpwebdspdelay_4g
    ,httpwebscreendelay_4g
    ,videoplaysuccesscount_4g
    ,videoplayrequestcount_4g
    ,videothroughput_4g
    ,videoplaytime_without_halt_sum_4g
    ,videoplayhaltcount_4g
    ,kqi_videoplayhaltcountpermin_4g
    ,times_excellentdownlink_4g
    ,times_inferiordownlink_4g
    ,times_welldownlink_4g
    ,times_excellentstallfrequ_4g
    ,times_inferiorstallfrequ_4g
    ,times_wellstallfrequ_4g
    ,messagesucccount_4g
    ,messagereqcount_4g
    ,messagesucc_rate_4g
    ,game_cnt_4g
    ,gameinteractdelay_4g
    ,dnsqueryrspcount_4g
    ,dnsqueryreqcount_4g
    ,dnsquerysuc_rate_4g
    ,ROUND(0.1 * NVL(dnsquerysuc_rate_4g,1) + 0.9 * (NVL(web_duration_4g,0) / duration_total_4g * NVL(httpwebrsprate_4g,1) + NVL(video_duration_4g,0) / duration_total_4g * NVL(video_good_rate_4g,1) + NVL(game_duration_4g,0) / duration_total_4g * NVL(game_good_rate_4g,1) + NVL(im_duration_4g,0) / duration_total_4g * NVL(im_good_rate_4g,1)),5) AS kqi_good_rate_4g
    ,web_good_rate_4g
    ,video_good_rate_4g
    ,im_good_rate_4g
    ,game_good_rate_4g
    ,web_duration_5g
    ,video_duration_5g
    ,im_duration_5g
    ,game_duration_5g
    ,duration_total_5g
    ,httpwebrspcount_5g
    ,httpwebreqcount_5g
    ,httpwebrsprate_5g
    ,httpwebdspdelay_5g
    ,httpwebscreendelay_5g
    ,videoplaysuccesscount_5g
    ,videoplayrequestcount_5g
    ,videothroughput_5g
    ,videoplaytime_without_halt_sum_5g
    ,videoplayhaltcount_5g
    ,kqi_videoplayhaltcountpermin_5g
    ,times_excellentdownlink_5g
    ,times_inferiordownlink_5g
    ,times_welldownlink_5g
    ,times_excellentstallfrequ_5g
    ,times_inferiorstallfrequ_5g
    ,times_wellstallfrequ_5g
    ,messagesucccount_5g
    ,messagereqcount_5g
    ,messagesucc_rate_5g
    ,game_cnt_5g
    ,gameinteractdelay_5g
    ,dnsqueryrspcount_5g
    ,dnsqueryreqcount_5g
    ,dnsquerysuc_rate_5g
    ,ROUND(0.1 * NVL(dnsquerysuc_rate_5g,1) + 0.9 * (NVL(web_duration_5g,0) / duration_total_5g * NVL(httpwebrsprate_5g,1) + NVL(video_duration_5g,0) / duration_total_5g * NVL(video_good_rate_5g,1) + NVL(game_duration_5g,0) / duration_total_5g * NVL(game_good_rate_5g,1) + NVL(im_duration_5g,0) / duration_total_5g * NVL(im_good_rate_5g,1)),5) AS kqi_good_rate_5g
    ,web_good_rate_5g
    ,video_good_rate_5g
    ,im_good_rate_5g
    ,game_good_rate_5g
    ,t1.section_type    AS section_type
    ,is_indoor_section_station
    ,zero_cell_cnt_4g
    ,zero_cell_cnt_5g
    ,zero_cell_cnt
    ,vonr_rtp_losspkt_rate_5g
    ,wechat_message_suc_cnt_4g
    ,wechat_message_req_cnt_4g
    ,wechat_message_suc_rate_4g
    ,wechat_message_suc_cnt_5g
    ,wechat_message_req_cnt_5g
    ,wechat_message_suc_rate_5g
    ,cell_cnt_35_5g
    ,cell_cnt_rate_35_5g
    ,uexp_meanspeeddl_35_flow
    ,uexp_meanspeeddl_35_duration
    ,uexp_meanspeeddl_35
    ,uexp_meanspeeddl_21_flow
    ,uexp_meanspeeddl_21_duration
    ,uexp_meanspeeddl_21
    ,cover_rate_score_5g
    ,videoplaysucc_rate_score_5g
    ,wechat_message_suc_rate_score_5g
    ,vonr_connsucc_rate_score_5g
    ,vonr_abnorrelease_rate_score_5g
    ,cover_score
    ,vonr_ho_succtovolte_rate_score_5g
    ,vonr_rtp_losspkt_rate_score_5g
    ,if(cell_cnt_rate_35_5g >= 0.6, case when uexp_meanspeeddl_35 >= 150 then 15 when uexp_meanspeeddl_35 <= 100 then 0 when uexp_meanspeeddl_35 <= 150 and uexp_meanspeeddl_35 >= 100 then (uexp_meanspeeddl_35 - 100) * 15/(150 - 100) end, case when uexp_meanspeeddl_21 >= 30 then 15 when uexp_meanspeeddl_21 <= 10 then 0 when uexp_meanspeeddl_21 <= 30 and uexp_meanspeeddl_21 >= 10 then (uexp_meanspeeddl_21 - 10) * 15/(30 - 10) end) uexp_meanspeeddl_score
    ,nvl(vonr_ho_succtovolte_rate_score_5g, 0) + nvl(vonr_rtp_losspkt_rate_score_5g, 0) + nvl(if(cell_cnt_rate_35_5g >= 0.6,case when uexp_meanspeeddl_35 >= 150 then 15 when uexp_meanspeeddl_35 <= 100 then 0 when uexp_meanspeeddl_35 <= 150 and uexp_meanspeeddl_35 >= 100 then (uexp_meanspeeddl_35 - 100) * 15/(150 - 100) end, case when uexp_meanspeeddl_21 >= 30 then 15 when uexp_meanspeeddl_21 <= 10 then 0 when uexp_meanspeeddl_21 <= 30 and uexp_meanspeeddl_21 >= 10 then (uexp_meanspeeddl_21 - 10) * 15/(30 - 10) end), 0) perception_score
    ,null initial_complaint_cnt
    ,null current_complaint_cnt
    ,null complaint_reduce_rate
    ,complaint_score
    ,nvl(cover_score, 0) + (nvl(vonr_ho_succtovolte_rate_score_5g, 0) + nvl(vonr_rtp_losspkt_rate_score_5g, 0) + nvl(if(cell_cnt_rate_35_5g >= 0.6,case when uexp_meanspeeddl_35 >= 150 then 15 when uexp_meanspeeddl_35 <= 100 then 0 when uexp_meanspeeddl_35 <= 150 and uexp_meanspeeddl_35 >= 100 then (uexp_meanspeeddl_35 - 100) * 15/(150 - 100) end, case when uexp_meanspeeddl_21 >= 30 then 15 when uexp_meanspeeddl_21 <= 10 then 0 when uexp_meanspeeddl_21 <= 30 and uexp_meanspeeddl_21 >= 10 then (uexp_meanspeeddl_21 - 10) * 15/(30 - 10) end), 0)) + nvl(complaint_score, 0) total_score
    ,null rsrpgoodcount_ott_ctcc_5g
    ,null rsrpcount_ott_ctcc_5g
    ,null cover_rate_ott_ctcc_5g
    ,null rsrpgoodcount_ott_cucc_5g
    ,null rsrpcount_ott_cucc_5g
    ,null cover_rate_ott_cucc_5g
    ,null rsrpgoodcount_ott_cmcc_5g
    ,null rsrpcount_ott_cmcc_5g
    ,null cover_rate_ott_cmcc_5g
FROM
(
    SELECT
        NVL(t1.province_name,t2.province_name)              AS province_name
        ,NVL(t1.citycode,t2.citycode)                        AS citycode
        ,NVL(t1.city_name,t2.city_name)                      AS city_name
        ,NVL(t1.subway_line_id,t2.subway_line_id)            AS subway_line_id
        ,NVL(t1.subway_line,t2.subway_line)                  AS subway_line
        ,NVL(t1.type,t2.type)                                AS type
        ,NVL(t1.section_station_id,t2.section_station_id)    AS section_station_id
        ,NVL(t1.name,t2.name)                                AS name
        ,bad_cel_cnt_4g
        ,bad_cel_cnt_5g
        ,NVL(bad_cel_cnt_4g,0) + NVL(bad_cel_cnt_5g,0)       AS bad_cel_cnt
        ,flux_ul_4g
        ,flux_dl_4g
        ,flux_4g
        ,flux_ul_5g
        ,flux_dl_5g
        ,flux_5g
        ,flux_5g / (NVL(flux_4g,0) + NVL(flux_5g,0))         AS flux_rate_5g
        ,rrc_userconnmax_4g
        ,rrc_userconnmax_5g
        ,highload_cnt_4g
        ,highload_cnt_5g
        ,NVL(highload_cnt_4g,0) + NVL(highload_cnt_5g,0)     AS highload_cnt
        ,prb_useddl_4g
        ,prb_availdl_4g
        ,prb_useddl_rate_4g
        ,prb_useddl_5g
        ,prb_availdl_5g
        ,prb_useddl_rate_5g
        ,totalrsrp_4g
        ,rsrpcount_4g
        ,avgrsrp_4g
        ,rsrpgoodcount_110_4g
        ,rsrpgoodcount_105_4g
        ,rsrpgoodcount_rate_110_4g
        ,rsrpgoodcount_rate_105_4g
        ,totalrsrp_5g
        ,rsrpcount_5g
        ,avgrsrp_5g
        ,rsrpgoodcount_110_5g
        ,rsrpgoodcount_105_5g
        ,rsrpgoodcount_rate_110_5g
        ,rsrpgoodcount_rate_105_5g
        ,NVL(totalrsrp_4g,0) + NVL(totalrsrp_5g,0)          AS totalrsrp
        ,NVL(rsrpcount_4g,0) + NVL(rsrpcount_5g,0)          AS rsrpcount
        ,(NVL(totalrsrp_4g,0) + NVL(totalrsrp_5g,0)) / (NVL(rsrpcount_4g,0) + NVL(rsrpcount_5g,0))   AS avgrsrp
        ,NVL(rsrpgoodcount_110_4g,0) + NVL(rsrpgoodcount_110_5g,0)   AS rsrpgoodcount_110
        ,NVL(rsrpgoodcount_105_4g,0) + NVL(rsrpgoodcount_105_5g,0)   AS rsrpgoodcount_105
        ,(NVL(rsrpgoodcount_110_4g,0) + NVL(rsrpgoodcount_110_5g,0)) / (NVL(rsrpcount_4g,0) + NVL(rsrpcount_5g,0))   AS rsrpgoodcount_rate_110
        ,(NVL(rsrpgoodcount_105_4g,0) + NVL(rsrpgoodcount_105_5g,0)) / (NVL(rsrpcount_4g,0) + NVL(rsrpcount_5g,0))   AS rsrpgoodcount_rate_105
        ,rsrpcount_5g / (NVL(rsrpcount_4g,0) + NVL(rsrpcount_5g,0))  AS rsrpcount_5g_rate
        ,weak_cover_cel_cnt_4g
        ,weak_cover_cel_cnt_5g
        ,NVL(weak_cover_cel_cnt_4g,0) + NVL(weak_cover_cel_cnt_5g,0) AS weak_cover_cel_cnt
        ,alarm_cnt_4g
        ,alarm_cnt_5g
        ,NVL(alarm_cnt_4g,0) + NVL(alarm_cnt_5g,0)           AS alarm_cnt
        ,scan_pay_suc_cnt_4g
        ,scan_pay_req_cnt_4g
        ,scan_pay_suc_rate_4g
        ,scan_pay_tcpsetupackdelay_4g
        ,scan_pay_suc_cnt_5g
        ,scan_pay_req_cnt_5g
        ,scan_pay_suc_rate_5g
        ,scan_pay_tcpsetupackdelay_5g
        ,NVL(scan_pay_suc_cnt_4g,0) + NVL(scan_pay_suc_cnt_5g,0) AS scan_pay_suc_cnt
        ,NVL(scan_pay_req_cnt_4g,0) + NVL(scan_pay_req_cnt_5g,0) AS scan_pay_req_cnt
        ,(NVL(scan_pay_suc_cnt_4g,0) + NVL(scan_pay_suc_cnt_5g,0)) / (NVL(scan_pay_req_cnt_4g,0) + NVL(scan_pay_req_cnt_5g,0)) AS scan_pay_suc_rate
        ,(NVL(scan_pay_tcpsetupackdelay_4g*scan_pay_req_cnt_4g,0) + NVL(scan_pay_tcpsetupackdelay_5g*scan_pay_req_cnt_5g,0)) / (NVL(scan_pay_req_cnt_4g,0) + NVL(scan_pay_req_cnt_5g,0)) AS scan_pay_tcpsetupackdelay
        ,CASE WHEN (NVL(rsrpgoodcount_105_4g,0) + NVL(rsrpgoodcount_105_5g,0)) / (NVL(rsrpcount_4g,0) + NVL(rsrpcount_5g,0)) < 0.95 THEN 1 ELSE 0 END AS is_bad_cover
        ,cqi_good_count_4g
        ,cqi_total_count_4g
        ,cqi_good_rate_4g
        ,cqi_good_count_5g
        ,cqi_total_count_5g
        ,cqi_good_rate_5g
        ,rrc_attconnestab_4g
        ,rrc_succconnestab_4g
        ,rrc_succconnestab_rate_4g
        ,s1sig_attconnestab_4g
        ,s1sig_succconnestab_4g
        ,s1sig_succconnestab_rate_4g
        ,erab_attestab_4g
        ,erab_succestab_4g
        ,erab_succestab_rate_4g
        ,access_success_rate_4g
        ,erab_attestab_qci1
        ,erab_succestab_qci1
        ,erab_succestab_rate_qci1
        ,access_success_rate_qci1
        ,erab_abnormrel_qci1
        ,erab_normrel_qci1
        ,erab_drop_qci1_rate
        ,rrc_connreq_5g
        ,rrc_connsucc_5g
        ,rrc_connsucc_rate_5g
        ,ng_connatt_5g
        ,ng_connsucc_5g
        ,ng_connsucc_rate_5g
        ,qos_initialestabreq_5g
        ,qos_initialestabsucc_5g
        ,qos_initialestabsucc_rate_5g
        ,access_success_rate_5g
        ,uecntx_abnormrel_4g
        ,uecntx_normrel_4g
        ,uecntx_drop_rate_4g
        ,ue_contextrelease_5g
        ,ue_normalcontextrelease_5g
        ,uecntx_drop_rate_5g
        ,pdcp_sduoctdl_4g
        ,pdcp_sdutailflowdl_4g
        ,pdcp_thrptimedl_4g
        ,pdcp_tailtimedl_4g
        ,uexp_meanspeeddl_4g
        ,rlc_txbytesdl_5g
        ,rlc_lasttxbytesdl_5g
        ,rlc_txtimedl_exceptlastslot_5g
        ,uexp_meanspeeddl_5g
        ,pdcp_sdulosspktul_qci1
        ,pdcp_sdupktul_qci1
        ,pdcp_sdulosspktul_qci1_rate
        ,pdcp_sdulosspktdl_qci1
        ,pdcp_sdupktdl_qci1
        ,pdcp_sdulosspktdl_qci1_rate
        ,vonr_ho_atttovolte_5g
        ,vonr_ho_succtovolte_5g
        ,vonr_ho_succtovolte_rate_5g
        ,vonr_rtp_rxpktul_5g
        ,vonr_rtp_losspktul_5g
        ,vonr_rtp_losspktul_rate_5g
        ,vonr_rtp_rxpktdl_5g
        ,vonr_rtp_losspktdl_5g
        ,vonr_rtp_losspktdl_rate_5g
        ,vonr_connreq_5g
        ,vonr_connsucc_5g
        ,vonr_connsucc_rate_5g
        ,vonr_releasesum_5g
        ,vonr_normalrelease_5g
        ,vonr_abnorrelease_rate_5g
        ,ho_succintragnb_5g
        ,ho_succbyxn_5g
        ,ho_succbyng_5g
        ,ho_attintragnb_5g
        ,ho_attbyxn_5g
        ,ho_attbyng_5g
        ,ho_succ_rate_5g
        ,epsfb_voice_suc
        ,epsfb_voice_req
        ,epsfb_voice_suc_rate
        ,intra_5gstoepsbydata
        ,intra_5gstoepsbydata_rate
        ,web_duration_4g
        ,video_duration_4g
        ,im_duration_4g
        ,game_duration_4g
        ,duration_total_4g
        ,httpwebrspcount_4g
        ,httpwebreqcount_4g
        ,httpwebrsprate_4g
        ,httpwebdspdelay_4g
        ,httpwebscreendelay_4g
        ,videoplaysuccesscount_4g
        ,videoplayrequestcount_4g
        ,videothroughput_4g
        ,videoplaytime_without_halt_sum_4g
        ,videoplayhaltcount_4g
        ,kqi_videoplayhaltcountpermin_4g
        ,times_excellentdownlink_4g
        ,times_inferiordownlink_4g
        ,times_welldownlink_4g
        ,times_excellentstallfrequ_4g
        ,times_inferiorstallfrequ_4g
        ,times_wellstallfrequ_4g
        ,messagesucccount_4g
        ,messagereqcount_4g
        ,messagesucc_rate_4g
        ,game_cnt_4g
        ,gameinteractdelay_4g
        ,dnsqueryrspcount_4g
        ,dnsqueryreqcount_4g
        ,dnsquerysuc_rate_4g
        ,web_good_rate_4g
        ,CASE
            WHEN NVL(video_good_rate_4g_1,0) <= NVL(video_good_rate_4g_2,0) THEN NVL(video_good_rate_4g_1,0)
            ELSE NVL(video_good_rate_4g_2,0)
        END     AS video_good_rate_4g
        ,im_good_rate_4g
        ,CASE
            WHEN gameinteractdelay_4g <= 150                       THEN 1
            WHEN 100 - (gameinteractdelay_4g - 150) * 0.75 <= 0    THEN 0
            ELSE (100 - (gameinteractdelay_4g - 150) * 0.75) / 100
        END AS game_good_rate_4g
       ,web_duration_5g
       ,video_duration_5g
       ,im_duration_5g
       ,game_duration_5g
       ,duration_total_5g
       ,httpwebrspcount_5g
       ,httpwebreqcount_5g
       ,httpwebrsprate_5g
       ,httpwebdspdelay_5g
       ,httpwebscreendelay_5g
       ,videoplaysuccesscount_5g
       ,videoplayrequestcount_5g
       ,videothroughput_5g
       ,videoplaytime_without_halt_sum_5g
       ,videoplayhaltcount_5g
       ,kqi_videoplayhaltcountpermin_5g
       ,times_excellentdownlink_5g
       ,times_inferiordownlink_5g
       ,times_welldownlink_5g
       ,times_excellentstallfrequ_5g
       ,times_inferiorstallfrequ_5g
       ,times_wellstallfrequ_5g
       ,messagesucccount_5g
       ,messagereqcount_5g
       ,messagesucc_rate_5g
       ,game_cnt_5g
       ,gameinteractdelay_5g
       ,dnsqueryrspcount_5g
       ,dnsqueryreqcount_5g
       ,dnsquerysuc_rate_5g
       ,web_good_rate_5g
       ,CASE
            WHEN NVL(video_good_rate_5g_1,0) <= NVL(video_good_rate_5g_2,0) THEN NVL(video_good_rate_5g_1,0)
            ELSE NVL(video_good_rate_5g_2,0)
        END     AS video_good_rate_5g
       ,im_good_rate_5g
       ,CASE
            WHEN gameinteractdelay_5g <= 150                       THEN 1
            WHEN 100 - (gameinteractdelay_5g - 150) * 0.75 <= 0    THEN 0
            ELSE (100 - (gameinteractdelay_5g - 150) * 0.75) / 100
        END AS game_good_rate_5g
        ,nvl(t1.section_type, t2.section_type) section_type
        ,nvl(t1.is_indoor_section_station, t2.is_indoor_section_station)  is_indoor_section_station
        ,nvl(zero_cell_cnt_4g,0)+nvl(zero_cell_cnt_5g, 0) zero_cell_cnt
        ,zero_cell_cnt_4g
        ,zero_cell_cnt_5g
        ,vonr_rtp_losspkt_rate_5g
        ,wechat_message_suc_cnt_4g
        ,wechat_message_req_cnt_4g
        ,wechat_message_suc_rate_4g
        ,wechat_message_suc_cnt_5g
        ,wechat_message_req_cnt_5g
        ,wechat_message_suc_rate_5g
        ,uexp_meanspeeddl_35_flow
        ,uexp_meanspeeddl_35_duration
        ,uexp_meanspeeddl_35
        ,nvl(uexp_meanspeeddl_21_flow_4g, 0) + nvl(uexp_meanspeeddl_21_flow_5g, 0) uexp_meanspeeddl_21_flow
        ,nvl(uexp_meanspeeddl_21_duration_4g, 0) + nvl(uexp_meanspeeddl_21_duration_5g, 0) uexp_meanspeeddl_21_duration
        ,nvl(uexp_meanspeeddl_21_flow_4g, 0) + nvl(uexp_meanspeeddl_21_flow_5g, 0) / nvl(uexp_meanspeeddl_21_duration_4g, 0) + nvl(uexp_meanspeeddl_21_duration_5g, 0) uexp_meanspeeddl_21
        ,cover_rate_score_5g
        ,videoplaysucc_rate_score_5g
        ,wechat_message_suc_rate_score_5g
        ,vonr_connsucc_rate_score_5g
        ,vonr_abnorrelease_rate_score_5g
        ,cover_score
        ,vonr_ho_succtovolte_rate_score_5g
        ,vonr_rtp_losspkt_rate_score_5g
        ,null initial_complaint_cnt
        ,null current_complaint_cnt
        ,null complaint_reduce_rate
        ,20 complaint_score
        ,null rsrpgoodcount_ott_ctcc_5g
        ,null rsrpcount_ott_ctcc_5g
        ,null cover_rate_ott_ctcc_5g
        ,null rsrpgoodcount_ott_cucc_5g
        ,null rsrpcount_ott_cucc_5g
        ,null cover_rate_ott_cucc_5g
        ,null rsrpgoodcount_ott_cmcc_5g
        ,null rsrpcount_ott_cmcc_5g
        ,null cover_rate_ott_cmcc_5g
    FROM
    (
        SELECT
            province_name
            ,citycode
            ,city_name
            ,subway_line_id
            ,subway_line
            ,type
            ,section_station_id
            ,name
            ,sum(is_bad)                                         AS bad_cel_cnt_4g
            ,sum(flux_ul)                                        AS flux_ul_4g
            ,sum(flux_dl)                                        AS flux_dl_4g
            ,sum(flux)                                           AS flux_4g
            ,sum(rrc_userconnmax)                                AS rrc_userconnmax_4g
            ,sum(is_highload)                                    AS highload_cnt_4g
            ,sum(puschprbtotmeandl)                              AS prb_useddl_4g
            ,sum(prb_dl_avail)                                   AS prb_availdl_4g
            ,sum(puschprbtotmeandl)/sum(prb_dl_avail)            AS prb_useddl_rate_4g
            ,sum(totalrsrp)                                      AS totalrsrp_4g
            ,sum(rsrpcount)                                      AS rsrpcount_4g
            ,sum(totalrsrp)/sum(rsrpcount)                       AS avgrsrp_4g
            ,sum(rsrpgoodcount_110)                              AS rsrpgoodcount_110_4g
            ,sum(rsrpgoodcount_105)                              AS rsrpgoodcount_105_4g
            ,sum(rsrpgoodcount_110)/sum(rsrpcount)               AS rsrpgoodcount_rate_110_4g
            ,sum(rsrpgoodcount_105)/sum(rsrpcount)               AS rsrpgoodcount_rate_105_4g
            ,sum(is_bad_cover)                                   AS weak_cover_cel_cnt_4g
            ,sum(is_alarm)                                       AS alarm_cnt_4g
            ,sum(scan_pay_suc_cnt)                               AS scan_pay_suc_cnt_4g
            ,sum(scan_pay_req_cnt)                               AS scan_pay_req_cnt_4g
            ,sum(scan_pay_suc_cnt)/sum(scan_pay_req_cnt)         AS scan_pay_suc_rate_4g
            ,sum(scan_pay_tcpsetupackdelay*scan_pay_req_cnt)/sum(scan_pay_req_cnt)   AS scan_pay_tcpsetupackdelay_4g
            ,sum(cqi_good_count)                                 AS cqi_good_count_4g
            ,sum(cqi_total_count)                                AS cqi_total_count_4g
            ,sum(cqi_good_count)/sum(cqi_total_count)            AS cqi_good_rate_4g
            ,sum(rrc_attconnestab)                               AS rrc_attconnestab_4g
            ,sum(rrc_succconnestab)                              AS rrc_succconnestab_4g
            ,sum(rrc_succconnestab)/sum(rrc_attconnestab)        AS rrc_succconnestab_rate_4g
            ,sum(s1sig_attconnestab)                             AS s1sig_attconnestab_4g
            ,sum(s1sig_succconnestab)                            AS s1sig_succconnestab_4g
            ,sum(s1sig_succconnestab)/sum(s1sig_attconnestab)    AS s1sig_succconnestab_rate_4g
            ,sum(erab_attestab)                                  AS erab_attestab_4g
            ,sum(erab_succestab)                                 AS erab_succestab_4g
            ,sum(erab_succestab)/sum(erab_attestab)              AS erab_succestab_rate_4g
            ,nvl(sum(rrc_succconnestab)/sum(rrc_attconnestab),1) * nvl(sum(s1sig_succconnestab)/sum(s1sig_attconnestab),1) * nvl(sum(erab_succestab)/sum(erab_attestab),1)   AS access_success_rate_4g
            ,sum(erab_attestab_qci1)                             AS erab_attestab_qci1
            ,sum(erab_succestab_qci1)                            AS erab_succestab_qci1
            ,sum(erab_succestab_qci1)/sum(erab_attestab_qci1)    AS erab_succestab_rate_qci1
            ,nvl(sum(rrc_succconnestab)/sum(rrc_attconnestab),1) * nvl(sum(s1sig_succconnestab)/sum(s1sig_attconnestab),1) * nvl(sum(erab_succestab_qci1)/sum(erab_attestab_qci1),1) AS access_success_rate_qci1
            ,sum(erab_abnormrel_qci1)                            AS erab_abnormrel_qci1
            ,sum(erab_normrel_qci1)                              AS erab_normrel_qci1
            ,nvl(sum(erab_abnormrel_qci1)/sum(erab_abnormrel_qci1+erab_normrel_qci1),0)  AS erab_drop_qci1_rate
            ,sum(uecntx_abnormrel)                               AS uecntx_abnormrel_4g
            ,sum(uecntx_normrel)                                 AS uecntx_normrel_4g
            ,sum(uecntx_abnormrel)/sum(uecntx_abnormrel+uecntx_normrel)  AS uecntx_drop_rate_4g
            ,sum(pdcp_sduoctdl)                                  AS pdcp_sduoctdl_4g
            ,sum(pdcp_sdutailflowdl)                             AS pdcp_sdutailflowdl_4g
            ,sum(pdcp_thrptimedl)                                AS pdcp_thrptimedl_4g
            ,sum(pdcp_tailtimedl)                                AS pdcp_tailtimedl_4g
            ,sum((pdcp_sduoctdl-pdcp_sdutailflowdl)*8)/sum(( pdcp_thrptimedl-pdcp_tailtimedl)/1000)  AS uexp_meanspeeddl_4g
            ,sum(pdcp_sdulosspktul_qci1)                                 AS pdcp_sdulosspktul_qci1
            ,sum(pdcp_sdupktul_qci1)                                     AS pdcp_sdupktul_qci1
            ,nvl(sum(pdcp_sdulosspktul_qci1)/sum(pdcp_sdupktul_qci1),0)  AS pdcp_sdulosspktul_qci1_rate
            ,sum(pdcp_sdulosspktdl_qci1)                                 AS pdcp_sdulosspktdl_qci1
            ,sum(pdcp_sdupktdl_qci1)                                     AS pdcp_sdupktdl_qci1
            ,nvl(sum(pdcp_sdulosspktdl_qci1)/sum(pdcp_sdupktdl_qci1),0)  AS pdcp_sdulosspktdl_qci1_rate
            ,sum(web_duration)                                           AS web_duration_4g
            ,sum(video_duration)                                         AS video_duration_4g
            ,sum(im_duration)                                            AS im_duration_4g
            ,sum(game_duration)                                          AS game_duration_4g
            ,sum(nvl(web_duration,0)+nvl(video_duration,0)+nvl(im_duration,0)+nvl(game_duration,0))  AS duration_total_4g
            ,sum(httpwebrspcount)                                                    AS httpwebrspcount_4g
            ,sum(httpwebreqcount)                                                    AS httpwebreqcount_4g
            ,sum(httpwebrspcount)/sum(httpwebreqcount)                               AS httpwebrsprate_4g
            ,sum(httpwebdspdelay*httpwebrspcount)/sum(httpwebrspcount)               AS httpwebdspdelay_4g
            ,sum(httpwebscreendelay*httpwebrspcount)/sum(httpwebrspcount)            AS httpwebscreendelay_4g
            ,sum(videoplaysuccesscount)                                              AS videoplaysuccesscount_4g
            ,sum(videoplayrequestcount)                                              AS videoplayrequestcount_4g
            ,sum(videothroughput*videoplaysuccesscount)/sum(videoplaysuccesscount)   AS videothroughput_4g
            ,sum(videoplaytime_without_halt_sum)                                     AS videoplaytime_without_halt_sum_4g
            ,sum(videoplayhaltcount)                                                 AS videoplayhaltcount_4g
            ,case when sum(videoplaytime_without_halt_sum) !=0 then sum(videoplayhaltcount)*60000/sum(videoplaytime_without_halt_sum) else 0 end AS kqi_videoplayhaltcountpermin_4g
            ,sum(times_excellentdownlink)                                            AS times_excellentdownlink_4g
            ,sum(times_excellentdownlink)                                            AS times_inferiordownlink_4g
            ,sum(times_welldownlink)                                                 AS times_welldownlink_4g
            ,sum(times_excellentstallfrequ)                                          AS times_excellentstallfrequ_4g
            ,sum(times_inferiorstallfrequ)                                           AS times_inferiorstallfrequ_4g
            ,sum(times_wellstallfrequ)                                               AS times_wellstallfrequ_4g
            ,sum(messagesucccount)                                                   AS messagesucccount_4g
            ,sum(messagereqcount)                                                    AS messagereqcount_4g
            ,sum(messagesucccount)/sum(messagereqcount)                              AS messagesucc_rate_4g
            ,sum(game_cnt)                                                           AS game_cnt_4g
            ,case when sum(game_cnt)  !=0 then sum(game_cnt*gameinteractdelay)/sum(game_cnt) else 0 end  AS gameinteractdelay_4g
            ,sum(dnsqueryrspcount)                                                   AS dnsqueryrspcount_4g
            ,sum(dnsqueryreqcount)                                                   AS dnsqueryreqcount_4g
            ,sum(dnsqueryrspcount)/sum(dnsqueryreqcount)                             AS dnsquerysuc_rate_4g
            ,sum(httpwebrspcount)/sum(httpwebreqcount)                               AS web_good_rate_4g
            ,sum(nvl(times_excellentdownlink,0)+nvl(times_welldownlink,0))/sum(nvl(times_excellentdownlink,0)+nvl(times_welldownlink,0)+nvl(times_inferiordownlink,0))  AS video_good_rate_4g_1
            ,sum(nvl(times_excellentstallfrequ,0)+nvl(times_wellstallfrequ,0))/sum(nvl(times_excellentstallfrequ,0)+nvl(times_wellstallfrequ,0)+nvl(times_inferiorstallfrequ,0))    AS video_good_rate_4g_2
            ,sum(messagesucccount)/sum(messagereqcount)  AS im_good_rate_4g
            ,section_type
            ,is_indoor_section_station
            ,sum(is_zero_flux) zero_cell_cnt_4g
            ,sum(wechat_message_suc_cnt) wechat_message_suc_cnt_4g
            ,sum(wechat_message_req_cnt) wechat_message_req_cnt_4g
            ,sum(wechat_message_suc_cnt)/sum(wechat_message_req_cnt) wechat_message_suc_rate_4g
            ,sum(case when freq = '2.1G' then (pdcp_sduoctdl-pdcp_sdutailflowdl)*8 else 0 end) uexp_meanspeeddl_21_flow_4g
            ,sum(case when freq = '2.1G' then (pdcp_thrptimedl-pdcp_tailtimedl)/1000 else 0 end) uexp_meanspeeddl_21_duration_4g
        FROM
            dm_subway_cel_lte_index_h
        WHERE p_provincecode = $dm_subway_section_station_h.p_provincecode$
            AND p_date = '$dm_subway_section_station_h.p_date$'
            AND p_hour = $dm_subway_section_station_h.p_hour$
        GROUP BY
            province_name
           ,citycode
           ,city_name
           ,subway_line_id
           ,subway_line
           ,type
           ,section_station_id
           ,name
           ,section_type
           , is_indoor_section_station
    ) t1
    FULL JOIN
    (
        SELECT
            province_name
            ,citycode
            ,city_name
            ,subway_line_id
            ,subway_line
            ,type
            ,section_station_id
            ,name
            ,sum(is_bad)                                                             AS bad_cel_cnt_5g
            ,sum(flux_ul)                                                            AS flux_ul_5g
            ,sum(flux_dl)                                                            AS flux_dl_5g
            ,sum(flux)                                                               AS flux_5g
            ,sum(rrc_userconnmax)                                                    AS rrc_userconnmax_5g
            ,sum(is_highload)                                                        AS highload_cnt_5g
            ,sum(prb_useddl)                                                         AS prb_useddl_5g
            ,sum(prb_availdl)                                                        AS prb_availdl_5g
            ,sum(prb_useddl)/sum(prb_availdl)                                        AS prb_useddl_rate_5g
            ,sum(totalrsrp)                                                          AS totalrsrp_5g
            ,sum(rsrpcount)                                                          AS rsrpcount_5g
            ,sum(totalrsrp)/sum(rsrpcount)                                           AS avgrsrp_5g
            ,sum(rsrpgoodcount_110)                                                  AS rsrpgoodcount_110_5g
            ,sum(rsrpgoodcount_105)                                                  AS rsrpgoodcount_105_5g
            ,sum(rsrpgoodcount_110)/sum(rsrpcount)                                   AS rsrpgoodcount_rate_110_5g
            ,sum(rsrpgoodcount_105)/sum(rsrpcount)                                   AS rsrpgoodcount_rate_105_5g
            ,sum(is_bad_cover)                                                       AS weak_cover_cel_cnt_5g
            ,sum(is_alarm)                                                           AS alarm_cnt_5g
            ,sum(scan_pay_suc_cnt)                                                   AS scan_pay_suc_cnt_5g
            ,sum(scan_pay_req_cnt)                                                   AS scan_pay_req_cnt_5g
            ,sum(scan_pay_suc_cnt)/sum(scan_pay_req_cnt)                             AS scan_pay_suc_rate_5g
            ,sum(scan_pay_tcpsetupackdelay*scan_pay_req_cnt)/sum(scan_pay_req_cnt)   AS scan_pay_tcpsetupackdelay_5g
            ,sum(cqi_good_count)                                                     AS cqi_good_count_5g
            ,sum(cqi_total_count)                                                    AS cqi_total_count_5g
            ,sum(cqi_good_count)/sum(cqi_total_count)                                AS cqi_good_rate_5g
            ,sum(rrc_connreq)                                                        AS rrc_connreq_5g
            ,sum(rrc_connsucc)                                                       AS rrc_connsucc_5g
            ,sum(rrc_connsucc)/sum(rrc_connreq)                                      AS rrc_connsucc_rate_5g
            ,sum(ng_connatt)                                                         AS ng_connatt_5g
            ,sum(ng_connsucc)                                                        AS ng_connsucc_5g
            ,sum(ng_connsucc)/sum(ng_connatt)                                        AS ng_connsucc_rate_5g
            ,sum(qos_initialestabreq)                                                AS qos_initialestabreq_5g
            ,sum(qos_initialestabsucc)                                               AS qos_initialestabsucc_5g
            ,sum(qos_initialestabsucc)/sum(qos_initialestabreq)                      AS qos_initialestabsucc_rate_5g
            ,nvl(sum(rrc_connsucc)/sum(rrc_connreq),1) * nvl(sum(ng_connsucc)/sum(ng_connatt),1) * nvl(sum(qos_initialestabsucc)/sum(qos_initialestabreq),1) AS access_success_rate_5g
            ,sum(ue_contextrelease)                                                  AS ue_contextrelease_5g
            ,sum(ue_normalcontextrelease)                                            AS ue_normalcontextrelease_5g
            ,nvl(sum(ue_contextrelease - ue_normalcontextrelease)/sum(ue_contextrelease),0) AS uecntx_drop_rate_5g
            ,sum(rlc_txbytesdl)                                                      AS rlc_txbytesdl_5g
            ,sum(rlc_lasttxbytesdl)                                                  AS rlc_lasttxbytesdl_5g
            ,sum(rlc_txtimedl_exceptlastslot)                                        AS rlc_txtimedl_exceptlastslot_5g
            ,(sum(rlc_txbytesdl-rlc_lasttxbytesdl)*8)/(sum(rlc_txtimedl_exceptlastslot)/1000) AS uexp_meanspeeddl_5g
            ,sum(vonr_ho_atttovolte)                                                 AS vonr_ho_atttovolte_5g
            ,sum(vonr_ho_succtovolte)                                                AS vonr_ho_succtovolte_5g
            ,sum(vonr_ho_succtovolte)/sum(vonr_ho_atttovolte)                        AS vonr_ho_succtovolte_rate_5g
            ,sum(vonr_rtp_rxpktul)                                                   AS vonr_rtp_rxpktul_5g
            ,sum(vonr_rtp_losspktul)                                                 AS vonr_rtp_losspktul_5g
            ,sum(vonr_rtp_losspktul)/sum(vonr_rtp_rxpktul)                           AS vonr_rtp_losspktul_rate_5g
            ,sum(vonr_rtp_rxpktdl)                                                   AS vonr_rtp_rxpktdl_5g
            ,sum(vonr_rtp_losspktdl)                                                 AS vonr_rtp_losspktdl_5g
            ,sum(vonr_rtp_losspktdl)/sum(vonr_rtp_rxpktdl)                           AS vonr_rtp_losspktdl_rate_5g
            ,sum(vonr_connreq)                                                       AS vonr_connreq_5g
            ,sum(vonr_connsucc)                                                      AS vonr_connsucc_5g
            ,sum(vonr_connsucc)/sum(vonr_connreq)                                    AS vonr_connsucc_rate_5g
            ,sum(vonr_releasesum)                                                    AS vonr_releasesum_5g
            ,sum(vonr_normalrelease)                                                 AS vonr_normalrelease_5g
            ,sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)            AS vonr_abnorrelease_rate_5g
            ,sum(ho_succintragnb)                                                    AS ho_succintragnb_5g
            ,sum(ho_succbyxn)                                                        AS ho_succbyxn_5g
            ,sum(ho_succbyng)                                                        AS ho_succbyng_5g
            ,sum(case when ho_attintragnb<ho_succintragnb then ho_succintragnb else ho_attintragnb end) AS ho_attintragnb_5g
            ,sum(case when ho_attbyxn<ho_succbyxn then ho_succbyxn else ho_attbyxn end) AS ho_attbyxn_5g
            ,sum(case when ho_attbyng<ho_succbyng then ho_succbyng else ho_attbyng end) AS ho_attbyng_5g
            ,nvl(sum(ho_succintragnb+ho_succbyxn+ho_succbyng)/sum(case when ho_attintragnb<ho_succintragnb then ho_succintragnb else ho_attintragnb end + case when ho_attbyxn<ho_succbyxn then ho_succbyxn else ho_attbyxn end + case when ho_attbyng<ho_succbyng then ho_succbyng else ho_attbyng end),1) AS ho_succ_rate_5g
            ,sum(epsfb_voice_suc)                                                     AS epsfb_voice_suc
            ,sum(epsfb_voice_req)                                                     AS epsfb_voice_req
            ,sum(epsfb_voice_suc)/sum(epsfb_voice_req)                                AS epsfb_voice_suc_rate
            ,sum(intra_5gstoepsbydata)                                                AS intra_5gstoepsbydata
            ,sum(intra_5gstoepsbydata)/sum(rrc_connsucc)                              AS intra_5gstoepsbydata_rate
            ,sum(web_duration)                                                        AS web_duration_5g
            ,sum(video_duration)                                                      AS video_duration_5g
            ,sum(im_duration)                                                         AS im_duration_5g
            ,sum(game_duration)                                                       AS game_duration_5g
            ,sum(nvl(web_duration,0)+nvl(video_duration,0)+nvl(im_duration,0)+nvl(game_duration,0)) AS duration_total_5g
            ,sum(httpwebrspcount)                                                     AS httpwebrspcount_5g
            ,sum(httpwebreqcount)                                                     AS httpwebreqcount_5g
            ,sum(httpwebrspcount)/sum(httpwebreqcount)                                AS httpwebrsprate_5g
            ,sum(httpwebdspdelay*httpwebrspcount)/sum(httpwebrspcount)                AS httpwebdspdelay_5g
            ,sum(httpwebscreendelay*httpwebrspcount)/sum(httpwebrspcount)             AS httpwebscreendelay_5g
            ,sum(videoplaysuccesscount)                                               AS videoplaysuccesscount_5g
            ,sum(videoplayrequestcount)                                               AS videoplayrequestcount_5g
            ,sum(videothroughput*videoplaysuccesscount)/sum(videoplaysuccesscount)    AS videothroughput_5g
            ,sum(videoplaytime_without_halt_sum)                                      AS videoplaytime_without_halt_sum_5g
            ,sum(videoplayhaltcount)                                                  AS videoplayhaltcount_5g
            ,case when sum(videoplaytime_without_halt_sum) !=0 then sum(videoplayhaltcount)*60000/sum(videoplaytime_without_halt_sum) else 0 end AS kqi_videoplayhaltcountpermin_5g
            ,sum(times_excellentdownlink)                                             AS times_excellentdownlink_5g
            ,sum(times_excellentdownlink)                                             AS times_inferiordownlink_5g
            ,sum(times_welldownlink)                                                  AS times_welldownlink_5g
            ,sum(times_excellentstallfrequ)                                           AS times_excellentstallfrequ_5g
            ,sum(times_inferiorstallfrequ)                                            AS times_inferiorstallfrequ_5g
            ,sum(times_wellstallfrequ)                                                AS times_wellstallfrequ_5g
            ,sum(messagesucccount)                                                    AS messagesucccount_5g
            ,sum(messagereqcount)                                                     AS messagereqcount_5g
            ,sum(messagesucccount)/sum(messagereqcount)                               AS messagesucc_rate_5g
            ,sum(game_cnt)                                                            AS game_cnt_5g
            ,case when sum(game_cnt)  !=0 then sum(gameinteractdelay*game_cnt)/sum(game_cnt) else 0 end  AS gameinteractdelay_5g
            ,sum(dnsqueryrspcount)                                                    AS dnsqueryrspcount_5g
            ,sum(dnsqueryreqcount)                                                    AS dnsqueryreqcount_5g
            ,sum(dnsqueryrspcount)/sum(dnsqueryreqcount)                              AS dnsquerysuc_rate_5g
            ,sum(httpwebrspcount)/sum(httpwebreqcount)                                AS web_good_rate_5g
            ,sum(nvl(times_excellentdownlink,0)+nvl(times_welldownlink,0))/sum(nvl(times_excellentdownlink,0)+nvl(times_welldownlink,0)+nvl(times_inferiordownlink,0))  AS video_good_rate_5g_1
            ,sum(nvl(times_excellentstallfrequ,0)+nvl(times_wellstallfrequ,0))/sum(nvl(times_excellentstallfrequ,0)+nvl(times_wellstallfrequ,0)+nvl(times_inferiorstallfrequ,0)) AS video_good_rate_5g_2
            ,sum(messagesucccount)/sum(messagereqcount)                               AS im_good_rate_5g
            ,sum(is_zero_flux) zero_cell_cnt_5g
            ,(sum(vonr_rtp_losspktul)/sum(vonr_rtp_rxpktul)) *0.5 + (sum(vonr_rtp_losspktdl)/sum(vonr_rtp_rxpktdl))*0.5 vonr_rtp_losspkt_rate_5g
            ,sum(wechat_message_suc_cnt) wechat_message_suc_cnt_5g
            ,sum(wechat_message_req_cnt) wechat_message_req_cnt_5g
            ,sum(wechat_message_suc_cnt)/sum(wechat_message_req_cnt) wechat_message_suc_rate_5g
            ,sum(case when freq = '3.5G' then (rlc_txbytesdl-rlc_lasttxbytesdl)*8 else 0 end) uexp_meanspeeddl_35_flow
            ,sum(case when freq = '3.5G' then (rlc_txtimedl_exceptlastslot)/1000 else 0 end) uexp_meanspeeddl_35_duration
            ,sum(case when freq = '3.5G' then (rlc_txbytesdl-rlc_lasttxbytesdl)*8 else 0 end) / sum(case when freq = '3.5G' then (rlc_txtimedl_exceptlastslot)/1000 else 0 end) uexp_meanspeeddl_35
            ,if(sum(rsrpgoodcount_105)/sum(rsrpcount) >= 0.95, 15, if((sum(rsrpgoodcount_105)/sum(rsrpcount) - 0.95)*500 + 15 < 0,0,(sum(rsrpgoodcount_105)/sum(rsrpcount) - 0.95)*500 + 15)) cover_rate_score_5g
            ,if((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) >= 0.97, 5, if(((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) - 0.97)*100 + 5 < 0,0,((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) - 0.97)*100 + 5)) videoplaysucc_rate_score_5g
            ,if((sum(wechat_message_suc_cnt)/sum(wechat_message_req_cnt)) >= 0.97, 5, if(((sum(wechat_message_suc_cnt)/sum(wechat_message_req_cnt)) - 0.97)*100 + 5 < 0,0,((sum(wechat_message_suc_cnt)/sum(wechat_message_req_cnt)) - 0.97)*100 + 5)) wechat_message_suc_rate_score_5g
            ,if((sum(vonr_connsucc)/sum(vonr_connreq)) >= 0.95, 5, if(((sum(vonr_connsucc)/sum(vonr_connreq)) - 0.95)*100 + 5 < 0,0,((sum(vonr_connsucc)/sum(vonr_connreq)) - 0.95)*100 + 5))  vonr_connsucc_rate_score_5g
            ,if((sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)) <= 0.02, 5, if(5 - ((sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)) - 0.02)*100 < 0,0,5 - ((sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)) - 0.02)*100))   vonr_abnorrelease_rate_score_5g
            ,nvl(if(sum(rsrpgoodcount_105)/sum(rsrpcount) >= 0.95, 15, if((sum(rsrpgoodcount_105)/sum(rsrpcount) - 0.95)*500 + 15 < 0,0,(sum(rsrpgoodcount_105)/sum(rsrpcount) - 0.95)*500 + 15)),0) + nvl(if((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) >= 0.97, 5, if(((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) - 0.97)*100 + 5 < 0,0,((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) - 0.97)*100 + 5)),0) + nvl(if((sum(wechat_message_suc_cnt)/sum(wechat_message_req_cnt)) >= 0.97, 5, if(((sum(wechat_message_suc_cnt)/sum(wechat_message_req_cnt)) - 0.97)*100 + 5 < 0,0,((sum(wechat_message_suc_cnt)/sum(wechat_message_req_cnt)) - 0.97)*100 + 5)),0) + nvl(if((sum(vonr_connsucc)/sum(vonr_connreq)) >= 0.95, 5, if(((sum(vonr_connsucc)/sum(vonr_connreq)) - 0.95)*100 + 5 < 0,0,((sum(vonr_connsucc)/sum(vonr_connreq)) - 0.95)*100 + 5)),0) + nvl(if((sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)) <= 0.02, 5, if(5 - ((sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)) - 0.02)*100 < 0,0,5 - ((sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)) - 0.02)*100)),0) AS cover_score
--         ,nvl(if(sum(rsrpgoodcount_105)/sum(rsrpcount) >= 0.95, 15, if((sum(rsrpgoodcount_105)/sum(rsrpcount) - 0.95)*500 + 15 < 0,0,(sum(rsrpgoodcount_105)/sum(rsrpcount) - 0.95)*500 + 15)), 0) + nvl(if((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) >= 0.97, 5, if(((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) - 0.97)*100 + 5 < 0,0,((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) - 0.97)*100 + 5)), 0) + nvl(if((sum(wechat_message_suc_cnt)/sum(wechat_message_req_cnt)) >= 0.97, 5, if(((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) - 0.97)*100 + 5 < 0,0,((sum(videoplaysuccesscount) / sum(videoplayrequestcount)) - 0.97)*100 + 5)), 0) + nvl(if((sum(vonr_connsucc)/sum(vonr_connreq)) >= 0.95, 5, ((sum(vonr_connsucc)/sum(vonr_connreq)) - 0.95)*100 + 5), 0) + nvl(if((sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)) >= 0.95, 5, if(((sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)) - 0.95)*100 + 5 < 0,0,((sum(vonr_releasesum-vonr_normalrelease)/sum(vonr_releasesum)) - 0.95)*100 + 5)), 0) cover_score
            ,if((sum(vonr_ho_succtovolte)/sum(vonr_ho_atttovolte)) >= 0.995, 5, if((sum(vonr_ho_succtovolte)/sum(vonr_ho_atttovolte) - 0.995)*500 + 15 < 0,0,(sum(vonr_ho_succtovolte)/sum(vonr_ho_atttovolte) - 0.995)*500 + 15)) vonr_ho_succtovolte_rate_score_5g
            ,if((sum(vonr_rtp_losspktul)/sum(vonr_rtp_rxpktul) * 0.5 + sum(vonr_rtp_losspktdl)/sum(vonr_rtp_rxpktdl) * 0.5) <= 0.001, 15, if(((sum(vonr_rtp_losspktul)/sum(vonr_rtp_rxpktul) * 0.5 + sum(vonr_rtp_losspktdl)/sum(vonr_rtp_rxpktdl) * 0.5) - 0.001)*5000 - 15 < 0,0,((sum(vonr_rtp_losspktul)/sum(vonr_rtp_rxpktul) * 0.5 + sum(vonr_rtp_losspktdl)/sum(vonr_rtp_rxpktdl) * 0.5) - 0.001)*5000 - 15)) vonr_rtp_losspkt_rate_score_5g
            ,section_type
            ,is_indoor_section_station
            ,sum(case when freq = '2.1G' then (rlc_txbytesdl-rlc_lasttxbytesdl)*8 else 0 end)  uexp_meanspeeddl_21_flow_5g
            ,sum(case when freq = '2.1G' then (rlc_txtimedl_exceptlastslot)/1000 else 0 end) uexp_meanspeeddl_21_duration_5g
        FROM
            dm_subway_cel_nr_index_h
        WHERE p_provincecode = $dm_subway_section_station_h.p_provincecode$
            AND p_date = '$dm_subway_section_station_h.p_date$'
            AND p_hour = $dm_subway_section_station_h.p_hour$
        GROUP BY
            province_name
           ,citycode
           ,city_name
           ,subway_line_id
           ,subway_line
           ,type
           ,section_station_id
           ,name
           ,section_type
           , is_indoor_section_station
    ) t2
    ON t1.subway_line_id = t2.subway_line_id
        AND t1.section_station_id = t2.section_station_id
--        AND t1.type = t2.type
--        AND t1.section_type = t2.section_type
        AND CASE WHEN t1.type = 0 OR t2.type = 0 THEN t1.type = t2.type
            ELSE t1.type = t2.type AND t1.section_type = t2.section_type END
) t1
LEFT JOIN
(
    SELECT
        line_id
       ,section_id
       ,section_distance / 1000 AS section_distance
       ,1   AS type
       ,ROW_NUMBER() OVER(PARTITION BY line_id,section_id ORDER BY section_distance DESC) rn
    FROM
        dm_subway_section_distance
    WHERE p_provincecode = $dm_subway_section_station_h.p_provincecode$
        AND section_distance IS NOT NULL
    HAVING rn = 1
) t2
ON t1.subway_line_id = t2.line_id
    AND t1.section_station_id = t2.section_id
    AND t1.type = t2.type
LEFT JOIN
(
    SELECT
        subway_line_id
       ,type
       ,section_station_id
       ,section_type
       ,COUNT(DISTINCT CASE WHEN master_operators='电信' THEN cellkey ELSE NULL END)    AS cel_ctcc_cnt_4g
       ,COUNT(DISTINCT CASE WHEN master_operators='联通' THEN cellkey ELSE NULL END)    AS cel_cucc_cnt_4g
       ,COUNT(DISTINCT cellkey)                                                         AS cel_cnt_4g
    FROM
        dm_subway_section_station_sector_lte_rel_use_d  -- 切换数据源 20250626
    WHERE p_provincecode = $dm_subway_section_station_sector_lte_rel_use_d.p_provincecode$
        AND p_date = '$dm_subway_section_station_sector_lte_rel_use_d.p_date$'
        AND valid_flag = 1  -- 添加过滤条件 20250626
    GROUP BY
        subway_line_id
       ,type
       ,section_station_id
       ,section_type
) t3
ON t1.subway_line_id = t3.subway_line_id
    AND t1.section_station_id = t3.section_station_id
    AND t1.type = t3.type
    AND t1.section_type = t3.section_type
LEFT JOIN
(
    SELECT
        subway_line_id
        ,type
        ,section_station_id
        ,section_type
        ,COUNT(DISTINCT CASE WHEN master_operators='电信' THEN cellkey ELSE NULL END)    AS cel_ctcc_cnt_5g
        ,COUNT(DISTINCT CASE WHEN master_operators='联通' THEN cellkey ELSE NULL END)    AS cel_cucc_cnt_5g
        ,COUNT(DISTINCT cellkey)                                                         AS cel_cnt_5g
        ,count(distinct case when freq='3.5G' then cellkey else null end) cell_cnt_35_5g
        ,count(distinct case when freq='3.5G' then cellkey else null end)/count(distinct cellkey) cell_cnt_rate_35_5g
    FROM
        dm_subway_section_station_sector_nr_rel_use_d  -- 切换数据源 20250626
    WHERE p_provincecode = $dm_subway_section_station_sector_nr_rel_use_d.p_provincecode$
        AND p_date = '$dm_subway_section_station_sector_nr_rel_use_d.p_date$'
        AND valid_flag = 1  -- 添加过滤条件 20250626
    GROUP BY
        subway_line_id
       ,type
       ,section_station_id
       ,section_type
) t4
ON t1.subway_line_id = t4.subway_line_id
    AND t1.section_station_id = t4.section_station_id
    AND t1.type = t4.type
    AND t1.section_type = t4.section_type
LEFT JOIN
(
    SELECT
        subway_line_id
       ,type
       ,section_station_id
       ,COUNT(DISTINCT CASE WHEN net_type='4G' THEN imsi ELSE NULL END)   AS usr_cnt_4g
       ,COUNT(DISTINCT CASE WHEN net_type='5G' THEN imsi ELSE NULL END)   AS usr_cnt_5g
       ,COUNT(DISTINCT imsi)                                              AS usr_cnt
    FROM
        dm_subway_usrcel_list_h
    WHERE p_provincecode = $dm_subway_section_station_h.p_provincecode$
        AND p_date = '$dm_subway_section_station_h.p_date$'
        AND p_hour = $dm_subway_section_station_h.p_hour$
    GROUP BY
        subway_line_id
       ,type
       ,section_station_id
) t5
ON t1.subway_line_id = t5.subway_line_id
    AND t1.section_station_id = t5.section_station_id
    AND t1.type = t5.type
distribute by rand()
;
