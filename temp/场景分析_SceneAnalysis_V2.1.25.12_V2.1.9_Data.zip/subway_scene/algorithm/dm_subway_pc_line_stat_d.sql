-- 20250626updateby : goupengcheng 10207
-- algorithm : 更换地铁小区输入表

set spark.sql.adaptive.enabled=true;
set spark.sql.adaptive.minNumPostShufflePartitions = 1;
set spark.sql.adaptive.maxNumPostShufflePartitions = 1000;
set spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 512435456;
set spark.sql.adaptive.shuffle.targetPostShuffleRowCount = 100000000;

CACHE TABLE tmp_bad_subway_flag AS
SELECT
    provincecode
   ,citycode
   ,subway_line_id
   ,3   AS data_level
   ,case when sum(case when type=0 and is_bad=1 then 1 else 0 end)/sum(case when type=0 then 1 else 0 end) > 0.1 OR sum(case when type=1 and is_bad=1 then 1 else 0 end)/sum(case when type=1 then 1 else 0 end) > 0.1 then 1 else 0 end  AS is_bad_line
FROM
    dm_subway_section_station_d
WHERE p_date = '$dm_subway_pc_line_stat_d.p_date$'
GROUP BY
    provincecode
   ,citycode
   ,subway_line_id
;

INSERT OVERWRITE TABLE dm_subway_pc_line_stat_d
PARTITION (
    p_date = '$dm_subway_pc_line_stat_d.p_date$'
)
select
    day
    ,data_level
    ,provincecode
    ,province_name
    ,citycode
    ,city_name
    ,subway_line_id
    ,subway_line
    ,is_bad_line
    ,line_distance
    ,station_cnt
    ,section_cnt
    ,bad_station_cnt
    ,bad_section_cnt
    ,bad_station_rate
    ,bad_section_rate
    ,bad_line_cnt
    ,line_cnt
    ,bad_line_rate
    ,usr_cnt_4g
    ,usr_cnt_5g
    ,usr_cnt
    ,cel_ctcc_cnt_4g
    ,cel_cucc_cnt_4g
    ,cel_cnt_4g
    ,cel_ctcc_cnt_5g
    ,cel_cucc_cnt_5g
    ,cel_cnt_5g
    ,cel_cnt
    ,flux_ul_4g
    ,flux_dl_4g
    ,flux_4g
    ,flux_ul_5g
    ,flux_dl_5g
    ,flux_5g
    ,flux_rate_5g
    ,rrc_userconnmax_4g
    ,rrc_userconnmax_5g
    ,highload_cnt_4g
    ,highload_cnt_5g
    ,highload_cnt
    ,highload_rate
    ,prb_useddl_4g
    ,prb_availdl_4g
    ,prb_useddl_rate_4g
    ,prb_useddl_busy_4g
    ,prb_availdl_busy_4g
    ,prb_useddl_rate_busy_4g
    ,prb_useddl_5g
    ,prb_availdl_5g
    ,prb_useddl_rate_5g
    ,prb_useddl_busy_5g
    ,prb_availdl_busy_5g
    ,prb_useddl_rate_busy_5g
    ,totalrsrp_4g
    ,rsrpcount_4g
    ,avgrsrp_4g
    ,rsrpgoodcount_110_4g
    ,rsrpgoodcount_105_4g
    ,rsrpgoodcount_rate_110_4g
    ,rsrpgoodcount_rate_105_4g
    ,totalrsrp_5g
    ,rsrpcount_5g
    ,avgrsrp_5g
    ,rsrpgoodcount_110_5g
    ,rsrpgoodcount_105_5g
    ,rsrpgoodcount_rate_110_5g
    ,rsrpgoodcount_rate_105_5g
    ,totalrsrp
    ,rsrpcount
    ,avgrsrp
    ,rsrpgoodcount_110
    ,rsrpgoodcount_105
    ,rsrpgoodcount_rate_110
    ,rsrpgoodcount_rate_105
    ,rsrpcount_5g_rate
    ,weak_cover_cel_cnt_4g
    ,weak_cover_cel_cnt_5g
    ,weak_cover_cel_cnt
    ,alarm_cnt_4g
    ,alarm_cnt_5g
    ,alarm_cnt
    ,alarm_rate
    ,scan_pay_suc_cnt_4g
    ,scan_pay_req_cnt_4g
    ,scan_pay_suc_rate_4g
    ,scan_pay_tcpsetupackdelay_4g
    ,scan_pay_suc_cnt_5g
    ,scan_pay_req_cnt_5g
    ,scan_pay_suc_rate_5g
    ,scan_pay_tcpsetupackdelay_5g
    ,scan_pay_suc_cnt
    ,scan_pay_req_cnt
    ,scan_pay_suc_rate
    ,scan_pay_tcpsetupackdelay
    ,cqi_good_count_4g
    ,cqi_total_count_4g
    ,cqi_good_rate_4g
    ,cqi_good_count_5g
    ,cqi_total_count_5g
    ,cqi_good_rate_5g
    ,rrc_attconnestab_4g
    ,rrc_succconnestab_4g
    ,rrc_succconnestab_rate_4g
    ,s1sig_attconnestab_4g
    ,s1sig_succconnestab_4g
    ,s1sig_succconnestab_rate_4g
    ,erab_attestab_4g
    ,erab_succestab_4g
    ,erab_succestab_rate_4g
    ,access_success_rate_4g
    ,erab_attestab_qci1
    ,erab_succestab_qci1
    ,erab_succestab_rate_qci1
    ,access_success_rate_qci1
    ,erab_abnormrel_qci1
    ,erab_normrel_qci1
    ,erab_drop_qci1_rate
    ,rrc_connreq_5g
    ,rrc_connsucc_5g
    ,rrc_connsucc_rate_5g
    ,ng_connatt_5g
    ,ng_connsucc_5g
    ,ng_connsucc_rate_5g
    ,qos_initialestabreq_5g
    ,qos_initialestabsucc_5g
    ,qos_initialestabsucc_rate_5g
    ,access_success_rate_5g
    ,uecntx_abnormrel_4g
    ,uecntx_normrel_4g
    ,uecntx_drop_rate_4g
    ,ue_contextrelease_5g
    ,ue_normalcontextrelease_5g
    ,uecntx_drop_rate_5g
    ,pdcp_sduoctdl_4g
    ,pdcp_sdutailflowdl_4g
    ,pdcp_thrptimedl_4g
    ,pdcp_tailtimedl_4g
    ,uexp_meanspeeddl_4g
    ,rlc_txbytesdl_5g
    ,rlc_lasttxbytesdl_5g
    ,rlc_txtimedl_exceptlastslot_5g
    ,uexp_meanspeeddl_5g
    ,pdcp_sdulosspktul_qci1
    ,pdcp_sdupktul_qci1
    ,pdcp_sdulosspktul_qci1_rate
    ,pdcp_sdulosspktdl_qci1
    ,pdcp_sdupktdl_qci1
    ,pdcp_sdulosspktdl_qci1_rate
    ,vonr_ho_atttovolte_5g
    ,vonr_ho_succtovolte_5g
    ,vonr_ho_succtovolte_rate_5g
    ,vonr_rtp_rxpktul_5g
    ,vonr_rtp_losspktul_5g
    ,vonr_rtp_losspktul_rate_5g
    ,vonr_rtp_rxpktdl_5g
    ,vonr_rtp_losspktdl_5g
    ,vonr_rtp_losspktdl_rate_5g
    ,vonr_connreq_5g
    ,vonr_connsucc_5g
    ,vonr_connsucc_rate_5g
    ,vonr_releasesum_5g
    ,vonr_normalrelease_5g
    ,vonr_abnorrelease_rate_5g
    ,ho_succintragnb_5g
    ,ho_succbyxn_5g
    ,ho_succbyng_5g
    ,ho_attintragnb_5g
    ,ho_attbyxn_5g
    ,ho_attbyng_5g
    ,ho_succ_rate_5g
    ,epsfb_voice_suc
    ,epsfb_voice_req
    ,epsfb_voice_suc_rate
    ,intra_5gstoepsbydata
    ,intra_5gstoepsbydata_rate
    ,web_duration_4g
    ,video_duration_4g
    ,im_duration_4g
    ,game_duration_4g
    ,duration_total_4g
    ,httpwebrspcount_4g
    ,httpwebreqcount_4g
    ,httpwebrsprate_4g
    ,httpwebdspdelay_4g
    ,httpwebscreendelay_4g
    ,videoplaysuccesscount_4g
    ,videoplayrequestcount_4g
    ,videothroughput_4g
    ,videoplaytime_without_halt_sum_4g
    ,videoplayhaltcount_4g
    ,kqi_videoplayhaltcountpermin_4g
    ,times_excellentdownlink_4g
    ,times_inferiordownlink_4g
    ,times_welldownlink_4g
    ,times_excellentstallfrequ_4g
    ,times_inferiorstallfrequ_4g
    ,times_wellstallfrequ_4g
    ,messagesucccount_4g
    ,messagereqcount_4g
    ,messagesucc_rate_4g
    ,game_cnt_4g
    ,gameinteractdelay_4g
    ,dnsqueryrspcount_4g
    ,dnsqueryreqcount_4g
    ,dnsquerysuc_rate_4g
    ,kqi_good_rate_4g
    ,web_good_rate_4g
    ,video_good_rate_4g
    ,im_good_rate_4g
    ,game_good_rate_4g
    ,web_duration_5g
    ,video_duration_5g
    ,im_duration_5g
    ,game_duration_5g
    ,duration_total_5g
    ,httpwebrspcount_5g
    ,httpwebreqcount_5g
    ,httpwebrsprate_5g
    ,httpwebdspdelay_5g
    ,httpwebscreendelay_5g
    ,videoplaysuccesscount_5g
    ,videoplayrequestcount_5g
    ,videothroughput_5g
    ,videoplaytime_without_halt_sum_5g
    ,videoplayhaltcount_5g
    ,kqi_videoplayhaltcountpermin_5g
    ,times_excellentdownlink_5g
    ,times_inferiordownlink_5g
    ,times_welldownlink_5g
    ,times_excellentstallfrequ_5g
    ,times_inferiorstallfrequ_5g
    ,times_wellstallfrequ_5g
    ,messagesucccount_5g
    ,messagereqcount_5g
    ,messagesucc_rate_5g
    ,game_cnt_5g
    ,gameinteractdelay_5g
    ,dnsqueryrspcount_5g
    ,dnsqueryreqcount_5g
    ,dnsquerysuc_rate_5g
    ,kqi_good_rate_5g
    ,web_good_rate_5g
    ,video_good_rate_5g
    ,im_good_rate_5g
    ,game_good_rate_5g
    ,zero_cell_cnt_4g
    ,zero_cell_cnt_5g
    ,zero_cell_cnt
    ,vonr_rtp_losspkt_rate_5g
    ,wechat_message_suc_cnt_4g
    ,wechat_message_req_cnt_4g
    ,wechat_message_suc_rate_4g
    ,wechat_message_suc_cnt_5g
    ,wechat_message_req_cnt_5g
    ,wechat_message_suc_rate_5g
    ,cell_cnt_35_5g
    ,cell_cnt_rate_35_5g
    ,uexp_meanspeeddl_35_flow
    ,uexp_meanspeeddl_35_duration
    ,uexp_meanspeeddl_35
    ,uexp_meanspeeddl_21_flow
    ,uexp_meanspeeddl_21_duration
    ,uexp_meanspeeddl_21
    ,if(cover_rate_score_5g < 0, 0 ,cover_rate_score_5g) cover_rate_score_5g
    ,if(videoplaysucc_rate_score_5g < 0, 0 ,videoplaysucc_rate_score_5g) videoplaysucc_rate_score_5g
    ,if(wechat_message_suc_rate_score_5g < 0, 0 ,wechat_message_suc_rate_score_5g) wechat_message_suc_rate_score_5g
    ,if(vonr_connsucc_rate_score_5g < 0, 0 ,vonr_connsucc_rate_score_5g) vonr_connsucc_rate_score_5g
    ,if(vonr_abnorrelease_rate_score_5g < 0, 0 ,vonr_abnorrelease_rate_score_5g) vonr_abnorrelease_rate_score_5g
    ,if(cover_score < 0, 0 ,cover_score) cover_score
    ,if(vonr_ho_succtovolte_rate_score_5g < 0, 0 ,vonr_ho_succtovolte_rate_score_5g) vonr_ho_succtovolte_rate_score_5g
    ,if(vonr_rtp_losspkt_rate_score_5g < 0, 0 ,vonr_rtp_losspkt_rate_score_5g) vonr_rtp_losspkt_rate_score_5g
    ,if(uexp_meanspeeddl_score < 0, 0 ,uexp_meanspeeddl_score) uexp_meanspeeddl_score
    ,if(perception_score < 0, 0 ,perception_score) perception_score
    ,initial_complaint_cnt
    ,current_complaint_cnt
    ,complaint_reduce_rate
    ,if(complaint_score < 0, 0 ,complaint_score) complaint_score
    ,if(total_score < 0, 0 ,total_score) total_score
    ,rsrpgoodcount_ott_ctcc_5g
    ,rsrpcount_ott_ctcc_5g
    ,cover_rate_ott_ctcc_5g
    ,rsrpgoodcount_ott_cucc_5g
    ,rsrpcount_ott_cucc_5g
    ,cover_rate_ott_cucc_5g
    ,rsrpgoodcount_ott_cmcc_5g
    ,rsrpcount_ott_cmcc_5g
    ,cover_rate_ott_cmcc_5g
from
(
    SELECT
        '$dm_subway_pc_line_stat_d.p_date$' AS day
        ,t1.data_level                       AS data_level
        ,t1.provincecode                     AS provincecode
        ,province_name
        ,t1.citycode                         AS citycode
        ,city_name
        ,t1.subway_line_id                   AS subway_line_id
        ,subway_line
        ,is_bad_line
        ,line_distance
        ,station_cnt
        ,section_cnt
        ,bad_station_cnt
        ,bad_section_cnt
        ,bad_station_rate
        ,bad_section_rate
        ,bad_line_cnt
        ,line_cnt
        ,bad_line_rate
        ,usr_cnt_4g
        ,usr_cnt_5g
        ,usr_cnt
        ,cel_ctcc_cnt_4g
        ,cel_cucc_cnt_4g
        ,cel_cnt_4g
        ,cel_ctcc_cnt_5g
        ,cel_cucc_cnt_5g
        ,cel_cnt_5g
        ,NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0)   AS cel_cnt
        ,flux_ul_4g
        ,flux_dl_4g
        ,flux_4g
        ,flux_ul_5g
        ,flux_dl_5g
        ,flux_5g
        ,flux_rate_5g
        ,rrc_userconnmax_4g
        ,rrc_userconnmax_5g
        ,highload_cnt_4g
        ,highload_cnt_5g
        ,highload_cnt
        ,highload_cnt / (NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0))  AS highload_rate
        ,prb_useddl_4g
        ,prb_availdl_4g
        ,prb_useddl_rate_4g
        ,prb_useddl_busy_4g
        ,prb_availdl_busy_4g
        ,prb_useddl_rate_busy_4g
        ,prb_useddl_5g
        ,prb_availdl_5g
        ,prb_useddl_rate_5g
        ,prb_useddl_busy_5g
        ,prb_availdl_busy_5g
        ,prb_useddl_rate_busy_5g
        ,totalrsrp_4g
        ,rsrpcount_4g
        ,avgrsrp_4g
        ,rsrpgoodcount_110_4g
        ,rsrpgoodcount_105_4g
        ,rsrpgoodcount_rate_110_4g
        ,rsrpgoodcount_rate_105_4g
        ,totalrsrp_5g
        ,rsrpcount_5g
        ,avgrsrp_5g
        ,rsrpgoodcount_110_5g
        ,rsrpgoodcount_105_5g
        ,rsrpgoodcount_rate_110_5g
        ,rsrpgoodcount_rate_105_5g
        ,totalrsrp
        ,rsrpcount
        ,avgrsrp
        ,null rsrpgoodcount_110
        ,null rsrpgoodcount_105
        ,0.5*NVL(rsrpgoodcount_rate_110_4g,0) + 0.5*NVL(rsrpgoodcount_rate_110_5g,0) rsrpgoodcount_rate_110
        ,0.5*NVL(rsrpgoodcount_rate_105_4g,0) + 0.5*NVL(rsrpgoodcount_rate_105_5g,0) rsrpgoodcount_rate_105
        ,rsrpcount_5g_rate
        ,weak_cover_cel_cnt_4g
        ,weak_cover_cel_cnt_5g
        ,weak_cover_cel_cnt
        ,alarm_cnt_4g
        ,alarm_cnt_5g
        ,alarm_cnt
        ,alarm_cnt / (NVL(cel_cnt_4g,0) + NVL(cel_cnt_5g,0))  AS alarm_rate
        ,scan_pay_suc_cnt_4g
        ,scan_pay_req_cnt_4g
        ,scan_pay_suc_rate_4g
        ,scan_pay_tcpsetupackdelay_4g
        ,scan_pay_suc_cnt_5g
        ,scan_pay_req_cnt_5g
        ,scan_pay_suc_rate_5g
        ,scan_pay_tcpsetupackdelay_5g
        ,scan_pay_suc_cnt
        ,scan_pay_req_cnt
        ,scan_pay_suc_rate
        ,scan_pay_tcpsetupackdelay
        ,cqi_good_count_4g
        ,cqi_total_count_4g
        ,cqi_good_rate_4g
        ,cqi_good_count_5g
        ,cqi_total_count_5g
        ,cqi_good_rate_5g
        ,rrc_attconnestab_4g
        ,rrc_succconnestab_4g
        ,rrc_succconnestab_rate_4g
        ,s1sig_attconnestab_4g
        ,s1sig_succconnestab_4g
        ,s1sig_succconnestab_rate_4g
        ,erab_attestab_4g
        ,erab_succestab_4g
        ,erab_succestab_rate_4g
        ,access_success_rate_4g
        ,erab_attestab_qci1
        ,erab_succestab_qci1
        ,erab_succestab_rate_qci1
        ,access_success_rate_qci1
        ,erab_abnormrel_qci1
        ,erab_normrel_qci1
        ,erab_drop_qci1_rate
        ,rrc_connreq_5g
        ,rrc_connsucc_5g
        ,rrc_connsucc_rate_5g
        ,ng_connatt_5g
        ,ng_connsucc_5g
        ,ng_connsucc_rate_5g
        ,qos_initialestabreq_5g
        ,qos_initialestabsucc_5g
        ,qos_initialestabsucc_rate_5g
        ,access_success_rate_5g
        ,uecntx_abnormrel_4g
        ,uecntx_normrel_4g
        ,uecntx_drop_rate_4g
        ,ue_contextrelease_5g
        ,ue_normalcontextrelease_5g
        ,uecntx_drop_rate_5g
        ,pdcp_sduoctdl_4g
        ,pdcp_sdutailflowdl_4g
        ,pdcp_thrptimedl_4g
        ,pdcp_tailtimedl_4g
        ,uexp_meanspeeddl_4g
        ,rlc_txbytesdl_5g
        ,rlc_lasttxbytesdl_5g
        ,rlc_txtimedl_exceptlastslot_5g
        ,uexp_meanspeeddl_5g
        ,pdcp_sdulosspktul_qci1
        ,pdcp_sdupktul_qci1
        ,pdcp_sdulosspktul_qci1_rate
        ,pdcp_sdulosspktdl_qci1
        ,pdcp_sdupktdl_qci1
        ,pdcp_sdulosspktdl_qci1_rate
        ,vonr_ho_atttovolte_5g
        ,vonr_ho_succtovolte_5g
        ,vonr_ho_succtovolte_rate_5g
        ,vonr_rtp_rxpktul_5g
        ,vonr_rtp_losspktul_5g
        ,vonr_rtp_losspktul_rate_5g
        ,vonr_rtp_rxpktdl_5g
        ,vonr_rtp_losspktdl_5g
        ,vonr_rtp_losspktdl_rate_5g
        ,vonr_connreq_5g
        ,vonr_connsucc_5g
        ,vonr_connsucc_rate_5g
        ,vonr_releasesum_5g
        ,vonr_normalrelease_5g
        ,vonr_abnorrelease_rate_5g
        ,ho_succintragnb_5g
        ,ho_succbyxn_5g
        ,ho_succbyng_5g
        ,ho_attintragnb_5g
        ,ho_attbyxn_5g
        ,ho_attbyng_5g
        ,ho_succ_rate_5g
        ,epsfb_voice_suc
        ,epsfb_voice_req
        ,epsfb_voice_suc_rate
        ,intra_5gstoepsbydata
        ,intra_5gstoepsbydata_rate
        ,web_duration_4g
        ,video_duration_4g
        ,im_duration_4g
        ,game_duration_4g
        ,duration_total_4g
        ,httpwebrspcount_4g
        ,httpwebreqcount_4g
        ,httpwebrsprate_4g
        ,httpwebdspdelay_4g
        ,httpwebscreendelay_4g
        ,videoplaysuccesscount_4g
        ,videoplayrequestcount_4g
        ,videothroughput_4g
        ,videoplaytime_without_halt_sum_4g
        ,videoplayhaltcount_4g
        ,kqi_videoplayhaltcountpermin_4g
        ,times_excellentdownlink_4g
        ,times_inferiordownlink_4g
        ,times_welldownlink_4g
        ,times_excellentstallfrequ_4g
        ,times_inferiorstallfrequ_4g
        ,times_wellstallfrequ_4g
        ,messagesucccount_4g
        ,messagereqcount_4g
        ,messagesucc_rate_4g
        ,game_cnt_4g
        ,gameinteractdelay_4g
        ,dnsqueryrspcount_4g
        ,dnsqueryreqcount_4g
        ,dnsquerysuc_rate_4g
        ,ROUND(0.1 * NVL(dnsquerysuc_rate_4g,1) + 0.9 * (NVL(web_duration_4g,0) / duration_total_4g * NVL(httpwebrsprate_4g,1) + NVL(video_duration_4g,0) / duration_total_4g * NVL(video_good_rate_4g,1) + NVL(game_duration_4g,0) / duration_total_4g * NVL(game_good_rate_4g,1) + NVL(im_duration_4g,0) / duration_total_4g * NVL(im_good_rate_4g,1)),5) AS kqi_good_rate_4g
        ,web_good_rate_4g
        ,video_good_rate_4g
        ,im_good_rate_4g
        ,game_good_rate_4g
        ,web_duration_5g
        ,video_duration_5g
        ,im_duration_5g
        ,game_duration_5g
        ,duration_total_5g
        ,httpwebrspcount_5g
        ,httpwebreqcount_5g
        ,httpwebrsprate_5g
        ,httpwebdspdelay_5g
        ,httpwebscreendelay_5g
        ,videoplaysuccesscount_5g
        ,videoplayrequestcount_5g
        ,videothroughput_5g
        ,videoplaytime_without_halt_sum_5g
        ,videoplayhaltcount_5g
        ,kqi_videoplayhaltcountpermin_5g
        ,times_excellentdownlink_5g
        ,times_inferiordownlink_5g
        ,times_welldownlink_5g
        ,times_excellentstallfrequ_5g
        ,times_inferiorstallfrequ_5g
        ,times_wellstallfrequ_5g
        ,messagesucccount_5g
        ,messagereqcount_5g
        ,messagesucc_rate_5g
        ,game_cnt_5g
        ,gameinteractdelay_5g
        ,dnsqueryrspcount_5g
        ,dnsqueryreqcount_5g
        ,dnsquerysuc_rate_5g
        ,ROUND(0.1 * NVL(dnsquerysuc_rate_5g,1) + 0.9 * (NVL(web_duration_5g,0) / duration_total_5g * NVL(httpwebrsprate_5g,1) + NVL(video_duration_5g,0) / duration_total_5g * NVL(video_good_rate_5g,1) + NVL(game_duration_5g,0) / duration_total_5g * NVL(game_good_rate_5g,1) + NVL(im_duration_5g,0) / duration_total_5g * NVL(im_good_rate_5g,1)),5) AS kqi_good_rate_5g
        ,web_good_rate_5g
        ,video_good_rate_5g
        ,im_good_rate_5g
        ,game_good_rate_5g
        ,zero_cell_cnt_4g
        ,zero_cell_cnt_5g
        ,zero_cell_cnt
        ,vonr_rtp_losspkt_rate_5g
        ,wechat_message_suc_cnt_4g
        ,wechat_message_req_cnt_4g
        ,wechat_message_suc_rate_4g
        ,wechat_message_suc_cnt_5g
        ,wechat_message_req_cnt_5g
        ,wechat_message_suc_rate_5g
        ,cell_cnt_35_5g
        ,cell_cnt_rate_35_5g
        ,uexp_meanspeeddl_35_flow
        ,uexp_meanspeeddl_35_duration
        ,uexp_meanspeeddl_35
        ,uexp_meanspeeddl_21_flow
        ,uexp_meanspeeddl_21_duration
        ,uexp_meanspeeddl_21
        ,cover_rate_score_5g
        ,videoplaysucc_rate_score_5g
        ,wechat_message_suc_rate_score_5g
        ,vonr_connsucc_rate_score_5g
        ,vonr_abnorrelease_rate_score_5g
        ,cover_score
        ,vonr_ho_succtovolte_rate_score_5g
        ,vonr_rtp_losspkt_rate_score_5g
        ,if(cell_cnt_rate_35_5g >= 0.6, case when uexp_meanspeeddl_35 >= 150 then 15 when uexp_meanspeeddl_35 <= 100 then 0 when uexp_meanspeeddl_35 <= 150 and uexp_meanspeeddl_35 >= 100 then (uexp_meanspeeddl_35 - 100) * 15/(150 - 100) end, case when uexp_meanspeeddl_21 >= 30 then 15 when uexp_meanspeeddl_21 <= 10 then 0 when uexp_meanspeeddl_21 <= 30 and uexp_meanspeeddl_21 >= 10 then (uexp_meanspeeddl_21 - 10) * 15/(30 - 10) end) uexp_meanspeeddl_score
        ,nvl(vonr_ho_succtovolte_rate_score_5g, 0) + nvl(vonr_rtp_losspkt_rate_score_5g, 0) + nvl(if(cell_cnt_rate_35_5g >= 0.6, case when uexp_meanspeeddl_35 >= 150 then 15 when uexp_meanspeeddl_35 <= 100 then 0 when uexp_meanspeeddl_35 <= 150 and uexp_meanspeeddl_35 >= 100 then (uexp_meanspeeddl_35 - 100) * 15/(150 - 100) end, case when uexp_meanspeeddl_21 >= 30 then 15 when uexp_meanspeeddl_21 <= 10 then 0 when uexp_meanspeeddl_21 <= 30 and uexp_meanspeeddl_21 >= 10 then (uexp_meanspeeddl_21 - 10) * 15/(30 - 10) end), 0)  perception_score
        ,null initial_complaint_cnt
        ,null current_complaint_cnt
        ,null complaint_reduce_rate
        ,20 complaint_score
        ,nvl(cover_score, 0) + (nvl(vonr_ho_succtovolte_rate_score_5g, 0) + nvl(vonr_rtp_losspkt_rate_score_5g, 0) + nvl(if(cell_cnt_rate_35_5g >= 0.6, case when uexp_meanspeeddl_35 >= 150 then 15 when uexp_meanspeeddl_35 <= 100 then 0 when uexp_meanspeeddl_35 <= 150 and uexp_meanspeeddl_35 >= 100 then (uexp_meanspeeddl_35 - 100) * 15/(150 - 100) end, case when uexp_meanspeeddl_21 >= 30 then 15 when uexp_meanspeeddl_21 <= 10 then 0 when uexp_meanspeeddl_21 <= 30 and uexp_meanspeeddl_21 >= 10 then (uexp_meanspeeddl_21 - 10) * 15/(30 - 10) end), 0)) + 20 total_score
        ,rsrpgoodcount_ott_ctcc_5g
        ,rsrpcount_ott_ctcc_5g
        ,cover_rate_ott_ctcc_5g
        ,rsrpgoodcount_ott_cucc_5g
        ,rsrpcount_ott_cucc_5g
        ,cover_rate_ott_cucc_5g
        ,rsrpgoodcount_ott_cmcc_5g
        ,rsrpcount_ott_cmcc_5g
        ,cover_rate_ott_cmcc_5g
    FROM
    (
        SELECT
            CASE
                WHEN subway_line_id IS NOT NULL THEN 3
                WHEN citycode IS NOT NULL       THEN 2
                WHEN provincecode IS NOT NULL   THEN 1
                ELSE 0
            END AS data_level
            ,provincecode
            ,province_name
            ,citycode
            ,city_name
            ,subway_line_id
            ,subway_line
    --       ,sum(case when type=1 then section_distance else 0 end)                                          AS line_distance
            ,sum(case when type=0 then 1 else 0 end)                                                         AS station_cnt
            ,sum(case when type=1 then 1 else 0 end)                                                         AS section_cnt
            ,sum(case when type=0 and is_bad=1 then 1 else 0 end)                                            AS bad_station_cnt
            ,sum(case when type=1 and is_bad=1 then 1 else 0 end)                                            AS bad_section_cnt
            ,sum(case when type=0 and is_bad=1 then 1 else 0 end)/sum(case when type=0 then 1 else 0 end)    AS bad_station_rate
            ,sum(case when type=1 and is_bad=1 then 1 else 0 end)/sum(case when type=1 then 1 else 0 end)    AS bad_section_rate
            ,sum(flux_ul_4g)                                                                                 AS flux_ul_4g
            ,sum(flux_dl_4g)                                                                                 AS flux_dl_4g
            ,sum(flux_4g)                                                                                    AS flux_4g
            ,sum(flux_ul_5g)                                                                                 AS flux_ul_5g
            ,sum(flux_dl_5g)                                                                                 AS flux_dl_5g
            ,sum(flux_5g)                                                                                    AS flux_5g
            ,sum(flux_5g)/sum(nvl(flux_5g,0)+nvl(flux_4g,0))                                                               AS flux_rate_5g
            ,SUM(prb_useddl_busy_4g)                                                                         AS prb_useddl_busy_4g
            ,SUM(prb_availdl_busy_4g)                                                                        AS prb_availdl_busy_4g
            ,SUM(prb_useddl_busy_4g) / SUM(prb_availdl_busy_4g)                                              AS prb_useddl_rate_busy_4g
            ,SUM(prb_useddl_busy_5g)                                                                         AS prb_useddl_busy_5g
            ,SUM(prb_availdl_busy_5g)                                                                        AS prb_availdl_busy_5g
            ,SUM(prb_useddl_busy_5g) / SUM(prb_availdl_busy_5g)                                              AS prb_useddl_rate_busy_5g
            ,max(rrc_userconnmax_4g)                                                                         AS rrc_userconnmax_4g
            ,max(rrc_userconnmax_5g)                                                                         AS rrc_userconnmax_5g
--           ,sum(highload_cnt_4g)                                                                            AS highload_cnt_4g
--           ,sum(highload_cnt_5g)                                                                            AS highload_cnt_5g
--           ,sum(highload_cnt)                                                                               AS highload_cnt
            ,sum(prb_useddl_4g)                                                                              AS prb_useddl_4g
            ,sum(prb_availdl_4g)                                                                             AS prb_availdl_4g
            ,sum(prb_useddl_4g)/sum(prb_availdl_4g)                                                          AS prb_useddl_rate_4g
            ,sum(prb_useddl_5g)                                                                              AS prb_useddl_5g
            ,sum(prb_availdl_5g)                                                                             AS prb_availdl_5g
            ,sum(prb_useddl_5g)/sum(prb_availdl_5g)                                                          AS prb_useddl_rate_5g
            ,sum(totalrsrp_4g)                                                                               AS totalrsrp_4g
            ,sum(rsrpcount_4g)                                                                               AS rsrpcount_4g
            ,sum(totalrsrp_4g)/sum(rsrpcount_4g)                                                             AS avgrsrp_4g
            ,sum(rsrpgoodcount_110_4g)                                                                       AS rsrpgoodcount_110_4g
            ,sum(rsrpgoodcount_105_4g)                                                                       AS rsrpgoodcount_105_4g
            ,sum(rsrpgoodcount_110_4g)/sum(rsrpcount_4g)                                                     AS rsrpgoodcount_rate_110_4g
            ,sum(rsrpgoodcount_105_4g)/sum(rsrpcount_4g)                                                     AS rsrpgoodcount_rate_105_4g
            ,sum(totalrsrp_5g)                                                                               AS totalrsrp_5g
            ,sum(rsrpcount_5g)                                                                               AS rsrpcount_5g
            ,sum(totalrsrp_5g)/sum(rsrpcount_5g)                                                             AS avgrsrp_5g
            ,sum(rsrpgoodcount_110_5g)                                                                       AS rsrpgoodcount_110_5g
            ,sum(rsrpgoodcount_105_5g)                                                                       AS rsrpgoodcount_105_5g
            ,sum(rsrpgoodcount_110_5g)/sum(rsrpcount_5g)                                                     AS rsrpgoodcount_rate_110_5g
            ,sum(rsrpgoodcount_105_5g)/sum(rsrpcount_5g)                                                     AS rsrpgoodcount_rate_105_5g
            ,sum(nvl(totalrsrp_4g,0)+nvl(totalrsrp_5g,0))                                                                  AS totalrsrp
            ,sum(nvl(rsrpcount_4g,0)+nvl(rsrpcount_5g,0))                                                                  AS rsrpcount
            ,sum(nvl(totalrsrp_4g,0)+nvl(totalrsrp_5g,0))/sum(nvl(rsrpcount_4g,0)+nvl(rsrpcount_5g,0))                                   AS avgrsrp
            ,sum(nvl(rsrpgoodcount_110_4g,0)+nvl(rsrpgoodcount_110_5g,0))                                                  AS rsrpgoodcount_110
            ,sum(nvl(rsrpgoodcount_105_4g,0)+nvl(rsrpgoodcount_105_5g,0))                                                  AS rsrpgoodcount_105
            ,sum(nvl(rsrpgoodcount_110_4g,0)+nvl(rsrpgoodcount_110_5g,0))/sum(nvl(rsrpcount_4g,0)+nvl(rsrpcount_5g,0))                   AS rsrpgoodcount_rate_110
            ,sum(nvl(rsrpgoodcount_105_4g,0)+nvl(rsrpgoodcount_105_5g,0))/sum(nvl(rsrpcount_4g,0)+nvl(rsrpcount_5g,0))                   AS rsrpgoodcount_rate_105
            ,sum(rsrpcount_5g)/sum(nvl(rsrpcount_5g,0)+nvl(rsrpcount_4g,0))                                                AS rsrpcount_5g_rate
--           ,sum(weak_cover_cel_cnt_4g)                                                                      AS weak_cover_cel_cnt_4g
--           ,sum(weak_cover_cel_cnt_5g)                                                                      AS weak_cover_cel_cnt_5g
--           ,sum(weak_cover_cel_cnt)                                                                         AS weak_cover_cel_cnt
--           ,sum(alarm_cnt_4g)                                                                               AS alarm_cnt_4g
--           ,sum(alarm_cnt_5g)                                                                               AS alarm_cnt_5g
--           ,sum(alarm_cnt)                                                                                  AS alarm_cnt
            ,sum(scan_pay_suc_cnt_4g)                                                                        AS scan_pay_suc_cnt_4g
            ,sum(scan_pay_req_cnt_4g)                                                                        AS scan_pay_req_cnt_4g
            ,sum(scan_pay_suc_cnt_4g)/sum(scan_pay_req_cnt_4g)                                               AS scan_pay_suc_rate_4g
            ,sum(scan_pay_tcpsetupackdelay_4g*scan_pay_req_cnt_4g)/sum(scan_pay_req_cnt_4g)                  AS scan_pay_tcpsetupackdelay_4g
            ,sum(scan_pay_suc_cnt_5g)                                                                        AS scan_pay_suc_cnt_5g
            ,sum(scan_pay_req_cnt_5g)                                                                        AS scan_pay_req_cnt_5g
            ,sum(scan_pay_suc_cnt_5g)/sum(scan_pay_req_cnt_5g)                                               AS scan_pay_suc_rate_5g
            ,sum(scan_pay_tcpsetupackdelay_5g*scan_pay_req_cnt_5g)/sum(scan_pay_req_cnt_5g)                  AS scan_pay_tcpsetupackdelay_5g
            ,sum(nvl(scan_pay_suc_cnt_4g,0)+nvl(scan_pay_suc_cnt_5g,0))                                                    AS scan_pay_suc_cnt
            ,sum(nvl(scan_pay_req_cnt_4g,0)+nvl(scan_pay_req_cnt_5g,0))                                                    AS scan_pay_req_cnt
            ,sum(nvl(scan_pay_suc_cnt_4g,0)+nvl(scan_pay_suc_cnt_5g,0))/sum(nvl(scan_pay_req_cnt_4g,0)+nvl(scan_pay_req_cnt_5g,0))       AS scan_pay_suc_rate
            ,sum(nvl(scan_pay_tcpsetupackdelay_4g*scan_pay_req_cnt_4g,0)+nvl(scan_pay_tcpsetupackdelay_5g*scan_pay_req_cnt_5g,0))/sum(nvl(scan_pay_req_cnt_4g,0)+nvl(scan_pay_req_cnt_5g,0)) AS scan_pay_tcpsetupackdelay
            ,sum(cqi_good_count_4g)                                                                          AS cqi_good_count_4g
            ,sum(cqi_total_count_4g)                                                                         AS cqi_total_count_4g
            ,sum(cqi_good_count_4g)/sum(cqi_total_count_4g)                                                  AS cqi_good_rate_4g
            ,sum(cqi_good_count_5g)                                                                          AS cqi_good_count_5g
            ,sum(cqi_total_count_5g)                                                                         AS cqi_total_count_5g
            ,sum(cqi_good_count_5g)/sum(cqi_total_count_5g)                                                  AS cqi_good_rate_5g
            ,sum(rrc_attconnestab_4g)                                                                        AS rrc_attconnestab_4g
            ,sum(rrc_succconnestab_4g)                                                                       AS rrc_succconnestab_4g
            ,sum(rrc_succconnestab_4g)/sum(rrc_attconnestab_4g)                                              AS rrc_succconnestab_rate_4g
            ,sum(s1sig_attconnestab_4g)                                                                      AS s1sig_attconnestab_4g
            ,sum(s1sig_succconnestab_4g)                                                                     AS s1sig_succconnestab_4g
            ,sum(s1sig_succconnestab_4g)/sum(s1sig_attconnestab_4g)                                          AS s1sig_succconnestab_rate_4g
            ,sum(erab_attestab_4g)                                                                           AS erab_attestab_4g
            ,sum(erab_succestab_4g)                                                                          AS erab_succestab_4g
            ,sum(erab_succestab_4g)/sum(erab_attestab_4g)                                                    AS erab_succestab_rate_4g
            ,nvl(sum(rrc_succconnestab_4g)/sum(rrc_attconnestab_4g),1) * nvl(sum(s1sig_succconnestab_4g)/sum(s1sig_attconnestab_4g),1) * nvl(sum(erab_succestab_4g)/sum(erab_attestab_4g),1) AS access_success_rate_4g
            ,sum(erab_attestab_qci1)                                                                         AS erab_attestab_qci1
            ,sum(erab_succestab_qci1)                                                                        AS erab_succestab_qci1
            ,sum(erab_succestab_qci1)/sum(erab_attestab_qci1)                                                AS erab_succestab_rate_qci1
            ,nvl(sum(rrc_succconnestab_4g)/sum(rrc_attconnestab_4g),1) * nvl(sum(s1sig_succconnestab_4g)/sum(s1sig_attconnestab_4g),1) * nvl(sum(erab_succestab_qci1)/sum(erab_attestab_qci1),1) AS access_success_rate_qci1
            ,sum(erab_abnormrel_qci1)                                                                        AS erab_abnormrel_qci1
            ,sum(erab_normrel_qci1)                                                                          AS erab_normrel_qci1
            ,nvl(sum(erab_abnormrel_qci1)/sum(erab_abnormrel_qci1+erab_normrel_qci1),0)                      AS erab_drop_qci1_rate
            ,sum(rrc_connreq_5g)                                                                             AS rrc_connreq_5g
            ,sum(rrc_connsucc_5g)                                                                            AS rrc_connsucc_5g
            ,sum(rrc_connsucc_5g)/sum(rrc_connreq_5g)                                                        AS rrc_connsucc_rate_5g
            ,sum(ng_connatt_5g)                                                                              AS ng_connatt_5g
            ,sum(ng_connsucc_5g)                                                                             AS ng_connsucc_5g
            ,sum(ng_connsucc_5g)/sum(ng_connatt_5g)                                                          AS ng_connsucc_rate_5g
            ,sum(qos_initialestabreq_5g)                                                                     AS qos_initialestabreq_5g
            ,sum(qos_initialestabsucc_5g)                                                                    AS qos_initialestabsucc_5g
            ,sum(qos_initialestabsucc_5g)/sum(qos_initialestabreq_5g)                                        AS qos_initialestabsucc_rate_5g
            ,nvl(sum(rrc_connsucc_5g)/sum(rrc_connreq_5g),1) * nvl(sum(ng_connsucc_5g)/sum(ng_connatt_5g),1) * nvl(sum(qos_initialestabsucc_5g)/sum(qos_initialestabreq_5g),1) AS access_success_rate_5g
            ,sum(uecntx_abnormrel_4g)                                                                             AS uecntx_abnormrel_4g
            ,sum(uecntx_normrel_4g)                                                                               AS uecntx_normrel_4g
            ,sum(uecntx_abnormrel_4g)/sum(nvl(uecntx_abnormrel_4g,0)+nvl(uecntx_normrel_4g,0))                                  AS uecntx_drop_rate_4g
            ,sum(ue_contextrelease_5g)                                                                            AS ue_contextrelease_5g
            ,sum(ue_normalcontextrelease_5g)                                                                      AS ue_normalcontextrelease_5g
            ,nvl(sum(ue_contextrelease_5g - ue_normalcontextrelease_5g)/sum(ue_contextrelease_5g),0)              AS uecntx_drop_rate_5g
            ,sum(pdcp_sduoctdl_4g)                                                                                AS pdcp_sduoctdl_4g
            ,sum(pdcp_sdutailflowdl_4g)                                                                           AS pdcp_sdutailflowdl_4g
            ,sum(pdcp_thrptimedl_4g)                                                                              AS pdcp_thrptimedl_4g
            ,sum(pdcp_tailtimedl_4g)                                                                              AS pdcp_tailtimedl_4g
            ,sum((pdcp_sduoctdl_4g-pdcp_sdutailflowdl_4g)*8)/sum(( pdcp_thrptimedl_4g-pdcp_tailtimedl_4g)/1000)   AS uexp_meanspeeddl_4g
            ,sum(rlc_txbytesdl_5g)                                                                                AS rlc_txbytesdl_5g
            ,sum(rlc_lasttxbytesdl_5g)                                                                            AS rlc_lasttxbytesdl_5g
            ,sum(rlc_txtimedl_exceptlastslot_5g)                                                                  AS rlc_txtimedl_exceptlastslot_5g
            ,(sum(rlc_txbytesdl_5g-rlc_lasttxbytesdl_5g)*8)/(sum(rlc_txtimedl_exceptlastslot_5g)/1000)            AS uexp_meanspeeddl_5g
            ,sum(pdcp_sdulosspktul_qci1)                                                                          AS pdcp_sdulosspktul_qci1
            ,sum(pdcp_sdupktul_qci1)                                                                              AS pdcp_sdupktul_qci1
            ,nvl(sum(pdcp_sdulosspktul_qci1)/sum(pdcp_sdupktul_qci1),0)                                           AS pdcp_sdulosspktul_qci1_rate
            ,sum(pdcp_sdulosspktdl_qci1)                                                                          AS pdcp_sdulosspktdl_qci1
            ,sum(pdcp_sdupktdl_qci1)                                                                              AS pdcp_sdupktdl_qci1
            ,nvl(sum(pdcp_sdulosspktdl_qci1)/sum(pdcp_sdupktdl_qci1),0)                                           AS pdcp_sdulosspktdl_qci1_rate
            ,sum(vonr_ho_atttovolte_5g)                                                                           AS vonr_ho_atttovolte_5g
            ,sum(vonr_ho_succtovolte_5g)                                                                          AS vonr_ho_succtovolte_5g
            ,sum(vonr_ho_succtovolte_5g)/sum(vonr_ho_atttovolte_5g)                                               AS vonr_ho_succtovolte_rate_5g
            ,sum(vonr_rtp_rxpktul_5g)                                                                             AS vonr_rtp_rxpktul_5g
            ,sum(vonr_rtp_losspktul_5g)                                                                           AS vonr_rtp_losspktul_5g
            ,sum(vonr_rtp_losspktul_5g)/sum(vonr_rtp_rxpktul_5g)                                                  AS vonr_rtp_losspktul_rate_5g
            ,sum(vonr_rtp_rxpktdl_5g)                                                                             AS vonr_rtp_rxpktdl_5g
            ,sum(vonr_rtp_losspktdl_5g)                                                                           AS vonr_rtp_losspktdl_5g
            ,sum(vonr_rtp_losspktdl_5g)/sum(vonr_rtp_rxpktdl_5g)                                                  AS vonr_rtp_losspktdl_rate_5g
            ,sum(vonr_connreq_5g)                                                                                 AS vonr_connreq_5g
            ,sum(vonr_connsucc_5g)                                                                                AS vonr_connsucc_5g
            ,sum(vonr_connsucc_5g)/sum(vonr_connreq_5g)                                                           AS vonr_connsucc_rate_5g
            ,sum(vonr_releasesum_5g)                                                                              AS vonr_releasesum_5g
            ,sum(vonr_normalrelease_5g)                                                                           AS vonr_normalrelease_5g
            ,sum(vonr_releasesum_5g-vonr_normalrelease_5g)/sum(vonr_releasesum_5g)                                AS vonr_abnorrelease_rate_5g
            ,sum(ho_succintragnb_5g)                                                                              AS ho_succintragnb_5g
            ,sum(ho_succbyxn_5g)                                                                                  AS ho_succbyxn_5g
            ,sum(ho_succbyng_5g)                                                                                  AS ho_succbyng_5g
            ,sum(ho_attintragnb_5g)                                                                               AS ho_attintragnb_5g
            ,sum(ho_attbyxn_5g)                                                                                   AS ho_attbyxn_5g
            ,sum(ho_attbyng_5g)                                                                                   AS ho_attbyng_5g
            ,nvl(sum(ho_succintragnb_5g+ho_succbyxn_5g+ho_succbyng_5g)/sum(ho_attintragnb_5g+ho_attbyxn_5g+ho_attbyng_5g),1) AS ho_succ_rate_5g
            ,sum(epsfb_voice_suc)                                                                                 AS epsfb_voice_suc
            ,sum(epsfb_voice_req)                                                                                 AS epsfb_voice_req
            ,sum(epsfb_voice_suc)/sum(epsfb_voice_req)                                                            AS epsfb_voice_suc_rate
            ,sum(intra_5gstoepsbydata)                                                                            AS intra_5gstoepsbydata
            ,sum(intra_5gstoepsbydata)/sum(rrc_connsucc_5g)                                                       AS intra_5gstoepsbydata_rate
            ,sum(web_duration_4g)                                                                                 AS web_duration_4g
            ,sum(video_duration_4g)                                                                               AS video_duration_4g
            ,sum(im_duration_4g)                                                                                  AS im_duration_4g
            ,sum(game_duration_4g)                                                                                AS game_duration_4g
            ,sum(duration_total_4g)                                                                               AS duration_total_4g
            ,sum(httpwebrspcount_4g)                                                                              AS httpwebrspcount_4g
            ,sum(httpwebreqcount_4g)                                                                              AS httpwebreqcount_4g
            ,sum(httpwebrspcount_4g)/sum(httpwebreqcount_4g)                                                      AS httpwebrsprate_4g
            ,sum(httpwebdspdelay_4g*httpwebrspcount_4g)/sum(httpwebrspcount_4g)                                   AS httpwebdspdelay_4g
            ,sum(httpwebscreendelay_4g*httpwebrspcount_4g)/sum(httpwebrspcount_4g)                                AS httpwebscreendelay_4g
            ,sum(videoplaysuccesscount_4g)                                                                        AS videoplaysuccesscount_4g
            ,sum(videoplayrequestcount_4g)                                                                        AS videoplayrequestcount_4g
            ,sum(videothroughput_4g*videoplaysuccesscount_4g)/sum(videoplaysuccesscount_4g)                       AS videothroughput_4g
            ,sum(videoplaytime_without_halt_sum_4g)                                                               AS videoplaytime_without_halt_sum_4g
            ,sum(videoplayhaltcount_4g)                                                                           AS videoplayhaltcount_4g
            ,case when sum(videoplaytime_without_halt_sum_4g) !=0 then sum(videoplayhaltcount_4g)*60000/sum(videoplaytime_without_halt_sum_4g) else 0 end AS kqi_videoplayhaltcountpermin_4g
            ,sum(times_excellentdownlink_4g)                                                                      AS times_excellentdownlink_4g
            ,sum(times_inferiordownlink_4g)                                                                       AS times_inferiordownlink_4g
            ,sum(times_welldownlink_4g)                                                                           AS times_welldownlink_4g
            ,sum(times_excellentstallfrequ_4g)                                                                    AS times_excellentstallfrequ_4g
            ,sum(times_inferiorstallfrequ_4g)                                                                     AS times_inferiorstallfrequ_4g
            ,sum(times_wellstallfrequ_4g)                                                                         AS times_wellstallfrequ_4g
            ,sum(messagesucccount_4g)                                                                             AS messagesucccount_4g
            ,sum(messagereqcount_4g)                                                                              AS messagereqcount_4g
            ,sum(messagesucccount_4g)/sum(messagereqcount_4g)                                                     AS messagesucc_rate_4g
            ,sum(game_cnt_4g)                                                                                     AS game_cnt_4g
            ,case when sum(game_cnt_4g)  !=0 then sum(game_cnt_4g*gameinteractdelay_4g)/sum(game_cnt_4g) else 0 end AS gameinteractdelay_4g
            ,sum(dnsqueryrspcount_4g)                                                                             AS dnsqueryrspcount_4g
            ,sum(dnsqueryreqcount_4g)                                                                             AS dnsqueryreqcount_4g
            ,sum(dnsqueryrspcount_4g)/sum(dnsqueryreqcount_4g)                                                    AS dnsquerysuc_rate_4g
            ,sum(httpwebrspcount_4g)/sum(httpwebreqcount_4g)                                                      AS web_good_rate_4g
            ,CASE WHEN sum(nvl(times_excellentdownlink_4g,0)+nvl(times_welldownlink_4g,0))/sum(nvl(times_excellentdownlink_4g,0)+nvl(times_welldownlink_4g,0)+nvl(times_inferiordownlink_4g,0)) < sum(nvl(times_excellentstallfrequ_4g,0)+nvl(times_wellstallfrequ_4g,0))/sum(nvl(times_excellentstallfrequ_4g,0)+nvl(times_wellstallfrequ_4g,0)+nvl(times_inferiorstallfrequ_4g,0)) THEN sum(nvl(times_excellentdownlink_4g,0)+nvl(times_welldownlink_4g,0))/sum(nvl(times_excellentdownlink_4g,0)+nvl(times_welldownlink_4g,0)+nvl(times_inferiordownlink_4g,0)) ELSE sum(nvl(times_excellentstallfrequ_4g,0)+nvl(times_wellstallfrequ_4g,0))/sum(nvl(times_excellentstallfrequ_4g,0)+nvl(times_wellstallfrequ_4g,0)+nvl(times_inferiorstallfrequ_4g,0)) END AS video_good_rate_4g
            ,sum(messagesucccount_4g)/sum(messagereqcount_4g)                                                     AS im_good_rate_4g
            ,CASE
                WHEN sum(game_cnt_4g*gameinteractdelay_4g)/sum(game_cnt_4g) <= 150                       THEN 1
                WHEN 100 - (sum(game_cnt_4g*gameinteractdelay_4g)/sum(game_cnt_4g) - 150) * 0.75 <= 0    THEN 0
                ELSE (100 - (sum(game_cnt_4g*gameinteractdelay_4g)/sum(game_cnt_4g) - 150) * 0.75) / 100
            END                                                                                                  AS game_good_rate_4g
            ,sum(web_duration_5g)                                                                                 AS web_duration_5g
            ,sum(video_duration_5g)                                                                               AS video_duration_5g
            ,sum(im_duration_5g)                                                                                  AS im_duration_5g
            ,sum(game_duration_5g)                                                                                AS game_duration_5g
            ,sum(duration_total_5g)                                                                               AS duration_total_5g
            ,sum(httpwebrspcount_5g)                                                                              AS httpwebrspcount_5g
            ,sum(httpwebreqcount_5g)                                                                              AS httpwebreqcount_5g
            ,sum(httpwebrspcount_5g)/sum(httpwebreqcount_5g)                                                      AS httpwebrsprate_5g
            ,sum(httpwebdspdelay_5g*httpwebrspcount_5g)/sum(httpwebrspcount_5g)                                   AS httpwebdspdelay_5g
            ,sum(httpwebscreendelay_5g*httpwebrspcount_5g)/sum(httpwebrspcount_5g)                                AS httpwebscreendelay_5g
            ,sum(videoplaysuccesscount_5g)                                                                        AS videoplaysuccesscount_5g
            ,sum(videoplayrequestcount_5g)                                                                        AS videoplayrequestcount_5g
            ,sum(videothroughput_5g*videoplaysuccesscount_5g)/sum(videoplaysuccesscount_5g)                       AS videothroughput_5g
            ,sum(videoplaytime_without_halt_sum_5g)                                                               AS videoplaytime_without_halt_sum_5g
            ,sum(videoplayhaltcount_5g)                                                                           AS videoplayhaltcount_5g
            ,case when sum(videoplaytime_without_halt_sum_5g) !=0 then sum(videoplayhaltcount_5g)*60000/sum(videoplaytime_without_halt_sum_5g) else 0 end AS kqi_videoplayhaltcountpermin_5g
            ,sum(times_excellentdownlink_5g)                                                                      AS times_excellentdownlink_5g
            ,sum(times_inferiordownlink_5g)                                                                       AS times_inferiordownlink_5g
            ,sum(times_welldownlink_5g)                                                                           AS times_welldownlink_5g
            ,sum(times_excellentstallfrequ_5g)                                                                    AS times_excellentstallfrequ_5g
            ,sum(times_inferiorstallfrequ_5g)                                                                     AS times_inferiorstallfrequ_5g
            ,sum(times_wellstallfrequ_5g)                                                                         AS times_wellstallfrequ_5g
            ,sum(messagesucccount_5g)                                                                             AS messagesucccount_5g
            ,sum(messagereqcount_5g)                                                                              AS messagereqcount_5g
            ,sum(messagesucccount_5g)/sum(messagereqcount_5g)                                                     AS messagesucc_rate_5g
            ,sum(game_cnt_5g)                                                                                     AS game_cnt_5g
            ,case when sum(game_cnt_5g)  !=0 then sum(gameinteractdelay_5g*game_cnt_5g)/sum(game_cnt_5g) else 0 end AS gameinteractdelay_5g
            ,sum(dnsqueryrspcount_5g)                                                                             AS dnsqueryrspcount_5g
            ,sum(dnsqueryreqcount_5g)                                                                             AS dnsqueryreqcount_5g
            ,sum(dnsqueryrspcount_5g)/sum(dnsqueryreqcount_5g)                                                    AS dnsquerysuc_rate_5g
            ,sum(httpwebrspcount_5g)/sum(httpwebreqcount_5g)                                                      AS web_good_rate_5g
            ,CASE WHEN sum(nvl(times_excellentdownlink_5g,0)+nvl(times_welldownlink_5g,0))/sum(nvl(times_excellentdownlink_5g,0)+nvl(times_welldownlink_5g,0)+nvl(times_inferiordownlink_5g,0)) < sum(nvl(times_excellentstallfrequ_5g,0)+nvl(times_wellstallfrequ_5g,0))/sum(nvl(times_excellentstallfrequ_5g,0)+nvl(times_wellstallfrequ_5g,0)+nvl(times_inferiorstallfrequ_5g,0)) THEN sum(nvl(times_excellentdownlink_5g,0)+nvl(times_welldownlink_5g,0))/sum(nvl(times_excellentdownlink_5g,0)+nvl(times_welldownlink_5g,0)+nvl(times_inferiordownlink_5g,0)) ELSE sum(nvl(times_excellentstallfrequ_5g,0)+nvl(times_wellstallfrequ_5g,0))/sum(nvl(times_excellentstallfrequ_5g,0)+nvl(times_wellstallfrequ_5g,0)+nvl(times_inferiorstallfrequ_5g,0)) END AS video_good_rate_5g
            ,sum(messagesucccount_5g)/sum(messagereqcount_5g)                                                     AS im_good_rate_5g
            ,CASE
                WHEN sum(gameinteractdelay_5g*game_cnt_5g)/sum(game_cnt_5g) <= 150                       THEN 1
                WHEN 100 - (sum(gameinteractdelay_5g*game_cnt_5g)/sum(game_cnt_5g) - 150) * 0.75 <= 0    THEN 0
                ELSE (100 - (sum(gameinteractdelay_5g*game_cnt_5g)/sum(game_cnt_5g) - 150) * 0.75) / 100
            END AS game_good_rate_5g
            ,sum(vonr_rtp_losspktul_5g)/sum(vonr_rtp_rxpktul_5g)*0.5 + sum(vonr_rtp_losspktdl_5g)/sum(vonr_rtp_rxpktdl_5g)*0.5 vonr_rtp_losspkt_rate_5g
            ,sum(wechat_message_suc_cnt_4g) wechat_message_suc_cnt_4g
            ,sum(wechat_message_req_cnt_4g) wechat_message_req_cnt_4g
            ,sum(wechat_message_suc_cnt_4g)/sum(wechat_message_req_cnt_4g) wechat_message_suc_rate_4g
            ,sum(wechat_message_suc_cnt_5g) wechat_message_suc_cnt_5g
            ,sum(wechat_message_req_cnt_5g) wechat_message_req_cnt_5g
            ,sum(wechat_message_suc_cnt_5g)/sum(wechat_message_req_cnt_5g) wechat_message_suc_rate_5g
            ,sum(uexp_meanspeeddl_35_flow) uexp_meanspeeddl_35_flow
            ,sum(uexp_meanspeeddl_35_duration) uexp_meanspeeddl_35_duration
            ,sum(uexp_meanspeeddl_35_flow)/sum(uexp_meanspeeddl_35_duration) uexp_meanspeeddl_35
            ,sum(uexp_meanspeeddl_21_flow) uexp_meanspeeddl_21_flow
            ,sum(uexp_meanspeeddl_21_duration) uexp_meanspeeddl_21_duration
            ,sum(uexp_meanspeeddl_21_flow)/sum(uexp_meanspeeddl_21_duration) uexp_meanspeeddl_21
            ,if(sum(rsrpgoodcount_105_5g)/sum(rsrpcount_5g) >= 0.95, 15, if((sum(rsrpgoodcount_105_5g)/sum(rsrpcount_5g) - 0.95)*500 + 15< 0, 0,(sum(rsrpgoodcount_105_5g)/sum(rsrpcount_5g) - 0.95)*500 + 15)) cover_rate_score_5g
            ,if((sum(videoplaysuccesscount_5g) / sum(videoplayrequestcount_5g)) >= 0.97, 5, if(((sum(videoplaysuccesscount_5g) / sum(videoplayrequestcount_5g)) - 0.97)*100 + 5 < 0, 0,((sum(videoplaysuccesscount_5g) / sum(videoplayrequestcount_5g)) - 0.97)*100 + 5)) videoplaysucc_rate_score_5g
            ,if((sum(wechat_message_suc_cnt_5g)/sum(wechat_message_req_cnt_5g)) >= 0.97, 5, if(((sum(wechat_message_suc_cnt_5g)/sum(wechat_message_req_cnt_5g)) - 0.97)*100 + 5 < 0, 0,((sum(wechat_message_suc_cnt_5g)/sum(wechat_message_req_cnt_5g)) - 0.97)*100 + 5)) wechat_message_suc_rate_score_5g
            ,if((sum(vonr_connsucc_5g)/sum(vonr_connreq_5g)) >= 0.95, 5, if((sum(vonr_connsucc_5g)/sum(vonr_connreq_5g) - 0.95)*100 + 5 < 0 ,0,(sum(vonr_connsucc_5g)/sum(vonr_connreq_5g) - 0.95)*100 + 5))  vonr_connsucc_rate_score_5g
            ,if((sum(vonr_releasesum_5g-vonr_normalrelease_5g)/sum(vonr_releasesum_5g)) <= 0.02, 5, if(5 - ((sum(vonr_releasesum_5g-vonr_normalrelease_5g)/sum(vonr_releasesum_5g)) - 0.02)*100 < 0 ,0,5 - ((sum(vonr_releasesum_5g-vonr_normalrelease_5g)/sum(vonr_releasesum_5g)) - 0.02)*100)) vonr_abnorrelease_rate_score_5g
            ,nvl(if(sum(rsrpgoodcount_105_5g)/sum(rsrpcount_5g) >= 0.95, 15, if((sum(rsrpgoodcount_105_5g)/sum(rsrpcount_5g) - 0.95)*500 + 15< 0, 0,(sum(rsrpgoodcount_105_5g)/sum(rsrpcount_5g) - 0.95)*500 + 15)), 0) + nvl(if((sum(videoplaysuccesscount_5g) / sum(videoplayrequestcount_5g)) >= 0.97, 5, if(((sum(videoplaysuccesscount_5g) / sum(videoplayrequestcount_5g)) - 0.97)*100 + 5 < 0, 0,((sum(videoplaysuccesscount_5g) / sum(videoplayrequestcount_5g)) - 0.97)*100 + 5)), 0) + nvl(if((sum(wechat_message_suc_cnt_5g)/sum(wechat_message_req_cnt_5g)) >= 0.97, 5, if(((sum(wechat_message_suc_cnt_5g)/sum(wechat_message_req_cnt_5g)) - 0.97)*100 + 5 < 0, 0,((sum(wechat_message_suc_cnt_5g)/sum(wechat_message_req_cnt_5g)) - 0.97)*100 + 5)), 0) + nvl(if((sum(vonr_connsucc_5g)/sum(vonr_connreq_5g)) >= 0.95, 5, if((sum(vonr_connsucc_5g)/sum(vonr_connreq_5g) - 0.95)*100 + 5 < 0,0,(sum(vonr_connsucc_5g)/sum(vonr_connreq_5g) - 0.95)*100 + 5)), 0) + nvl(if((sum(vonr_releasesum_5g-vonr_normalrelease_5g)/sum(vonr_releasesum_5g)) >= 0.95, 5, if(((sum(vonr_releasesum_5g-vonr_normalrelease_5g)/sum(vonr_releasesum_5g)) - 0.95)*100 + 5 < 0,0,((sum(vonr_releasesum_5g-vonr_normalrelease_5g)/sum(vonr_releasesum_5g)) - 0.95)*100 + 5)), 0) cover_score
            ,if((sum(vonr_ho_succtovolte_5g)/sum(vonr_ho_atttovolte_5g)) >= 0.995, 15, if((sum(vonr_ho_succtovolte_5g)/sum(vonr_ho_atttovolte_5g) - 0.995)*500 + 15<0,0,(sum(vonr_ho_succtovolte_5g)/sum(vonr_ho_atttovolte_5g) - 0.995)*500 + 15)) vonr_ho_succtovolte_rate_score_5g
--             ,if((sum(vonr_rtp_losspktul_5g)/sum(vonr_rtp_rxpktul_5g) * 0.5 + sum(vonr_rtp_losspktdl_5g)/sum(vonr_rtp_rxpktdl_5g) * 0.5) <= 0.001, 15, IF(((sum(vonr_rtp_losspktul_5g)/sum(vonr_rtp_rxpktul_5g) * 0.5 + sum(vonr_rtp_losspktdl_5g)/sum(vonr_rtp_rxpktdl_5g) * 0.5) - 0.001)*5000 - 15 < 0,0,((sum(vonr_rtp_losspktul_5g)/sum(vonr_rtp_rxpktul_5g) * 0.5 + sum(vonr_rtp_losspktdl_5g)/sum(vonr_rtp_rxpktdl_5g) * 0.5) - 0.001)*5000 - 15)) vonr_rtp_losspkt_rate_score_5g
            ,if((sum(vonr_rtp_losspktul_5g)/sum(vonr_rtp_rxpktul_5g) * 0.5 + sum(vonr_rtp_losspktdl_5g)/sum(vonr_rtp_rxpktdl_5g) * 0.5) <= 0.001, 15, IF(15 - ((sum(vonr_rtp_losspktul_5g)/sum(vonr_rtp_rxpktul_5g) * 0.5 + sum(vonr_rtp_losspktdl_5g)/sum(vonr_rtp_rxpktdl_5g) * 0.5) - 0.001)*5000 < 0,0,15 - ((sum(vonr_rtp_losspktul_5g)/sum(vonr_rtp_rxpktul_5g) * 0.5 + sum(vonr_rtp_losspktdl_5g)/sum(vonr_rtp_rxpktdl_5g) * 0.5) - 0.001)*5000)) vonr_rtp_losspkt_rate_score_5g
            ,sum(rsrpgoodcount_ott_ctcc_5g) rsrpgoodcount_ott_ctcc_5g
            ,sum(rsrpcount_ott_ctcc_5g) rsrpcount_ott_ctcc_5g
            ,sum(rsrpgoodcount_ott_ctcc_5g)/sum(rsrpcount_ott_ctcc_5g) cover_rate_ott_ctcc_5g
            ,sum(rsrpgoodcount_ott_cucc_5g) rsrpgoodcount_ott_cucc_5g
            ,sum(rsrpcount_ott_cucc_5g) rsrpcount_ott_cucc_5g
            ,sum(rsrpgoodcount_ott_cucc_5g)/sum(rsrpcount_ott_cucc_5g) cover_rate_ott_cucc_5g
            ,sum(rsrpgoodcount_ott_cmcc_5g) rsrpgoodcount_ott_cmcc_5g
            ,sum(rsrpcount_ott_cmcc_5g) rsrpcount_ott_cmcc_5g
            ,sum(rsrpgoodcount_ott_cmcc_5g)/sum(rsrpcount_ott_cmcc_5g) cover_rate_ott_cmcc_5g
        FROM
            dm_subway_section_station_d
        WHERE p_date = '$dm_subway_pc_line_stat_d.p_date$'
        GROUP BY
            provincecode
           ,province_name
           ,citycode
           ,city_name
           ,subway_line_id
           ,subway_line
        GROUPING SETS(
            (provincecode,province_name,citycode,city_name,subway_line_id,subway_line)
            ,(provincecode,province_name,citycode,city_name)
            ,(provincecode,province_name)
            ,()
        )
    ) t1
    LEFT JOIN
    (
        SELECT
            CASE
                WHEN subway_line_id IS NOT NULL THEN 3
                WHEN citycode IS NOT NULL       THEN 2
                WHEN provincecode IS NOT NULL   THEN 1
                ELSE 0
            END AS data_level
           ,provincecode
           ,citycode
           ,subway_line_id
           ,SUM(is_bad_line)                                            AS bad_line_cnt
           ,COUNT(DISTINCT citycode,subway_line_id)                     AS line_cnt
           ,SUM(is_bad_line) / COUNT(DISTINCT citycode,subway_line_id)  AS bad_line_rate
        FROM
            tmp_bad_subway_flag
        GROUP BY
            provincecode
           ,citycode
           ,subway_line_id
        GROUPING SETS(
            (provincecode,citycode,subway_line_id)
            ,(provincecode,citycode)
            ,(provincecode)
            ,()
        )
    ) t2
    ON t1.data_level = t2.data_level
        AND CASE
                WHEN t1.data_level = 3 THEN t1.provincecode = t2.provincecode AND t1.citycode = t2.citycode AND t1.subway_line_id = t2.subway_line_id
                WHEN t1.data_level = 2 THEN t1.provincecode = t2.provincecode AND t1.citycode = t2.citycode
                WHEN t1.data_level = 1 THEN t1.provincecode = t2.provincecode
                ELSE 1 = 1
            END
    LEFT JOIN
        tmp_bad_subway_flag t3
    ON t1.data_level = t3.data_level
        AND t1.provincecode = t3.provincecode
        AND t1.citycode = t3.citycode
        AND t1.subway_line_id = t3.subway_line_id
    LEFT JOIN
    (
        SELECT
            CASE
                WHEN subway_line_id IS NOT NULL THEN 3
                WHEN citycode IS NOT NULL       THEN 2
                WHEN provincecode IS NOT NULL   THEN 1
                ELSE 0
            END AS data_level
           ,provincecode
           ,citycode
           ,subway_line_id
           ,COUNT(DISTINCT CASE WHEN net_type='4G' THEN msisdn ELSE NULL END)   AS usr_cnt_4g
           ,COUNT(DISTINCT CASE WHEN net_type='5G' THEN msisdn ELSE NULL END)   AS usr_cnt_5g
           ,COUNT(DISTINCT msisdn)                                              AS usr_cnt
        FROM
            dm_subway_usrcel_list_h
        WHERE p_date = '$dm_subway_pc_line_stat_d.p_date$'
        GROUP BY
            provincecode
           ,citycode
           ,subway_line_id
        GROUPING SETS(
            (provincecode,citycode,subway_line_id)
            ,(provincecode,citycode)
            ,(provincecode)
            ,()
        )
    ) t4
    ON t1.data_level = t4.data_level
        AND CASE
                WHEN t1.data_level = 3 THEN t1.provincecode = t4.provincecode AND t1.citycode = t4.citycode AND t1.subway_line_id = t4.subway_line_id
                WHEN t1.data_level = 2 THEN t1.provincecode = t4.provincecode AND t1.citycode = t4.citycode
                WHEN t1.data_level = 1 THEN t1.provincecode = t4.provincecode
                ELSE 1 = 1
            END
    LEFT JOIN
    (
        SELECT
            CASE
                WHEN subway_line_id IS NOT NULL THEN 3
                WHEN citycode IS NOT NULL       THEN 2
                WHEN provincecode IS NOT NULL   THEN 1
                ELSE 0
            END AS data_level
            ,provincecode
            ,citycode
            ,subway_line_id
            ,COUNT(DISTINCT CASE WHEN master_operators='电信' THEN cellkey ELSE NULL END)  AS cel_ctcc_cnt_4g
            ,COUNT(DISTINCT CASE WHEN master_operators='联通' THEN cellkey ELSE NULL END)  AS cel_cucc_cnt_4g
            ,COUNT(DISTINCT cellkey)                                                       AS cel_cnt_4g
        FROM
            dm_subway_section_station_sector_lte_rel_use_d  -- 切换数据源 20250626
        WHERE p_date = '$dm_subway_section_station_sector_lte_rel_use_d.p_date$'
            AND valid_flag = 1  -- 添加过滤条件 20250626
        GROUP BY
            provincecode
           ,citycode
           ,subway_line_id
        GROUPING SETS(
            (provincecode,citycode,subway_line_id)
            ,(provincecode,citycode)
            ,(provincecode)
            ,()
        )
    ) t5
    ON t1.data_level = t5.data_level
        AND CASE
                WHEN t1.data_level = 3 THEN t1.provincecode = t5.provincecode AND t1.citycode = t5.citycode AND t1.subway_line_id = t5.subway_line_id
                WHEN t1.data_level = 2 THEN t1.provincecode = t5.provincecode AND t1.citycode = t5.citycode
                WHEN t1.data_level = 1 THEN t1.provincecode = t5.provincecode
                ELSE 1 = 1
            END
    LEFT JOIN
    (
        SELECT
            CASE
                WHEN subway_line_id IS NOT NULL THEN 3
                WHEN citycode IS NOT NULL       THEN 2
                WHEN provincecode IS NOT NULL   THEN 1
                ELSE 0
            END AS data_level
            ,provincecode
            ,citycode
            ,subway_line_id
            ,COUNT(DISTINCT CASE WHEN master_operators='电信' THEN cellkey ELSE NULL END)  AS cel_ctcc_cnt_5g
            ,COUNT(DISTINCT CASE WHEN master_operators='联通' THEN cellkey ELSE NULL END)  AS cel_cucc_cnt_5g
            ,COUNT(DISTINCT cellkey)                                                       AS cel_cnt_5g
            ,count(distinct case when freq='3.5G' then cellkey else null end) cell_cnt_35_5g
            ,count(distinct case when freq='3.5G' then cellkey else null end)/count(distinct cellkey) cell_cnt_rate_35_5g
        FROM
            dm_subway_section_station_sector_nr_rel_use_d  -- 切换数据源 20250626
        WHERE p_date = '$dm_subway_section_station_sector_nr_rel_use_d.p_date$'
            AND valid_flag = 1  -- 添加过滤条件 20250626
        GROUP BY
            provincecode
           ,citycode
           ,subway_line_id
        GROUPING SETS(
            (provincecode,citycode,subway_line_id)
            ,(provincecode,citycode)
            ,(provincecode)
            ,()
        )
    ) t6
    ON t1.data_level = t6.data_level
        AND CASE
                WHEN t1.data_level = 3 THEN t1.provincecode = t6.provincecode AND t1.citycode = t6.citycode AND t1.subway_line_id = t6.subway_line_id
                WHEN t1.data_level = 2 THEN t1.provincecode = t6.provincecode AND t1.citycode = t6.citycode
                WHEN t1.data_level = 1 THEN t1.provincecode = t6.provincecode
                ELSE 1 = 1
            END
    left join
    (
        select
            CASE
                WHEN subway_line_id IS NOT NULL THEN 3
                WHEN citycode IS NOT NULL       THEN 2
                WHEN provincecode IS NOT NULL   THEN 1
                ELSE 0
            END AS data_level
            ,provincecode
            ,citycode
            ,subway_line_id
            ,count(distinct case when net_type='4G' and is_zero_flux=1 then cellkey else null end) zero_cell_cnt_4g
            ,count(distinct case when net_type='5G' and is_zero_flux=1 then cellkey else null end) zero_cell_cnt_5g
            ,nvl(count(distinct case when net_type='4G' and is_zero_flux=1 then cellkey else null end),0) + nvl(count(distinct case when net_type='5G' and is_zero_flux=1 then cellkey else null end),0) zero_cell_cnt
            ,count(distinct case when net_type='4G' and is_highload=1 then cellkey else null end) highload_cnt_4g
            ,count(distinct case when net_type='5G' and is_highload=1 then cellkey else null end) highload_cnt_5g
            ,nvl(count(distinct case when net_type='4G' and is_highload=1 then cellkey else null end),0) + nvl(count(distinct case when net_type='5G' and is_highload=1 then cellkey else null end),0) highload_cnt
            ,count(distinct case when net_type='4G' and is_bad_cover=1 then cellkey else null end) weak_cover_cel_cnt_4g
            ,count(distinct case when net_type='5G' and is_bad_cover=1 then cellkey else null end) weak_cover_cel_cnt_5g
            ,nvl(count(distinct case when net_type='4G' and is_bad_cover=1 then cellkey else null end),0) + nvl(count(distinct case when net_type='5G' and is_bad_cover=1 then cellkey else null end),0) weak_cover_cel_cnt
            ,count(distinct case when net_type='4G' and is_alarm=1 then cellkey else null end) alarm_cnt_4g
            ,count(distinct case when net_type='5G' and is_alarm=1 then cellkey else null end) alarm_cnt_5g
            ,nvl(count(distinct case when net_type='4G' and is_alarm=1 then cellkey else null end),0) + nvl(count(distinct case when net_type='5G' and is_alarm=1 then cellkey else null end),0) alarm_cnt
        from
            dm_subway_cel_index_d
        where p_date = '$dm_subway_pc_line_stat_d.p_date$'
        GROUP BY
            provincecode
           ,citycode
           ,subway_line_id
        GROUPING SETS(
            (provincecode,citycode,subway_line_id)
            ,(provincecode,citycode)
            ,(provincecode)
            ,()
        )
    ) t7
    ON t1.data_level = t7.data_level
        AND CASE
                WHEN t1.data_level = 3 THEN t1.provincecode = t7.provincecode AND t1.citycode = t7.citycode AND t1.subway_line_id = t7.subway_line_id
                WHEN t1.data_level = 2 THEN t1.provincecode = t7.provincecode AND t1.citycode = t7.citycode
                WHEN t1.data_level = 1 THEN t1.provincecode = t7.provincecode
                ELSE 1 = 1
            END
    LEFT JOIN
    (
        SELECT
            CASE
                WHEN subway_line_id IS NOT NULL THEN 3
                WHEN citycode IS NOT NULL       THEN 2
                WHEN provincecode IS NOT NULL   THEN 1
                ELSE 0
            END AS data_level
           ,provincecode
           ,citycode
           ,subway_line_id
           ,SUM(section_distance)   AS line_distance
        FROM
        (
            SELECT
                provincecode
               ,citycode
               ,line_id AS subway_line_id
               ,section_id
               ,section_distance / 1000 AS section_distance
               ,ROW_NUMBER() OVER(PARTITION BY provincecode,citycode,line_id,section_id ORDER BY section_distance DESC) rn
            FROM
                dm_subway_section_distance
            WHERE section_distance IS NOT NULL
                AND provincecode IS NOT NULL
            HAVING rn = 1
        ) t
        GROUP BY
            provincecode
           ,citycode
           ,subway_line_id
        GROUPING SETS(
            (provincecode,citycode,subway_line_id)
            ,(provincecode,citycode)
            ,(provincecode)
            ,()
        )
    ) t8
    ON t1.data_level = t8.data_level
        AND CASE
                WHEN t1.data_level = 3 THEN t1.provincecode = t8.provincecode AND t1.citycode = t8.citycode AND t1.subway_line_id = t8.subway_line_id
                WHEN t1.data_level = 2 THEN t1.provincecode = t8.provincecode AND t1.citycode = t8.citycode
                WHEN t1.data_level = 1 THEN t1.provincecode = t8.provincecode
                ELSE 1 = 1
            END
--    LEFT JOIN
--    (
--        SELECT
--            subway_line_id
--           ,p_provincecode  AS provincecode
--           ,citycode
--           ,sum(is_highload)    AS highload_cnt_4g
--           ,sum(is_bad_cover)   AS weak_cover_cel_cnt_4g
--           ,sum(is_alarm)       AS alarm_cnt_4g
--           ,sum(is_zero_flux)   AS zero_cell_cnt_4g
--        FROM
--            dm_subway_cel_lte_index_d
--        WHERE p_date = '$dm_subway_pc_line_stat_d.p_date$'
--            AND subway_line_id IS NOT NULL
--        GROUP BY
--            subway_line_id
--           ,p_provincecode
--           ,citycode
--        GROUPING SETS(
--            (
--                subway_line_id
--               ,p_provincecode
--               ,citycode
--            )
--           ,(
--                p_provincecode
--               ,citycode
--            )
--           ,(
--                p_provincecode
--            )
--           ,()
--        )
--    ) t9
--    ON t1.data_level = t9.data_level
--        AND CASE
--                WHEN t1.data_level = 3 THEN t1.provincecode = t9.provincecode AND t1.citycode = t9.citycode AND t1.subway_line_id = t9.subway_line_id
--                WHEN t1.data_level = 2 THEN t1.provincecode = t9.provincecode AND t1.citycode = t9.citycode
--                WHEN t1.data_level = 1 THEN t1.provincecode = t9.provincecode
--                ELSE 1 = 1
--            END
--    LEFT JOIN
--    (
--        SELECT
--            subway_line_id
--           ,p_provincecode  AS provincecode
--           ,citycode
--           ,sum(is_highload)    AS highload_cnt_5g
--           ,sum(is_bad_cover)   AS weak_cover_cel_cnt_5g
--           ,sum(is_alarm)       AS alarm_cnt_5g
--           ,sum(is_zero_flux)   AS zero_cell_cnt_5g
--        FROM
--            dm_subway_cel_nr_index_d
--        WHERE p_date = '$dm_subway_pc_line_stat_d.p_date$'
--            AND subway_line_id IS NOT NULL
--        GROUP BY
--            subway_line_id
--           ,p_provincecode
--           ,citycode
--        GROUPING SETS(
--            (
--                subway_line_id
--               ,p_provincecode
--               ,citycode
--            )
--           ,(
--                p_provincecode
--               ,citycode
--            )
--           ,(
--                p_provincecode
--            )
--           ,()
--        )
--    ) t10
--    ON t1.data_level = t10.data_level
--        AND CASE
--                WHEN t1.data_level = 3 THEN t1.provincecode = t10.provincecode AND t1.citycode = t10.citycode AND t1.subway_line_id = t10.subway_line_id
--                WHEN t1.data_level = 2 THEN t1.provincecode = t10.provincecode AND t1.citycode = t10.citycode
--                WHEN t1.data_level = 1 THEN t1.provincecode = t10.provincecode
--                ELSE 1 = 1
--            END
) t
;
